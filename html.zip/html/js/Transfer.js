$.ajaxSetup({
	"error":function(XMLHttpRequest, textStatus, errorThrown) {
		alert ('an error occured - please use Firebug console to view the details ');
		if (window.console && window.console.log){
			console.log(textStatus);   
			console.log(errorThrown);   
			console.log(XMLHttpRequest.responseText);   
			console.log(XMLHttpRequest);   
		}
	}});

var modvalue = 1;
function errorFunction1(xhr, status, ex) 
{

	if(xhr.status==0){
		alert('You are offline!!\n Please Check Your Network.');
	}else if(xhr.status==404){
		alert('Requested URL not found.');
	}else if(xhr.status==500){
		alert('This issue occurs due to network connectivity error .');
	}else if(status=='parsererror'){
		alert('Error.\nParsing JSON Request failed.');
	}else if(status=='timeout'){
		alert('Request Time out.');
	}else {
		alert('An error occurred during the communication with the server: ' + xhr.status +' - ' + xhr.statusText);
		alert('Unknow Error.\n'+xhr.responseText);
	}
}	
function next()
{    		
	if($("[name='fdFlag']").val()=='Y')
		if(!CheckDeposite()) return;   
	if(!validateRegeBene())
		return;			
	setRemiAccountDesc();
	setBeneDesc();
	setPurposeDesc();         
	if(validateAmountReq())
	{
		alert("Please Enter Numeric Amount Value");
	}
	else if( parseFloat($('#totalFixed').html())<parseFloat($("[name='minfcamt']").val()) && $("input[name='fixedInr']").is(':checked') && document.pwTranRemiTxn.prefRate.value=='Y')
	{
		alert("To avail the Preferential Rate offer, transaction amount should be "+$("[name='prefFC']").val()+ " " +parseFloat($("[name='minfcamt']").val())+ " or above");
		return;		

	}
	else if(!validateReqNoOfTime())
	{        		
	}
	else if(validateFunName(objFrm))
	{
		if(!$("input[name='fixedInr']").is(':checked') && prodCode == "3")
		{
			alert('Please choose "Transaction amount" option');
			return;				
		}		

		if(($("[name='agreeTerms1']").val()!= "Y") && (prodName == "Exp e-Transfer"))
		{
			alert("Please check the Terms and Conditions check box.");
			return;
		}
		else
		{     		            
			if(prodCode==3)
			{						
				$("input[name='fixedInr']:checked")
				.val(
						$("input[name='fixedInr']:checked").val()=='NONINR'?'N':'Y'
				);
			}
			else if(prodCode==2)
			{			
				$(":radio[value='INR']").attr('checked','checked');
				//alert("22Value::"+$(":radio[value='INR']").val());
				$(":radio[name='fixedInr']:checked")
				.val(
						$(":radio[name='fixedInr']:checked").val()=='NONINR'?'N':'Y'
				);
			}
			else
			{												
				$(":radio[value='NONINR']").attr('checked','checked');
				//alert("11Value::"+$(":radio[value='INR']").val());
				$(":radio[name='fixedInr']:checked")
				.val(
						$(":radio[name='fixedInr']:checked").val()=='NONINR'?'N':'Y'
				);
			}
			var PromoCode=$("[name='product.promoCode']").val();		
			if((PromoCode.length>0)&&(!validatePromoCode(PromoCode)))
			{
				alert('Promo Code cannot contain special characters!');
				$("[name='product.promoCode']").focus();
				return;
			}
			objFrm.action=actionConfirm;					
			objFrm.submit();
		}
	}
}

function exchageAmount(p_remtype,p_bool)
{
	//alert("kjghkhklhlhj     "+p_obj);
	var total = parseFloat($("[name='txnAmount']").val());
	if(isNaN(total)){
		total=0;
	}
	modvalue = p_remtype;
	//alert("p_bool>>>>>>>>"+p_bool+"||"+p_remtype);
	calculate(p_remtype,p_bool);
}
function calculate(p_remtype,p_bool)
{
	var l_country ;
	var remtype = p_remtype;
	var checkboxval =0;
	/*migration enabler */
	var couponCodeReset = document.getElementById("couponCodeReset").value;
	/*migration enabler */
	// var productId = objFrm.productId.value;
	l_country = $("#sample").find("dt a span.value").html();
	//alert("country >>>>>>>>>>>>"+l_country);
	if($('#cd-radio-1').is(':checked'))
	{
		checkboxval =1;
	}
	else if($('#cd-radio-2').is(':checked'))
	{
		checkboxval=2;
	}
	if(remtype == 1)
	{	
		var txnAmount = parseFloat($("[name='txnAmount']").val());
		if($("[name='txnAmount']").val().length == 0)
		{
			alert("Please enter numeric amount value");        
			$("[name='txnAmount']").val("");
			return false;
		}
		if(isNaN(txnAmount))
		{
			if($.trim($("[name='txnAmount']").val()) == "")
				txnAmount=slabFrom;				  
			else
			{
				alert("Please enter numeric amount value");
				$("[name='txnAmount']").val("");
				return false;
			}
		}	
		else
			$("[name='txnAmount']").val($.trim($("[name='txnAmount']").val()));   

		if(parseFloat($("[name='txnAmount']").val()) < 0)
		{
			alert("Please enter non negative amount value");
			$("[name='txnAmount']").val("");
			return false;
		}

	}
	else{
		var txnAmount = parseFloat( $("[name='txnFixedAmount']").val());	
		//alert("txnAmount>>>>>>"+txnAmount);
		if($("[name='txnFixedAmount']").val().length == 0)
		{
			alert("Please enter numeric amount value");
			$("#totalFixed").html("0.00");
			$("[name='txnFixedAmount']").val("");
			return false;
		}
		if(isNaN(txnAmount))
		{
			if($.trim($("[name='txnFixedAmount']").val()) == "")
				txnFixedAmount=slabFromFixed;				
			else
			{
				alert("Please enter numeric amount value");
				$("#total").html("0.00");
				$("[name='txnFixedAmount']").val(""); 
				return false;
			}
		}
		else
			$("[name='txnFixedAmount']").val($.trim($("[name='txnFixedAmount']").val()));  
		if(parseFloat($("[name='txnFixedAmount']").val()) < 0)
		{
			alert("Please enter non negative amount value");
			$("#totalFixed").html("0.00");               
			$("[name='txnFixedAmount']").val("");                
			return false;
		}		
	}
	/*alert("exchangeRateCalculator?productId="+productId+"&&txnAmount="+txnAmount+"&&txnFixedAmount="+txnFixedAmount+"&&fixedInr="+fixedInrRad+"&&deliveryMode=200001");*/
	/*migration enabler */	
	$.ajax( {
		type: "POST",
		cache:false, 	
		url:"IPBasedCountry?txnAmount="+txnAmount+"&&mode="+p_remtype+"&&country="+l_country+"&&countryFlag=false&&taxFlag="+p_bool+"&&checkboxval="+checkboxval+"&&couponCodeReset="+couponCodeReset,
		data: {},
		 // ADDED FOR LOADER BAR
        beforeSend: loadStart,
			complete: loadStop,
		   // ENDED FOR LOADER BAR
		dataType: "text",			  
		success:CallBackName,
		error  : errorFunction
	} )  ;  
	return true;
	// ADDED FOR LOADER BAR
    function loadStart() 
    {
			$(".se-pre-con").fadeIn();
	}
	function loadStop() 
	{
			$(".se-pre-con").fadeOut();
	}
	// ENDED FOR LOADER BAR
	/*migration enabler */
	//CallBack function start here i.e. this function within function	
	function CallBackName(data)
	{      
		
		//alert("info>>>>>>>>>>>>"+info);
		if(info!='0.00')
			
		{	
			var info=data.split("##");
			var remtype =info[6];
			$("[name='productIDVal']").val(info[8]);
			
			if(p_remtype == 2)
			{
				if(p_bool == "true")
				{
					$("[name='txnAmount']").val(info[4]);
					$("[name='productIDVal']").val(info[8]);
					$("#compute123").text(info[4]+" "+info[9]);
					$("#compute345").text(info[2]);
				}
				else
				{
					$("[name='txnAmount']").val(info);
					$("#compute123").text(info[4]+" "+info[9]);
					$("#compute345").text(info[2]);
				}
				
			}	
			else
			{
				if(p_bool == "true")
				{
					$("[name='txnFixedAmount']").val(info[4]);
					$("[name='productIDVal']").val(info[8]);
					$("#compute123").text(info[2]+" "+info[9]);
					$("#compute345").text(info[4]);
				}
				else
				{
					$("[name='txnFixedAmount']").val(info);
					$("#compute123").text(info[2]+" "+info[9]);
					$("#compute345").text(info[4]);
				}
			}
			
			if(remtype == 2)
			{
				
				if(p_bool == "true")
				{
					var flag = info[5];
					$("#excCurrID").text(info[9]);
					$("#exchangRT").text(info[0]+' INR');
					var brkData ="No Data";
					//alert("flag>>>>>>>>>>>"+flag);
					if(flag == "false")
					{
						$("#abcd").empty();
						if(l_country == 'USA'||l_country == 'CAN')
						{								
							brkData =  "<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remitance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div>"+
							/*"<%-- <div class=\"particular\"> <span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> --%>"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Actual Amount For Remitter [a/c]+b:</span> <span></span> <span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";
							
							
							
						}
						else
						{
							brkData ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remitance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Actual Amount For Remitter [a/c]+b:</span> <span></span><span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+' '+ info[9]);
						 $(brkData).appendTo("#abcd");
						
					}
					
					else if(flag == "true")
					{
						$("#abcd").empty();
						if(l_country == 'USA'||l_country == 'CAN')
						{
							brkData =  "<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span></span>Conversion Service Tax (b): <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">" +
							"<span>Remitance Service Charge (b) : </span>  <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							"<span>Exchange Rate (c):</span> <span></span>  <span>"+info[0]+" INR</span>"+
							"</div><div class=\"particular\">"+
							"<span>Transfer Amount (a+b):</span> <span></span>  <span>"+info[10]+' '+info[9]+"</span>"+
							"</div>"+
							/*"<%-- <div class=\"particular\"> <span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> --%>"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Actual Amount For Remitter [a*c] :</span> <span></span> <span>"+info[4]+" INR</span>"+
							"</div>";
						}
						else
						{
							brkData ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Conversion Service Tax (b):</span> <span></span><span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remitance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Transfer Amount (a+b):</span> <span></span> <span>"+info[10]+' '+info[9]+"</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Amount For Receiver [a*c]:</span> <span></span><span>"+info[4]+" INR</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+" INR");
						 $(brkData).appendTo("#abcd");
						
					}	
				}
				
			}
			else
			{ 	
				if(p_bool == "true")
				{
					var flag = info[5];
					var brkData2 = "N";
					$("#excCurrID").text(info[9]);
					$("#exchangRT").text(info[0]+' INR');
					//alert("flag>>>>>>>>>>>"+flag);
					$("#abcd").empty();
					if(flag == "false")
					{
						if(l_country == 'USA'||l_country == 'CAN')
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"particular\">"+
							"<span>Transfer Amount (a+b):</span> <span></span> <span>"+info[10]+' '+info[9]+"</span>"+
							"</div>"+
							/*"<!-- <div class=\"particular\"><span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> -->"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Indicative Amount for receiver [a*c]:</span> <span></span> <span>"+info[4]+" INR</span>"+
							"</div>";
						}
						else
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (c) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (d):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Transfer Amount (a+c):</span> <span></span> <span>"+info[10]+' '+ info[9]+"</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Indicative Amount for receiver [(a*d)-b]:</span> <span></span> <span>"+info[4]+" INR</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+" INR");
					}
					else if(flag == "true")
					{
						if(l_country == 'USA'||l_country == 'CAN')
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div>"+
							/*"<%-- <div class=\"particular\"> <span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> --%>"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Actual Amount For Remitter [a/c]+b:</span> <span></span> <span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";
						}
						else
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Indicative Amount for remitter [a/c]:</span> <span></span> <span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+" "+info[9]);
						
					}
					$(brkData2).appendTo("#abcd");
				}	
			}
		}else
		{
			alert("Exchange Rate is not Available for this Amount");
			if(p_remtype == 2)
			{                             
				$("[name='txnAmount']").val("0.00");		                     
			}else
			{
				$("[name='txnFixedAmount']").val("0.00");                        	                         
			}
			$("#txnamount").text('0.0 INR');
			$("#txnserfee").text('0.0 USD');
			$("#sertax").text('0.0 INR');
			$("#exchngrt").text('0.0 INR');
			$("#totalamt").text('0.0 USD');
			$("#totalAmount").text('0.0 USD');
		} 						
	}//Callback function end
	//calculate function end here
}

function CalculateOnChangeIndicativ(p_Indicative,p_bool)
{
	var l_country ;
	var remtype = modvalue;
	var checkboxval =0;
	// var productId = objFrm.productId.value;
	l_country = $("#sample").find("dt a span.value").html();
	//alert("Modified Value >>>>>>>>>>>>"+modvalue);
	if($('#cd-radio-1').is(':checked'))
	{
		checkboxval =1;
	}
	else if($('#cd-radio-2').is(':checked'))
	{
		checkboxval =2;
	}
	if(modvalue == 1)
	{	
		var txnAmount = parseFloat($("[name='txnAmount']").val());
		if($("[name='txnAmount']").val().length == 0)
		{
			alert("Please enter numeric amount value");        
			$("[name='txnAmount']").val("");
			return false;
		}
		if(isNaN(txnAmount))
		{
			if($.trim($("[name='txnAmount']").val()) == "")
				txnAmount=slabFrom;				  
			else
			{
				alert("Please enter numeric amount value");
				$("[name='txnAmount']").val("");
				return false;
			}
		}	
		else
			$("[name='txnAmount']").val($.trim($("[name='txnAmount']").val()));   

		if(parseFloat($("[name='txnAmount']").val()) < 0)
		{
			alert("Please enter non negative amount value");
			$("[name='txnAmount']").val("");
			return false;
		}

	}
	else{
		var txnAmount = parseFloat( $("[name='txnFixedAmount']").val());	
		//alert("txnAmount>>>>>>"+txnAmount);
		if($("[name='txnFixedAmount']").val().length == 0)
		{
			alert("Please enter numeric amount value");
			$("#totalFixed").html("0.00");
			$("[name='txnFixedAmount']").val("");
			return false;
		}
		if(isNaN(txnAmount))
		{
			if($.trim($("[name='txnFixedAmount']").val()) == "")
				txnFixedAmount=slabFromFixed;				
			else
			{
				alert("Please enter numeric amount value");
				$("#total").html("0.00");
				$("[name='txnFixedAmount']").val(""); 
				return false;
			}
		}
		else
			$("[name='txnFixedAmount']").val($.trim($("[name='txnFixedAmount']").val()));  
		if(parseFloat($("[name='txnFixedAmount']").val()) < 0)
		{
			alert("Please enter non negative amount value");
			$("#totalFixed").html("0.00");               
			$("[name='txnFixedAmount']").val("");                
			return false;
		}		
	}
	/*alert("exchangeRateCalculator?productId="+productId+"&&txnAmount="+txnAmount+"&&txnFixedAmount="+txnFixedAmount+"&&fixedInr="+fixedInrRad+"&&deliveryMode=200001");*/	  	 
	$.ajax( {
		type: "POST",
		cache:false, 	
		url:"IPBasedCountry?txnAmount="+txnAmount+"&&mode="+remtype+"&&country="+l_country+"&&countryFlag=false&&taxFlag="+p_bool+"&&checkboxval="+checkboxval,
		async: false,
		data: {},
		  // ADDED FOR LOADER BAR
        beforeSend: loadStart,
			complete: loadStop,
		   // ENDED FOR LOADER BAR
		dataType: "text",			  
		success:CallBackName,
		error  : errorFunction
	} )  ;  
	return true;
    // ADDED FOR LOADER BAR
    function loadStart() 
    {
			$(".se-pre-con").fadeIn();
	}
	function loadStop() 
	{
			$(".se-pre-con").fadeOut();
	}
	// ENDED FOR LOADER BAR
	//CallBack function start here i.e. this function within function	
	function CallBackName(data)
	{      
		
		//alert("info>>>>>>>>>>>>"+data);
		if(info!='0.00')
			
		{	
			var info=data.split("##");
			var remtype2 =info[6];
			$("[name='productIDVal']").val(info[8]);
			if(remtype2==2)
			{
				//$("#custLimit").text('INR '+info[12]);
			}else
			{
				$("#custLimit").text(info[9]+" "+info[12]);
			}
			if(remtype == 2)
			{
				if(p_bool == "true")
				{
					$("[name='txnAmount']").val(info[4]);
					$("[name='productIDVal']").val(info[8]);
					$("#compute123").text(info[4]+" "+info[9]);
					$("#compute345").text(info[2]);
				}
				else
				{
					$("[name='txnAmount']").val(info);
					$("#compute123").text(info[4]+" "+info[9]);
					$("#compute345").text(info[2]);
				}
			}	
			else
			{
				if(p_bool == "true")
				{
					$("[name='txnFixedAmount']").val(info[4]);
					debugger;
					$("[name='productIDVal']").val(info[8]);
					$("#compute123").text(info[2]+" "+info[9]);
					$("#compute345").text(info[4]);
				}
				else
				{
					$("[name='txnFixedAmount']").val(info); 
					debugger;
					$("#compute123").text(info[2]+" "+info[9]);
					$("#compute345").text(info[4]);
				}
			}
			
			if(remtype2 == 2)
			{
				
				if(p_bool == "true")
				{
					var flag = info[5];
					$("#excCurrID").text(info[9]);
					$("#exchangRT").text(info[0]+' INR');
					
					var brkData ="No Data";
					//alert("flag>>>>>>>>>>>"+flag);
					if(flag == "false")
					{
						$("#abcd").empty();
						if(l_country == 'USA'||l_country == 'CAN')
						{	
							brkData =  "<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remitance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div>"+
							/*"<%-- <div class=\"particular\"> <span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> --%>"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Actual Amount For Remitter [a/c]+b:</span> <span></span> <span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";
							
							
							
						}
						else
						{
							brkData ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remitance Service Charge (c) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Exchange Rate (d):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Actual Amount For Remitter [(a+b)/d]+c:</span> <span></span><span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+' '+ info[9]);
						 $(brkData).appendTo("#abcd");
						
					}
					
					else if(flag == "true")
					{
						$("#abcd").empty();
						if(l_country == 'USA'||l_country == 'CAN')
						{
							brkData =  "<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span></span>Conversion Service Tax (b): <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">" +
							"<span>Remitance Service Charge (b) : </span>  <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							"<span>Exchange Rate (c):</span> <span></span>  <span>"+info[0]+" INR</span>"+
							"</div><div class=\"particular\">"+
							"<span>Transfer Amount (a+b):</span> <span></span>  <span>"+info[10]+' '+info[9]+"</span>"+
							"</div>"+
							/*"<!-- <div class=\"particular\"><span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> -->"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Amount For Receiver [a*c]:</span> <span></span><span>"+info[4]+" INR</span>"+
							"</div>";
						}
						else
						{
							brkData ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Conversion Service Tax (b):</span> <span></span><span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remitance Service Charge (c) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Exchange Rate (d):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Transfer Amount (a+c):</span> <span></span> <span>"+info[10]+' '+info[9]+"</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Amount For Receiver [(a*d)-b]:</span> <span></span><span>"+info[4]+" INR</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+" INR");
						 $(brkData).appendTo("#abcd");
						
					}	
				}
				
			}
			else
			{ 	
				if(p_bool == "true")
				{
					var flag = info[5];
					var brkData2 = "N";
					$("#excCurrID").text(info[9]);
					$("#exchangRT").text(info[0]+' INR');
					//alert("flag>>>>>>>>>>>"+flag);
					$("#abcd").empty();
					if(flag == "false")
					{
						if(l_country == 'USA'||l_country == 'CAN')
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"particular\">"+
							"<span>Transfer Amount (a+b):</span> <span></span> <span>"+info[10]+' '+info[9]+"</span>"+
							"</div>"+
							/*"<!-- <div class=\"particular\"><span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> -->"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Indicative Amount for receiver [a*c]:</span> <span></span> <span>"+info[4]+" INR</span>"+
							"</div>";
						}
						else
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (c) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (d):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Transfer Amount (a+c):</span> <span></span> <span>"+info[10]+' '+ info[9]+"</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Indicative Amount for receiver [(a*d)-b]:</span> <span></span> <span>"+info[4]+" INR</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+" INR");
					}
					else if(flag == "true")
					{
						if(l_country == 'USA'||l_country == 'CAN')
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div>"+
							/*"<%-- <div class=\"particular\"> <span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> --%>"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Actual Amount For Remitter [a/c]+b:</span> <span></span> <span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";
						}
						else
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (c) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (d):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Indicative Amount for remitter [(a+b)/d]+c:</span> <span></span> <span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+" "+info[9]);
						
					}
					$(brkData2).appendTo("#abcd");
				}	
			}
		}else
		{
			alert("Exchange Rate is not Available for this Amount");
			if(p_remtype == 2)
			{                             
				$("[name='txnAmount']").val("0.00");		                     
			}else
			{
				$("[name='txnFixedAmount']").val("0.00");                        	                         
			}
			$("#txnamount").text('0.0 INR');
			$("#txnserfee").text('0.0 USD');
			$("#sertax").text('0.0 INR');
			$("#exchngrt").text('0.0 INR');
			$("#totalamt").text('0.0 USD');
			$("#totalAmount").text('0.0 USD');
		} 						
	}//Callback function end
	//calculate function end here
}





function errorFunction(xhr, status, ex) 
{

	if(xhr.status==0){
		alert('You are offline!!\n Please Check Your Network.');
	}else if(xhr.status==404){
		alert('Requested URL not found.');
	}else if(xhr.status==500){
		alert('This issue occurs due to network connectivity error .');
	}else if(status=='parsererror'){
		alert('Error.\nParsing JSON Request failed.');
	}else if(status=='timeout'){
		alert('Request Time out.');
	}else {
		alert('An error occurred during the communication with the server: ' + xhr.status +' - ' + xhr.statusText);
		alert('Unknow Error.\n'+xhr.responseText);
	}
}

function step2CountryChange(cntryres)
{
	//alert("country on load "+cntryres);  
	//var l_country = $("#sample").find("dt a span.value").html();
	var l_country;
	
	if(cntryres==null || cntryres=='' )
	{
	var l_country = $("#sample").find("dt a span.value").html();
	}
	else
	{
		if(cntryres==77)
		{
		l_country="USA";	
		}
		if(cntryres==88)
		{
		l_country="CAN";	
		}
		if(cntryres==79)
		{
		l_country="SG";	
		}
		if(cntryres==87)
		{
		l_country="AUS";	
		}
		if(cntryres==76)
		{
		l_country="UK";	
		}
		if(cntryres==78)
		{
		l_country="HK";	
		}
		if(cntryres==81)
		{
		l_country="UAE";	
		}
		if(cntryres==97)
		{
		l_country="SWE";	
		}
		if(cntryres==751570)
		{
		l_country="CH";	
		}
	}
	
	
	// added suresh for country based fields
	//alert("l_countryl_countryl_country"+l_country);
	
	
	if(l_country=="USA"){
		
		//$('#textfield8').attr('placeholder','*ZIP code');
		//alert('USAUSAUSAUSA');
		$("#state").hide();
		$("#stateus").show();
		$("#stateasd").hide();
		$("#statecnd").hide();
		$("#citytextfield7").val("");  
		$("#divsin").hide();
		$("#divssn").show();
		
		  $("#countryDescPreText").show();  
		  $("#countryresCad").hide();  
		  $("#countryressg").hide();  
		  $("#countryresaus").hide();   
		  $("#countryresuk").hide();  
		  $("#countryresswe").hide();    
		  $("#countryresch").hide();    
		  $("#countryresuae").hide();    
		  $("#countryreshk").hide();    
		
		  
		   
		  document.regLoginDetailsForm.countryres.value="77";
		//alert(document.regLoginDetailsForm.countryres.value);
						
	}
	else if(l_country=="SG"){

			$("#stateus").hide();
			$("#statecnd").hide();
			$("#stateasd").hide();
			$("#state").show();
			$("#state").val("Singapore"); 
			$("#citytextfield7").val("Singapore");
			$("#divsin").hide();
			$("#divssn").hide();
			
			$("#countryDescPreText").hide();  
			  $("#countryresCad").hide();  
			  $("#countryressg").show();  
			  $("#countryresaus").hide();   
			  $("#countryresuk").hide();  
			  $("#countryresswe").hide();    
			  $("#countryresch").hide();    
			  $("#countryresuae").hide();    
			  $("#countryreshk").hide();  
			  //alert('test2222');
			  document.regLoginDetailsForm.countryres.value="79";
			 // alert(document.regLoginDetailsForm.countryres.value);
	 }
	 
	else if(l_country=="CAN"){
			
			$("#state").hide();
			$("#stateus").hide();
			$("#stateasd").hide(); 
			$("#statecnd").show();
			$("#citytextfield7").val("");
			$("#divssn").hide();
			$("#divsin").show();
			
			$("#countryDescPreText").hide();  
			  $("#countryresCad").show();  
			  $("#countryressg").hide();  
			  $("#countryresaus").hide();   
			  $("#countryresuk").hide();  
			  $("#countryresswe").hide();    
			  $("#countryresch").hide();    
			  $("#countryresuae").hide();    
			  $("#countryreshk").hide();  
			  
			  document.regLoginDetailsForm.countryres.value="88";
			 // alert(document.regLoginDetailsForm.countryres.value);
		}
	 
	else if(l_country=="AUS"){
			
			$("#state").hide();
			$("#stateus").hide();
			$("#statecnd").hide();
			$("#stateasd").show();
			$("#citytextfield7").val("");
			$("#divsin").hide();
			$("#divssn").hide();
			
			$("#countryDescPreText").hide();  
			  $("#countryresCad").hide();  
			  $("#countryressg").hide();  
			  $("#countryresaus").show();   
			  $("#countryresuk").hide();  
			  $("#countryresswe").hide();    
			  $("#countryresch").hide();    
			  $("#countryresuae").hide();    
			  $("#countryreshk").hide();
			  
			  document.regLoginDetailsForm.countryres.value="87";
			 // alert(document.regLoginDetailsForm.countryres.value);
	 }
	 
	else if(l_country=="UK"){
			
			
			$("#stateus").hide();
			$("#statecnd").hide();
			$("#stateasd").hide();  
			//$('#state').attr('placeholder','*County');      
			$("#state").show();
			$("#state").val("");
			$("#citytextfield7").val("");
			$("#divsin").hide();
			$("#divssn").hide();
			
			$("#countryDescPreText").hide();  
			  $("#countryresCad").hide();  
			  $("#countryressg").hide();  
			  $("#countryresaus").hide();   
			  $("#countryresuk").show();  
			  $("#countryresswe").hide();    
			  $("#countryresch").hide();    
			  $("#countryresuae").hide();    
			  $("#countryreshk").hide();  
			  
			  document.regLoginDetailsForm.countryres.value="76";
			  //alert(document.regLoginDetailsForm.countryres.value);
		}  
	 else{  
			//$('#state').attr('placeholder','*State');       
			
			$("#stateus").hide();
			$("#statecnd").hide();
			$("#stateasd").hide();  
			$("#state").show(); 
			$("#state").val("");
			$("#citytextfield7").val("");  
			$("#divsin").hide();
			$("#divssn").hide();   
			
			if(l_country=="HK"){
				$("#countryDescPreText").hide();  
				  $("#countryresCad").hide();  
				  $("#countryressg").hide();  
				  $("#countryresaus").hide();   
				  $("#countryresuk").hide();  
				  $("#countryresswe").hide();    
				  $("#countryresch").hide();    
				  $("#countryresuae").hide();    
				  $("#countryreshk").show();  
				  
				  document.regLoginDetailsForm.countryres.value="78";
				//  alert(document.regLoginDetailsForm.countryres.value);
				
			}
			if(l_country=="UAE"){
				
				$("#countryDescPreText").hide();  
				  $("#countryresCad").hide();  
				  $("#countryressg").hide();  
				  $("#countryresaus").hide();   
				  $("#countryresuk").hide();  
				  $("#countryresswe").hide();    
				  $("#countryresch").hide();    
				  $("#countryresuae").show();    
				  $("#countryreshk").hide();  
				  
				  document.regLoginDetailsForm.countryres.value="81";
				  //alert(document.regLoginDetailsForm.countryres.value);
				
			}
			if(l_country=="SWE"){
				
				$("#countryDescPreText").hide();  
				  $("#countryresCad").hide();  
				  $("#countryressg").hide();  
				  $("#countryresaus").hide();   
				  $("#countryresuk").hide();  
				  $("#countryresswe").show();    
				  $("#countryresch").hide();    
				  $("#countryresuae").hide();    
				  $("#countryreshk").hide();  
				  
				  document.regLoginDetailsForm.countryres.value="97";
				//  alert(document.regLoginDetailsForm.countryres.value);
				
			}
			if(l_country=="CH"){
				
				$("#countryDescPreText").hide();  
				  $("#countryresCad").hide();  
				  $("#countryressg").hide();  
				  $("#countryresaus").hide();   
				  $("#countryresuk").hide();  
				  $("#countryresswe").hide();    
				  $("#countryresch").show();    
				  $("#countryresuae").hide();    
				  $("#countryreshk").hide();  
				  
				  document.regLoginDetailsForm.countryres.value="751570";
				//  alert(document.regLoginDetailsForm.countryres.value);

			}
		}
	 
	
	if(document.regLoginDetailsForm.countryres.value==87){
		$("#textfield").val("61");
		$("#textfieldphonecc").val("61");
	}else if(document.regLoginDetailsForm.countryres.value==88){
		$("#textfield").val("1");
		$("#textfieldphonecc").val("1");
	}else if(document.regLoginDetailsForm.countryres.value==78){
		$("#textfield").val("852");
		$("#textfieldphonecc").val("852");
	}else if(document.regLoginDetailsForm.countryres.value==79){
		$("#textfield").val("65");
		$("#textfieldphonecc").val("65");
	}else if(document.regLoginDetailsForm.countryres.value==97){
		$("#textfield").val("46");
		$("#textfieldphonecc").val("46");
	}else if(document.regLoginDetailsForm.countryres.value==751570){
		$("#textfield").val("41");
		$("#textfieldphonecc").val("41");
	}else if(document.regLoginDetailsForm.countryres.value==81){
		$("#textfield").val("971");
		$("#textfieldphonecc").val("971");
	}else if(document.regLoginDetailsForm.countryres.value==76){
		$("#textfield").val("44");
		$("#textfieldphonecc").val("44");
	}else if(document.regLoginDetailsForm.countryres.value==77){
		$("#textfield").val("1");
		$("#textfieldphonecc").val("1");			
	}else{  
		$("#textfield").val("");
		$("#textfieldphonecc").val("");
	} 
	isNriAccountEnable(document.regLoginDetailsForm.countryres.value);
	
	// ended suresh for country based fields	

}

function exchageFixedAmount(p_remtype,p_bool)
{
	//alert("exchageFixedAmount");
	var l_country = $("#sample").find("dt a span.value").html();
	var txnAmount = parseFloat($("[name='txnAmount']").val());
	var txnFixedAmount = parseFloat( $("[name='txnFixedAmount']").val());		  	 
	$.ajax( {
		type: "POST",
		cache:false, 	
		url:"IPBasedCountry?txnAmount="+txnAmount+"&&mode="+p_remtype+"&&country="+l_country+"&&txnFixedAmount="+txnFixedAmount+"&&countryFlag=true&&taxFlag="+p_bool,
		data: {},
        // ADDED FOR LOADER BAR
        beforeSend: loadStart,
			complete: loadStop,
		   // ENDED FOR LOADER BAR	
		dataType: "text",			  
		success:CallBackName,
		error  : errorFunction
	} );    
	return true;
	 // ADDED FOR LOADER BAR
    function loadStart() 
    {
			$(".se-pre-con").fadeIn();
	}
	function loadStop() 
	{
			$(".se-pre-con").fadeOut();
	}
	// ENDED FOR LOADER BAR
	//CallBack function start here i.e. this function within function	
	function CallBackName(data)
	{      
		
		//alert("info>>>>>>>>>>>>"+info);
		if(info!='0.00')
			
		{	
			var info=data.split("##");
			var remtype =info[6];
			var prodcode = info[12]; //Modified On 29012017
			modvalue = remtype;
			//alert("remtype>>>>>>>>>>>>>>>"+remtype);
			//alert("prodcode>>>>>>>>>>>>>>>"+prodcode);
			// added suresh for country based fields
			
			document.getElementById("submitbtn").disabled = false;
			
			if(l_country=="USA"){
				
				//$('#textfield8').attr('placeholder','*ZIP code');
		//		alert('sjskllfdkljj');
				$("#state").hide();
				$("#stateus").show();
				$("#stateasd").hide();
				$("#statecnd").hide();
				$("#citytextfield7").val("");  
				$("#divsin").hide();
				$("#divssn").show();
				
				  $("#countryDescPreText").show();  
				  $("#countryresCad").hide();  
				  $("#countryressg").hide();  
				  $("#countryresaus").hide();   
				  $("#countryresuk").hide();  
				  $("#countryresswe").hide();    
				  $("#countryresch").hide();    
				  $("#countryresuae").hide();    
				  $("#countryreshk").hide();    
				
				  
				   
				  document.regLoginDetailsForm.countryres.value="77";
				//alert(document.regLoginDetailsForm.countryres.value);
								
			}
			else if(l_country=="SG"){

					$("#stateus").hide();
					$("#statecnd").hide();
					$("#stateasd").hide();
					$("#state").show();
					$("#state").val("Singapore"); 
					$("#citytextfield7").val("Singapore");
					$("#divsin").hide();
					$("#divssn").hide();
					
					$("#countryDescPreText").hide();  
					  $("#countryresCad").hide();  
					  $("#countryressg").show();  
					  $("#countryresaus").hide();   
					  $("#countryresuk").hide();  
					  $("#countryresswe").hide();    
					  $("#countryresch").hide();    
					  $("#countryresuae").hide();    
					  $("#countryreshk").hide();  
					  //alert('test2222');
					  document.regLoginDetailsForm.countryres.value="79";
					 // alert(document.regLoginDetailsForm.countryres.value);
			 }
			 
			else if(l_country=="CAN"){
					
					$("#state").hide();
					$("#stateus").hide();
					$("#stateasd").hide(); 
					$("#statecnd").show();
					$("#citytextfield7").val("");
					$("#divssn").hide();
					$("#divsin").show();
					
					$("#countryDescPreText").hide();  
					  $("#countryresCad").show();  
					  $("#countryressg").hide();  
					  $("#countryresaus").hide();   
					  $("#countryresuk").hide();  
					  $("#countryresswe").hide();    
					  $("#countryresch").hide();    
					  $("#countryresuae").hide();    
					  $("#countryreshk").hide();  
					  
					  document.regLoginDetailsForm.countryres.value="88";
					 // alert(document.regLoginDetailsForm.countryres.value);
				}
			 
			else if(l_country=="AUS"){
					
					$("#state").hide();
					$("#stateus").hide();
					$("#statecnd").hide();
					$("#stateasd").show();
					$("#citytextfield7").val("");
					$("#divsin").hide();
					$("#divssn").hide();
					
					$("#countryDescPreText").hide();  
					  $("#countryresCad").hide();  
					  $("#countryressg").hide();  
					  $("#countryresaus").show();   
					  $("#countryresuk").hide();  
					  $("#countryresswe").hide();    
					  $("#countryresch").hide();    
					  $("#countryresuae").hide();    
					  $("#countryreshk").hide();
					  
					  document.regLoginDetailsForm.countryres.value="87";
					 // alert(document.regLoginDetailsForm.countryres.value);
			 }
			 
			else if(l_country=="UK"){
					
					
					$("#stateus").hide();
					$("#statecnd").hide();
					$("#stateasd").hide();  
					//$('#state').attr('placeholder','*County');      
					$("#state").show();
					$("#state").val("");
					$("#citytextfield7").val("");
					$("#divsin").hide();
					$("#divssn").hide();
					
					$("#countryDescPreText").hide();  
					  $("#countryresCad").hide();  
					  $("#countryressg").hide();  
					  $("#countryresaus").hide();   
					  $("#countryresuk").show();  
					  $("#countryresswe").hide();    
					  $("#countryresch").hide();    
					  $("#countryresuae").hide();    
					  $("#countryreshk").hide();  
					  
					  document.regLoginDetailsForm.countryres.value="76";
					  //alert(document.regLoginDetailsForm.countryres.value);
				}  
			 else{  
					//$('#state').attr('placeholder','*State');       
					
					$("#stateus").hide();
					$("#statecnd").hide();
					$("#stateasd").hide();  
					$("#state").show(); 
					$("#state").val("");
					$("#citytextfield7").val("");  
					$("#divsin").hide();
					$("#divssn").hide();   
					
					if(l_country=="HK"){
						$("#countryDescPreText").hide();  
						  $("#countryresCad").hide();  
						  $("#countryressg").hide();  
						  $("#countryresaus").hide();   
						  $("#countryresuk").hide();  
						  $("#countryresswe").hide();    
						  $("#countryresch").hide();    
						  $("#countryresuae").hide();    
						  $("#countryreshk").show();  
						  
						  document.regLoginDetailsForm.countryres.value="78";
						//  alert(document.regLoginDetailsForm.countryres.value);
						
					}
					if(l_country=="UAE"){
						
						$("#countryDescPreText").hide();  
						  $("#countryresCad").hide();  
						  $("#countryressg").hide();  
						  $("#countryresaus").hide();   
						  $("#countryresuk").hide();  
						  $("#countryresswe").hide();    
						  $("#countryresch").hide();    
						  $("#countryresuae").show();    
						  $("#countryreshk").hide();  
						  
						  document.regLoginDetailsForm.countryres.value="81";
						  //alert(document.regLoginDetailsForm.countryres.value);
						
					}
					if(l_country=="SWE"){
						
						$("#countryDescPreText").hide();  
						  $("#countryresCad").hide();  
						  $("#countryressg").hide();  
						  $("#countryresaus").hide();   
						  $("#countryresuk").hide();  
						  $("#countryresswe").show();    
						  $("#countryresch").hide();    
						  $("#countryresuae").hide();    
						  $("#countryreshk").hide();  
						  
						  document.regLoginDetailsForm.countryres.value="97";
						//  alert(document.regLoginDetailsForm.countryres.value);
						
					}
					if(l_country=="CH"){
						
						$("#countryDescPreText").hide();  
						  $("#countryresCad").hide();  
						  $("#countryressg").hide();  
						  $("#countryresaus").hide();   
						  $("#countryresuk").hide();  
						  $("#countryresswe").hide();    
						  $("#countryresch").show();    
						  $("#countryresuae").hide();    
						  $("#countryreshk").hide();  
						  
						  document.regLoginDetailsForm.countryres.value="751570";
						//  alert(document.regLoginDetailsForm.countryres.value);
	
					}
				}
			$("#regOTP").hide();
			isNriAccountEnable(document.regLoginDetailsForm.countryres.value);
			
			/*$("#regOTP").hide();*/
			
			document.regLoginDetailsForm.password.value='';
			document.regLoginDetailsForm.password2.value='';
			document.getElementById("enter-otp").value='';  
			
			if(document.regLoginDetailsForm.countryres.value==87){
				$("#textfield").val("61");
				$("#textfieldphonecc").val("61");
			}else if(document.regLoginDetailsForm.countryres.value==88){
				$("#textfield").val("1");
				$("#textfieldphonecc").val("1");
			}else if(document.regLoginDetailsForm.countryres.value==78){
				$("#textfield").val("852");
				$("#textfieldphonecc").val("852");
			}else if(document.regLoginDetailsForm.countryres.value==79){
				$("#textfield").val("65");
				$("#textfieldphonecc").val("65");
			}else if(document.regLoginDetailsForm.countryres.value==97){
				$("#textfield").val("46");
				$("#textfieldphonecc").val("46");
			}else if(document.regLoginDetailsForm.countryres.value==751570){
				$("#textfield").val("41");
				$("#textfieldphonecc").val("41");
			}else if(document.regLoginDetailsForm.countryres.value==81){
				$("#textfield").val("971");
				$("#textfieldphonecc").val("971");
			}else if(document.regLoginDetailsForm.countryres.value==76){
				$("#textfield").val("44");
				$("#textfieldphonecc").val("44");
			}else if(document.regLoginDetailsForm.countryres.value==77){
				$("#textfield").val("1");
				$("#textfieldphonecc").val("1");			
			}else{  
				$("#textfield").val("");
				$("#textfieldphonecc").val("");
			}
			
			
			/*if(mobileCCode == 91)
			{
				$("#textfield").val("91");
				$("#textfieldphonecc").val("91");
			}*/
			
			// ended suresh for country based fields
			
			
			$("[name='productIDVal']").val(info[8]);
			//Modified On 29012017 Start----------------------------------------------------------
			if(l_country == "USA")
			{    
				$("#NonFixedINRDiv").hide();
				$("#fixedINRDiv").show();
				//$("#cd-radio-2").attr("Checked","Checked");
				document.getElementById("cd-radio-2").checked = true;
				
			}
			else 
			{if (prodCode == "3") 
				{
					if(remtype == 1)
					//$("#cd-radio-1").attr("Checked","Checked");
					document.getElementById("cd-radio-1").checked = true;
					else
					//$("#cd-radio-2").attr("Checked","Checked");
					document.getElementById("cd-radio-2").checked = true;
					$("#NonFixedINRDiv").show();
					$("#fixedINRDiv").show();
				} 
				else if (prodCode == "2") 
				{
					//$("#cd-radio-1").attr("Checked","Checked");
					document.getElementById("cd-radio-1").checked = true;
					$("#NonFixedINRDiv").show();
					$("#fixedINRDiv").hide();
				} 
				else 
				{
					//$("#cd-radio-2").attr("Checked","Checked");
					document.getElementById("cd-radio-2").checked = true;
					$("#NonFixedINRDiv").hide();
					$("#fixedINRDiv").show();
				}
			}			
			//Modified On 29012017 End-----------------------------------------------------
			if(remtype == 2)
			{
				if(p_bool == "true")
				{
					$("[name='txnAmount']").val(info[4]);
					$("[name='productIDVal']").val(info[8]);
					$("[name='txnFixedAmount']").val(info[2]);
					debugger;
					$("#compute123").text(info[4]+" "+info[9]);
					$("#compute345").text(info[2]);
				}
				else
				{
					$("[name='txnAmount']").val(info);
					$("#compute123").text(info[4]+" "+info[9]);
					$("#compute345").text(info[2]);
				}
			}	
			else
			{
				if(p_bool == "true")
				{
					$("[name='txnFixedAmount']").val(info[4]);
					debugger;
					$("[name='productIDVal']").val(info[8]);
					$("[name='txnAmount']").val(info[2]);
					$("#compute123").text(info[2]+" "+info[9]);
					$("#compute345").text(info[4]);
				}
				else
				{
					$("[name='txnFixedAmount']").val(info); 
					debugger;
					$("#compute123").text(info[2]+" "+info[9]);
					$("#compute345").text(info[4]);
				}
			}
			
			if(remtype == 2)
			{
				
				if(p_bool == "true")
				{
					var flag = info[5];
					$("#excCurrID").text(info[9]);
					$("#exchangRT").text(info[0]+' INR');
					var brkData ="No Data";
					//alert("flag>>>>>>>>>>>"+flag);
					if(flag == "false")
					{
						$("#abcd").empty();
						if(l_country == 'USA'||l_country == 'CAN')
						{	
							$("#totalAmount")
							brkData =  "<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remitance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div>"+
							/*"<%-- <div class=\"particular\"> <span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> --%>"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Actual Amount For Remitter [a/c]+b:</span> <span></span> <span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";
							
							
							
						}
						else
						{
							brkData ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remitance Service Charge (c) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Exchange Rate (d):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Actual Amount For Remitter [(a+b)/d]+c:</span> <span></span><span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+' '+ info[9]);
						 $(brkData).appendTo("#abcd");
						
					}
					
					else if(flag == "true")
					{
						$("#abcd").empty();
						if(l_country == 'USA'||l_country == 'CAN')
						{
							brkData =  "<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span></span>Conversion Service Tax (b): <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">" +
							"<span>Remitance Service Charge (b) :</span>  <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							"<span>Exchange Rate (c):</span> <span></span>  <span>"+info[0]+" INR</span>"+
							"</div><div class=\"particular\">"+
							"<span>Transfer Amount (a+b):</span> <span></span>  <span>"+info[10]+' '+info[9]+"</span>"+
							"</div>"+
							/*"<!-- <div class=\"particular\"><span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> -->"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Amount For Receiver [a*c]:</span> <span></span><span>"+info[4]+" INR</span>"+
							"</div>";
						}
						else
						{
							brkData ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Conversion Service Tax (b):</span> <span></span><span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remitance Service Charge (c) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Exchange Rate (d):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Transfer Amount (a+c):</span> <span></span> <span>"+info[10]+' '+info[9]+"</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Amount For Receiver [(a*d)-b]:</span> <span></span><span>"+info[4]+" INR</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+" INR");
						 $(brkData).appendTo("#abcd");
						
					}	
				}
				
			}
			else
			{ 	
				if(p_bool == "true")
				{
					var flag = info[5];
					var brkData2 = "N";
					$("#excCurrID").text(info[9]);
					$("#exchangRT").text(info[0]+' INR');
					//alert("flag>>>>>>>>>>>"+flag);
					$("#abcd").empty();
					if(flag == "false")
					{
						if(l_country == 'USA'||l_country == 'CAN')
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"particular\">"+
							"<span>Transfer Amount (a+b):</span> <span></span> <span>"+info[10]+' '+info[9]+"</span>"+
							"</div>"+
							/*"<!-- <div class=\"particular\"><span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> -->"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Indicative Amount for receiver [a*c]:</span> <span></span> <span>"+info[4]+" INR</span>"+
							"</div>";
						}
						else
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span><span>"+info[2]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (c) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (d):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Transfer Amount (a+c):</span> <span></span> <span>"+info[10]+' '+ info[9]+"</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Indicative Amount for receiver [(a*d)-b]:</span> <span></span> <span>"+info[4]+" INR</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+" INR");
					}
					else if(flag == "true")
					{
						if(l_country == 'USA'||l_country == 'CAN')
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (b) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (c):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div>"+
							/*"<%-- <div class=\"particular\"> <span>Transfer Tax (e):</span> <span></span> <span>"+info[7]+' '+info[9]+"</span></div> --%>"+*/
							"<div class=\"billpay-total-amt\">"+
							"<span>Actual Amount For Remitter [a/c]+b:</span> <span></span> <span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";;
						}
						else
						{
							brkData2 ="<div class=\"particular\">"+
							"<span>Transaction Amount (a):</span> <span></span> <span>"+ info[2] +" INR</span>"+
							"</div><div class=\"particular\">"+
							/*"<%-- <span>Indicative Conversion Service Tax (b):</span> <span></span> <span>"+info[1]+" INR</span>"+*/
							"</div><div class=\"particular\">"+
							"<span>Remittance Service Charge (c) :</span> <span></span> <span>"+info[11]+' '+ info[9]+"</span>"+
							"</div><div class=\"particular\">" +
							"<span>Indicative Exchange Rate (d):</span> <span></span> <span>"+info[0]+" INR</span>"+
							"</div><div class=\"billpay-total-amt\">"+
							"<span>Indicative Amount for remitter [(a+b)/d]+c:</span> <span></span> <span>"+info[4]+' '+ info[9]+"</span>"+
							"</div>";
						}
						$("#totalAmount").text(info[4]+" "+info[9]);
						
					}
					$(brkData2).appendTo("#abcd");
				}	
			}
		}else
		{
			alert("Exchange Rate is not Available for this Amount");
			if(p_remtype == 2)
			{                             
				$("[name='txnAmount']").val("0.00");		                     
			}else
			{
				$("[name='txnFixedAmount']").val("0.00");                        	                         
			}
			$("#txnamount").text('0.0 INR');
			$("#txnserfee").text('0.0 USD');
			$("#sertax").text('0.0 INR');
			$("#exchngrt").text('0.0 INR');
			$("#totalamt").text('0.0 USD');
			$("#totalAmount").text('0.0 USD');
		} 						
	}//Callback function end
	//calculate function end here


} 

function validateAmountReq()
{
	var total = parseFloat($("[name='txnAmount']").val()); 
	var totalFixed = parseFloat($("[name='txnFixedAmount']").val()); 
	debugger;
	var rad_val = "NONINR";	     
	if(prodCode == "3")
		rad_val=$("input[name='fixedInr']:checked").val();
	else if(prodCode == "2")
		rad_val = "INR";	
	else	
		rad_val = "NONINR";    
	if(rad_val == 'NONINR' && (total == null || isNaN(total)  || !IsNumeric(total)))
		return true;     
	else if(rad_val == 'INR' && (totalFixed == null || isNaN(totalFixed) ||
			!IsNumeric(totalFixed)))
		return true;

	return false;
}
function validateReqNoOfTime()
{    	   
	if( $("input[name='isRecurring']:checked").val() == "Y")
	{
		if($("input[name='fromdatepicker1']").val()=="")
		{
			alert("Please enter start date");
			return false;
		}
		if($("input[name='frequency']:checked").val()!= "one" )						
		{
			if($("input[name='noOfTimeType']:checked").val() == "date"
				&& $("[name='todatepicker1']").val()=="")
			{
				alert("Please enter End by date");
				return false;
			}
			if($("input[name='noOfTimeType']:checked").val()=="number"
				&& $("[name='noOfTime']").val()=="")
			{
				alert("Please Enter Numeric value for End After");
				return false;
			}						
		} 	                            
	}
	return true;        
}

function setDisable()
{			
	if($("input[name='frequency']:checked").val() != "one")
	{    
		$("#endById").show();    
		$("#endAfterId").show();  					  	
	}else{                 
		$("#endById").hide();    
		$("#endAfterId").hide()               
	}   
	$("input[name='frequency']").parent().attr("class", "bC_Over");
	$("input[name='frequency']:checked").parent().attr("class", "");

	$("input[name='frequency']").parent().next().attr("class", "bC_Over");
	$("input[name='frequency']:checked").parent().next().attr("class", "");
}
function hidethisrow()
{		 
	if(prodCode == "3")
	{
		if($("input[name='fixedInr']:checked").val()=="NONINR")
		{
			exchageAmount();
			$("#hiderow").show();
			$("#hiderow1").fadeIn("slow");			
			$("#hiderow2").hide();
			$("#hiderow3").fadeOut("slow");  
		}
		else if($("input[name='fixedInr']:checked").val()=="INR")
		{
			exchageFixedAmount();
			$("#hiderow").hide();
			$("#hiderow1").fadeOut("slow");		
			$("#hiderow2").show();
			$("#hiderow3").fadeIn("slow");                
		}
		else
		{
			$("#hiderow").hide();
			$("#hiderow1").hide();
			$("#hiderow2").hide();
			$("#hiderow3").hide();		

		}
		$("#NonFixedINRDiv").show();
		$("#fixedINRDiv").show();
	}   
	else  if(prodCode == "2")
	{		exchageFixedAmount();  							
	$("#hiderow").hide();
	$("#hiderow1").hide();			
	$("#hiderow2").show();
	$("#hiderow3").show();		
	$("#NonFixedINRDiv").hide();
	$("#fixedINRDiv").hide();								
	selectFDTypes("INR");							
	}
	else
	{		exchageAmount();
	$("#hiderow").show();
	$("#hiderow1").show();				
	$("#hiderow2").hide();
	$("#hiderow3").hide();				
	$("#NonFixedINRDiv").hide();
	$("#fixedINRDiv").hide();
	selectFDTypes("NONINR");							
	}

}
function hidethisdiv()
{ 		
	if(objFrm.isRecurring[0]!=null)
	{
		if(objFrm.isRecurring[0].checked==true)            
			$("#hidethisdiv").slideUp("slow"); 				
		else if(objFrm.isRecurring[1].checked==true)
			$("#hidethisdiv").slideDown("slow");				 				            
	}
}

/* $(function() {
         //$("#fromdatepicker1").datepicker({showOn: 'both',buttonImage: 'js/jquery/images/calendar.gif', buttonImageOnly: true, dateFormat:'dd-M-yy'});
        // $("#todatepicker1").datepicker({showOn: 'both',buttonImage: 'js/jquery/images/calendar.gif', buttonImageOnly: true, dateFormat:'dd-M-yy'});
           setDisable(); });*/

function hidetxt_new()
{		$("#txt_tog").html('<a href="javascript:void(0);" onclick="javascript:showtxt_new();"><img src="images/m2w/regdArw_01.gif" width="12" height="11" class="FL" /></a>&nbsp;To proceed with your money transfer, please select the account you want to transfer from and the receiver you want to send money to.');
$("#hide_tab1").hide();
$("#txt_tog").css('backgroundColor:#f5f4e9','border:#f5f4e9','padding:1px'); 		
}
function showtxt_new()
{		$("#hide_tab1").show();
$("#txt_tog").html('<a href="javascript:void(0);" onclick="javascript:hidetxt_new();"><img src="images/m2w/regdArw_03.gif" width="12" height="11"/></a>&nbsp;To proceed with your money transfer, please select the account you want to transfer from and the receiver you want to send money to.');
$("#txttog1").css('backgroundColor:#f5f4e9','border:#f5f4e9','padding:1px');			
}
function ChangeStatus1(img)
{	 var imgSrc;
var splitArray;
splitArray = new Array;
imgSrc = eval("document.images['chk"+img+"'].src")
splitArray = imgSrc.split('/');
if(splitArray[splitArray.length-1]=="UnChecked.gif")
{	 eval("document.images['chk"+img+"'].src = 'images/Checked.gif'");
$("[name='agreeTerms1']").val("Y");
//document.etTranRemiTxn.agreeTerms1.value="Y";
}
else
{	 eval("document.images['chk"+img+"'].src = 'images/UnChecked.gif'");
$("[name='agreeTerms1']").val("N");
//document.etTranRemiTxn.agreeTerms1.value="N";
}
}
function ChangePrefStatus(img)
{	 var imgSrc;
var splitArray;
splitArray = new Array;
imgSrc = eval("document.images['chk"+img+"'].src")
splitArray = imgSrc.split('/');
if( $("[name='txnAmount']").val()=="")
{
	alert("Please Enter Transaction Amount");
}
else
{
	if( parseFloat($("[name='txnAmount']").val())<parseFloat($("[name='minfcamt']").val()))
	{
		alert("To avail the Preferential Rate offer, transaction amount should be "+$("[name='prefFC']").val()+ " " +parseFloat($("[name='minfcamt']").val())+ " or above");

	}
	else
	{
		if(splitArray[splitArray.length-1]=="UnChecked.gif")
		{	 eval("document.images['chk"+img+"'].src = 'images/Checked.gif'");
		$("[name='prefRate']").val("Y");
		//document.etTranRemiTxn.agreeTerms1.value="Y";
		}
		else
		{	 eval("document.images['chk"+img+"'].src = 'images/UnChecked.gif'");
		$("[name='prefRate']").val("N");
		//document.etTranRemiTxn.agreeTerms1.value="N";
		}
	}
}
}

function ChangePrefStatusFixed(img){
	var imgSrc;
	var splitArray;
	splitArray = new Array;
	var productId = objFrm.productId.value;
	var fixedInrRad = "NONINR";
	var txnFixedAmount = 0;
	if(prodCode == "3")
		fixedInrRad=$("input[name='fixedInr']:checked").val();
	else if(prodCode == "1")
		fixedInrRad = "NONINR";
	else			
		fixedInrRad = "INR";

	if(prodCode == "2" || prodCode == "3")
	{
		var totalFixed = parseFloat( $("[name='txnFixedAmount']").val());	                
		if(fixedInrRad == "INR" && !IsNumeric($("[name='txnFixedAmount']").val()) 
				&& $("[name='txnFixedAmount']").val().length>0)
		{
			alert("Please enter numeric amount value");
			$("#totalFixed").html("0.00");
			$("[name='txnFixedAmount']").val("");
			return false;
		}
		var txnFixedAmount = parseFloat($("[name='txnFixedAmount']").val());
		if(isNaN(txnFixedAmount))
		{
			if($.trim($("[name='txnFixedAmount']").val()) == "")
				txnFixedAmount=slabFromFixed;				
			else
			{
				alert("Please enter numeric amount value");
				$("#total").html("0.00");
				$("[name='txnFixedAmount']").val(""); 
				return false;
			}
		}
		else
			$("[name='txnFixedAmount']").val($.trim($("[name='txnFixedAmount']").val()));  
		debugger;
		if(parseFloat($("[name='txnFixedAmount']").val()) < 0)
		{
			alert("Please enter non negative amount value");
			$("#totalFixed").html("0.00");               
			$("[name='txnFixedAmount']").val("");                
			return false;
		}
	}
	if(prodCode == "1" || prodCode == "3")
	{
		var txnAmount = parseFloat($("[name='txnAmount']").val());
		if(fixedInrRad == "NONINR" && !IsNumeric($("[name='txnAmount']").val()) 
				&& $("[name='txnAmount']").val().length>0)
		{
			alert("Please enter numeric amount value");
			$("#total").html("0.00");           
			$("[name='txnAmount']").val("");
			return false;
		}
		if(isNaN(txnAmount))
		{
			if($.trim($("[name='txnAmount']").val()) == "")
				txnAmount=slabFrom;				  
			else
			{
				alert("Please enter numeric amount value");
				$("[name='txnAmount']").val("");
				return false;
			}
		}	
		else
			$("[name='txnAmount']").val($.trim($("[name='txnAmount']").val()));   

		if(parseFloat($("[name='txnAmount']").val()) < 0)
		{
			alert("Please enter non negative amount value");
			$("[name='txnAmount']").val("");
			return false;
		}
	}	  
	/*alert("exchangeRateCalculator?productId="+productId+"&&txnAmount="+txnAmount+"&&txnFixedAmount="+txnFixedAmount+"&&fixedInr="+fixedInrRad+"&&deliveryMode=200001");*/	  
	fixedInrRad=((fixedInrRad=='NONINR')?'N':'Y');	 
	$.ajax( {
		type: "POST",
		cache:false, 	
		url:"exchangeRateCalculator?productId="+productId+"&&txnAmount="+txnAmount+"&&txnFixedAmount="+txnFixedAmount+"&&fixedInr="+fixedInrRad+"&&deliveryMode=200001",
		data: {},
		dataType: "text",			  
		success:CallBackName,
		error  : errorFunction
	} ) ;



	//CallBack function start here i.e. this function within function	
	function CallBackName(data)
	{      
		var info=data;					
		var r=info.split("##");
		if(info!="")
		{
			var r=info.split("##");						 
			if(fixedInrRad == "N")
			{
				$("#cardRate").html(r[4]);
				$("#total").html((parseFloat(r[4]) *
						$("[name='txnAmount']").val()).toFixed(2));                          
			}
			else
			{ 	                    	  
				$("#cardFixedRate").html(r[4]);	
				$("#totalFixed").html(($("[name='txnFixedAmount']").val()/parseFloat(r[4])).toFixed(2));
debugger;
			}
		}else
		{
			alert("Exchange Rate is not Available for this Amount");
			if(fixedInrRad == "N")
			{
				$("#cardRate").html("0.00");
				$("#total").html("0.00");                                
				$("[name='txnAmount']").val("");		                     
			}else
			{
				$("#cardFixedRate").html("0.00");
				$("#totalFixed").html("0.00");
				$("[name='txnFixedAmount']").val("");                        	                         
			}		
		} 
		imgSrc = eval("document.images['chk"+img+"'].src")
		splitArray = imgSrc.split('/');

		/*	if( $('#totalFixed').html()=="0.00")
		 {
			 	alert("Please Enter Transaction Amount");
		 }
		 else
		 {
			 if( parseFloat($('#totalFixed').html())<parseFloat($("[name='minfcamt']").val()))
			 {
				 alert("To avail the Preferential Rate offer, transaction amount should be "+$("[name='prefFC']").val()+ " " +parseFloat($("[name='minfcamt']").val())+ " or above");

			 }
			 else
			 {*/
		if(splitArray[splitArray.length-1]=="UnChecked.gif")
		{	 eval("document.images['chk"+img+"'].src = 'images/Checked.gif'");
		$("[name='prefRate']").val("Y");
		//document.etTranRemiTxn.agreeTerms1.value="Y";
		}
		else
		{	 eval("document.images['chk"+img+"'].src = 'images/UnChecked.gif'");
		$("[name='prefRate']").val("N");
		//document.etTranRemiTxn.agreeTerms1.value="N";
		}
		// }
		// }

	}
}

function changeStatusPref(img)
{

	//alert($("[name='rateCust']").val());
	if($("[name='rateCust']").val()=='Y')
	{
		var imgSrc;
		var splitArray;
		splitArray = new Array;
		imgSrc = eval("document.images['chk"+img+"'].src")
		splitArray = imgSrc.split('/');
		if( parseFloat($("[name='txnAmount']").val())<parseFloat($("[name='minfcamt']").val()))
		{

			alert("To avail the Preferential Rate offer, transaction amount should be "+$("[name='prefFC']").val()+ " " +parseFloat($("[name='minfcamt']").val())+ " or above");
			eval("document.images['chk"+img+"'].src = 'images/UnChecked.gif'");
			$("[name='prefRate']").val("N");
		}		
	}			 

}
function changeStatusPref1(img)
{ 

	// alert($("[name='rateCust']").val());
	if($("[name='rateCust']").val()=='Y')
	{
		var imgSrc;
		var splitArray;
		splitArray = new Array;


		var productId = objFrm.productId.value;
		var fixedInrRad = "NONINR";
		var txnFixedAmount = 0;
		if(prodCode == "3")
			fixedInrRad=$("input[name='fixedInr']:checked").val();
		else if(prodCode == "1")
			fixedInrRad = "NONINR";
		else			
			fixedInrRad = "INR";

		if(prodCode == "2" || prodCode == "3")
		{
			var totalFixed = parseFloat( $("[name='txnFixedAmount']").val());	                
			if(fixedInrRad == "INR" && !IsNumeric($("[name='txnFixedAmount']").val()) 
					&& $("[name='txnFixedAmount']").val().length>0)
			{
				alert("Please enter numeric amount value");
				$("#totalFixed").html("0.00");
				$("[name='txnFixedAmount']").val("");
				return false;
			}
			var txnFixedAmount = parseFloat($("[name='txnFixedAmount']").val());
			if(isNaN(txnFixedAmount))
			{
				if($.trim($("[name='txnFixedAmount']").val()) == "")
					txnFixedAmount=slabFromFixed;				
				else
				{
					alert("Please enter numeric amount value");
					$("#total").html("0.00");
					$("[name='txnFixedAmount']").val(""); 
					return false;
				}
			}
			else
				$("[name='txnFixedAmount']").val($.trim($("[name='txnFixedAmount']").val()));  
			debugger;
			if(parseFloat($("[name='txnFixedAmount']").val()) < 0)
			{
				alert("Please enter non negative amount value");
				$("#totalFixed").html("0.00");               
				$("[name='txnFixedAmount']").val("");                
				return false;
			}
		}
		if(prodCode == "1" || prodCode == "3")
		{
			var txnAmount = parseFloat($("[name='txnAmount']").val());
			if(fixedInrRad == "NONINR" && !IsNumeric($("[name='txnAmount']").val()) 
					&& $("[name='txnAmount']").val().length>0)
			{
				alert("Please enter numeric amount value");
				$("#total").html("0.00");           
				$("[name='txnAmount']").val("");
				return false;
			}
			if(isNaN(txnAmount))
			{
				if($.trim($("[name='txnAmount']").val()) == "")
					txnAmount=slabFrom;				  
				else
				{
					alert("Please enter numeric amount value");
					$("[name='txnAmount']").val("");
					return false;
				}
			}	
			else
				$("[name='txnAmount']").val($.trim($("[name='txnAmount']").val()));   

			if(parseFloat($("[name='txnAmount']").val()) < 0)
			{
				alert("Please enter non negative amount value");
				$("[name='txnAmount']").val("");
				return false;
			}
		}	  
		/*alert("exchangeRateCalculator?productId="+productId+"&&txnAmount="+txnAmount+"&&txnFixedAmount="+txnFixedAmount+"&&fixedInr="+fixedInrRad+"&&deliveryMode=200001");*/	  
		fixedInrRad=((fixedInrRad=='NONINR')?'N':'Y');	 
		$.ajax( {
			type: "POST",
			cache:false, 	
			url:"exchangeRateCalculator?productId="+productId+"&&txnAmount="+txnAmount+"&&txnFixedAmount="+txnFixedAmount+"&&fixedInr="+fixedInrRad+"&&deliveryMode=200001",
			data: {},
			dataType: "text",			  
			success:CallBackName,
			error  : errorFunction
		} ) 
		return true;
		//CallBack function start here i.e. this function within function	
		function CallBackName(data)
		{      
			var info=data;					
			var r=info.split("##");
			if(info!="")
			{
				var r=info.split("##");						 
				if(fixedInrRad == "N")
				{
					$("#cardRate").html(r[4]);
					$("#total").html((parseFloat(r[4]) *
							$("[name='txnAmount']").val()).toFixed(2));                          
				}
				else
				{ 	                    	  
					$("#cardFixedRate").html(r[4]);	
					$("#totalFixed").html(($("[name='txnFixedAmount']").val()/parseFloat(r[4])).toFixed(2));
				}
			}else
			{
				alert("Exchange Rate is not Available for this Amount");
				if(fixedInrRad == "N")
				{
					$("#cardRate").html("0.00");
					$("#total").html("0.00");                                
					$("[name='txnAmount']").val("");		                     
				}else
				{
					$("#cardFixedRate").html("0.00");
					$("#totalFixed").html("0.00");
					$("[name='txnFixedAmount']").val("");                        	                         
				}		
			} 

			imgSrc = eval("document.images['chk"+img+"'].src")
			splitArray = imgSrc.split('/');
			var presj=$('#totalFixed').html();
			// alert('presj-->'+presj);
			// alert('prajkta-->'+parseFloat($("[name='txnFixedAmount']").val()));

			if(presj=="0.00")
			{
				alert("Please Enter Transaction Amount");
			}
			else
			{ 
				if(parseFloat(presj)<parseFloat($("[name='minfcamt']").val()))
				{
					//if(!(presj=='0.00' && !(parseFloat($("[name='txnFixedAmount']").val()==""))))
					//{
					alert("To avail the Preferential Rate offer, transaction amount should be "+$("[name='prefFC']").val()+ " " +parseFloat($("[name='minfcamt']").val())+ " or above");
					eval("document.images['chk"+img+"'].src = 'images/UnChecked.gif'");
					$("[name='prefRate']").val("N");
					// }	
				} }					
		}//Callback function end
		//calculate function end here


	}			 

}  	

function popUpInfo()
{	
	window.open("http://www.icicibank.com/Pfsuser/icicibank/ibank-nri/"+
	"nrinewversion/popup/popup_moneytransfer_service_tax.htm");		
}

/*	function takeValue(val)
	{    
		if(objFrm.remiAccountId && objFrm.remiAccountId.selectedIndex>0 
			&& objFrm.beneficiaryId && objFrm.beneficiaryId.selectedIndex>0 )
			{ 
				objFrm.action=actionDetail;
				objFrm.submit();
			}
	}
	commented for Express CAD */
function validatePromoCode(data)
{

	var regAlphaNum =/^[\w\s]+$/i;
	return data.match(regAlphaNum);

}
