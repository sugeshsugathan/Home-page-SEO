/*
 * Copyright 2010, Wen Pu (dexterpu at gmail dot com)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * Check out http://www.cs.illinois.edu/homes/wenpu1/chatbox.html for document
 *
 * Depends on jquery.ui.core, jquery.ui.widiget, jquery.ui.effect
 *
 * Also uses some styles for jquery.ui.dialog
 *
 */


if (window.location.protocol == "https:") {
	baseURL = "https://";
} else {
	baseURL = "http://";
}

var BASEURL = baseURL+"iciciworkflow1.icicibank.com/ChatEngine/";

//var BASEURL = "./";

var prev = 0;
var callCount = 0;
var dataType = "msg";
var assetsUrl = BASEURL+"generic_assets";
var count = 0;
var USERNAME = "";
var KEY = "";
var showICICI_TnC = true,
   // instructions_ICICI = "You will now be directed to an automated chat service. During the chat session, if you wish to use the Additional Help facility at any point of time, kindly click on <b>'Additional Help'</b> icon at the bottom of the chat window.";

    instructions_ICICI   = 'This is an automated chat service. '+
       'The chat service assists the Customer/User in addressing generic queries related to Money2India. '+
       ' The User agrees and understands that since this is a completely automated chat service, '+
       'the accuracy of responses may not be 100% and that responses shall be provided only to generic queries '+
       'and not account/transaction related queries. User is advised not share any confidential information such '+
       'as debit/credit card numbers, ATM PIN, Account Number etc. on the chat window. The User hereby agrees '+
       'and confirms that ICICI Bank shall not be liable for any loss that might occur to the User due to use of '+
       'this service. The User shall not use abusive or offensive language on this chat service. <br><br>'+
        	   'At any time during the chat, if the User wishes to seek additional help, '+
        	   'he/she may click on the \'Additional Help\' icon at the bottom of the chat window. The User unconditionally '+
        	   ' agrees that all communication on this chat service shall be recorded for internal feedback.'
        	   
     instructions_ICICI_small = instructions_ICICI.substring(0,506);   	   

var ICICI_ContactLink =  'https://www.icicibank.com/nri-banking/RHStemp/contact-us.page';

var fiveMinute = 1000*5*60;
var tenMinute  = 1000*10*60;

var timeOut,chatEnd;

function callTimeOuts(){
  clearTimeout(timeOut)
  startTimeout();
  clearTimeout(chatEnd)
  endChat();
}


function fullInstShow(){
	$("#inst-small").html(instructions_ICICI);
}

function doHandoff(){
	if(KEY){
		$.ajax({
	        url: ""+BASEURL+"dohandoff?key="+KEY,
	        type: "GET",
	        xhrFields: {withCredentials: true},
	        success: function(data) {
	        	
	        } 
		})
   }
}

function endChat(){
    chatEnd  = setTimeout(function(){
      /*console.log('Ending chat')
        $('.ui-chatbox-msg-server').remove();
        $('.ui-chatbox-msg-user').remove();
        $('.optionsDiv').remove();
        $('.minimize-minus').click();*/
        /*$("#chat_div")
        .chatbox("option", "boxManager")
        .addMsg('AIRA', 'Hello, I am ICICI Bank\'s Chatbot');*/
    	/*$("#chat_div")
        .chatbox("option", "boxManager")
        .addMsg('AIRA', 'Chat session ended');*/
    	clearTimeout(timeOut)
    	clearTimeout(chatEnd)
        //callTimeOuts();

      //clearTimeout(chatEnd)
     },tenMinute)
}

function startTimeout(){
   timeOut = setTimeout(function(){
        $("#chat_div")
            .chatbox("option", "boxManager")
            .addMsg('Aira', 'You haven\'t chatted with us for a while. How may I assist you?');   
    },fiveMinute)
}

function getCurrentTime() {
    var date = new Date();
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; 
        minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;

    return strTime;
}

function showThinkingGif(){
   $("#chat_div")
     .append("<span class='thinkingGif ui-chatbox-msg-server'>"+
         "<span class='torso torso-server'></span>"+
         "<img src='"+assetsUrl+"/Chat-Window-Assets-Chatbot-Is-Typing.png'></span>")
}

function downloadChat(self){
   var downloadDataStr = " ";
   var ques = $('.ui-chatbox-msg-user')
   var ans  = $('.ui-chatbox-msg-server')

  $.each(ques,function(i,e){
      ++i;
      downloadDataStr = downloadDataStr+' \n ' + 'Ques '+i+': '+e.innerText+' \n '+ans[+i].innerText+'\n';
  })

   var blob = new Blob([downloadDataStr],{type: 'text/plain'});

   /*var target = $(self).children('a');
       target.href = window.URL.createObjectURL(blob);
       target.download = 'chat_transcript';*/

     var a = document.createElement('a');
       a.href = window.URL.createObjectURL(blob);;
       a.style = "visibility:hidden";
       a.download = 'chat_transcript.txt';
     document.body.appendChild(a);
         a.click();
     document.body.removeChild(a);
}

function jsonToHtml(jsonArray,type){
  var ret="";

  if(typeof jsonArray == 'object'){
    if(type=="action" && jsonArray.length != 0){
        $.each(jsonArray,function(key,val){
           ret = ret +'<span class="action-elem">'+val.link+ '</span>'         
        })
    }  
    if(type=="disamb" && jsonArray.length != 0){
        ret = '<span class="disamb-header">You may also want to know</span>';
        $.each(jsonArray,function(key,val){
           ret = ret +'<span class="disamb-elem">'+ val.link+' </span>'         
        })
    } 

  }/*else{
     ret  = ('<span>'+jsonArray+'</span>')
  }*/

  return ret;
}

function autosubmit(submittext)
{
  
  $(".ui-chatbox-input-box").val(submittext);
  var e = $.Event('keydown', { keyCode: 13 });
  $('.ui-chatbox-input-box').trigger(e);
  
}

function getFeedback(bool,ev,key,self) {
    ev.preventDefault();
    $.ajax({
        url: ""+BASEURL+"update?key=" + key + "&accept=" + bool,
        type: "GET",
        xhrFields: {withCredentials: true},
        success: function(data) {
          if(bool){
            $(self).siblings('img').attr('src',assetsUrl+'/thumbs-down.png');
            $(self).attr('src',assetsUrl+'/thumbs-up-filled.png');
             createComment(self,key,'Positive');
          }else{
            $(self).siblings('img').attr('src',assetsUrl+'/thumbs-up.png');
            $(self).attr('src',assetsUrl+'/thumbs-down-filled.png');
            createComment(self,key,'Negative');
          }
        }
    });
}

function sendComment(comment,key,type){
	if(comment.length > 0){
	$.ajax({
        url: ""+BASEURL+"savecomment?comment="+comment+"&key="+key+"&type="+type,
        type: "GET",
        xhrFields: {withCredentials: true},
        success: function(data) {
        	
        } 
	})
  } 
}

function createComment(target,key,type){
	var _old_scroll_height = document.getElementById('chat_div').scrollHeight;
	
	$('.comment').remove();
	var div = $(target).closest('.time-stamp');
	   
	//var ques = $(div).children("span:first-child").text();
	//console.log(ques)
	
	var outer = $("<div class='comment'><p>Feedback box</p><input placeholder='Type here to share your feedback' id='comment-input' type='text' maxlength='1000' >")
	var btn   = $('<button>></button> </div>').click(function(){
		var res = $(outer).find('#comment-input').val();
		outer.remove();
		sendComment(res,key,type);
	})
	var closeComment = $("<span class='close-comment'>X</span>").click(function(ev){
		    outer.remove();
	     })
	    .appendTo(outer)
	    
	outer.append(btn);
	div.append(outer);
	
	var _new_scroll_height = document.getElementById('chat_div').scrollHeight;

	var _increase = _new_scroll_height - _old_scroll_height;
	if( _increase > 0){
		$('#chat_div').scrollTop( _new_scroll_height )
	}
	
	callSlimScroll();
}

function toVhVw(arg) {
    if (arg.toString().endsWith('vw')) 
        return ( (window.innerWidth / 100) * arg.toString().split('v')[0]);
    else 
        return ( (window.innerHeight / 100) * arg.toString().split('v')[0]);
}

(function($) {
    $.widget("ui.chatbox", {
        options: {
            id: null, 
            title: null, 
            user: null, 
            hidden: false,
            offset: 0, 
            /*width: 300, */
           /* height: 600,*/
            messageSent: function(id, user, msg) {
                this.boxManager.addMsg(user.first_name, msg);
            },
            boxClosed: function(id) {}, 
            boxManager: {
                init: function(elem) {
                    this.elem = elem;
                },
                addMsg: function(peer, msg , key) {
                	KEY = key;
                    var self = this;
                    var feedbackShort = '<span style="margin-right: -16px;"> &nbsp <img style="float:right" src='+assetsUrl+'/thumbs-up.png onClick="getFeedback(true,event,'+key+',this)"> &nbsp <img style="float:left" src='+assetsUrl+'/thumbs-down.png onClick="getFeedback(false,event,'+key+',this)"> </span';
                    var feedbackFull = '<span style="font-size: 12px;">Was this information useful ? '+feedbackShort+'</span>';

                    var brandText = $("<div class='brandtext'>ICICI Bank Chat</div>")
                    
                    var box = self.elem.uiChatboxLog;
                    var e = document.createElement('div');
                    var dttm = $(document.createElement('div')).addClass("time-stamp").html(getCurrentTime);
                    box.append(e);

                   /* $(e).hide();*/

                    var systemMessage = false;

                    var msgElement = document.createElement(
                        systemMessage ? "i" : "span");
                     

                    var torso = document.createElement("div");
                                torso.className = "";
                                
                    callCount++;
                    if (peer == 'Me'){
                        $(e).addClass("ui-chatbox-msg-user");
                        torso.className  = 'torso torso-user';
                        
                        if(msg.indexOf('>')){
                          msg = msg.substring(msg.lastIndexOf('>')+1 , msg.length);
                        }
                        
                        $(msgElement).append(msg);
                        e.appendChild(msgElement);
                        $(e).append(dttm);

                        callTimeOuts();
                    }
                    else{
                      //$(e).hide();
                    	$(msgElement).prepend(brandText)
                        $(e).addClass("ui-chatbox-msg-server");
                        torso.className = 'torso torso-server';
                        
                        var optionsDiv = $("<div></div>").addClass("optionsDiv")
                       if(typeof msg == 'object'){
                            $(msgElement).append(msg.answer.trim())
                            
                            if('disamb' in msg && msg.disamb.length > 0 ){
                            
                               var jsonData = $('<div class="disamb">'+jsonToHtml(msg.disamb,"disamb")+'</div>');
                               $(jsonData).append(dttm);
                               optionsDiv.append(jsonData);
                               box.append(optionsDiv); 
                            }else{
                               //$(e).append(dttm)
                            }

                            jsonData = "";  
                            if('action' in msg && msg.action.length > 0){     
                            
                               jsonData = $('<div class="action">'+jsonToHtml(msg.action,"action")+'</div>');
                                 //$(jsonData).append(dttm);
                               optionsDiv.append(jsonData);
                               box.append(optionsDiv);
                            }
                            $(e).append(msgElement);
                            $(e).append(dttm);

                       }else{
                            $(msgElement).append(msg);
                            $(e).prepend(msgElement);
                            $(e).append(dttm);
                       }

                        if(callCount == 3){
                        	$('.sfBottomElem').removeClass('sfBottomElem');
							/*Just a workaround*/
							callCount = 5; 
                        	/*
                        	if( typeof msg == 'object' && 'showfeedback' in msg && msg.showfeedback == true ){
                              dttm.append($('<span style="float:right;">'+feedbackFull+'</span>'));
                        	}else if(typeof msg == 'object' &&  'showfeedback' in msg && msg.showfeedback == false ){
                        		//
                        	}else if(typeof msg == "string"){
                        	   //
                        	}else{
                        		dttm.append($('<span style="float:right;">'+feedbackFull+'</span>'));
                                $('.sfBottomElem').removeClass('sfBottomElem');
                        	}*/
                        }
						
                        if(callCount > 3){
                        	if( typeof msg == 'object' &&  'showfeedback' in msg && msg.showfeedback == true ){
                        	  dttm.append($('<span>'+feedbackShort+'</span>'));
                        	}else if(typeof msg == 'object' &&  'showfeedback' in msg && msg.showfeedback == false ){
                        		//
                        	}else if(typeof msg == "string"){
                        	   //
                        	}else{
                        		dttm.append($('<span>'+feedbackShort+'</span>'));
                        	}
                        } 
                      

                    }
                    $(e).append(torso);
                    if(peer == 'Me'){
                       $(e).fadeIn();
                       showThinkingGif();
                    }else{
                       $(".thinkingGif").remove();
                       $(e).fadeIn(); //$(e).show();
                       count++;
                   	   if(count > 1)lessMore(msgElement);
                    }
                    
                    $("#chat_div").animate({ scrollTo: $(e).position().top }, 1000);
                    self._scrollToBottom(peer);
                    callSlimScroll(); 

                    if (!self.elem.uiChatboxTitlebar.hasClass("ui-state-focus") && !self.highlightLock) {
                        self.highlightLock = true;
                        self.highlightBox();
                    }
                },
                highlightBox: function() {
                   /* var self = this;
                    self.elem.uiChatboxTitlebar.effect("highlight", {}, 300);
                    self.elem.uiChatbox.effect("slide", { direction: 'down' }, 500, function() {
                        self.highlightLock = false;
                        self._scrollToBottom();
                    });*/
                },
                toggleBox: function() {
                    if(USERNAME.length  > 0)
                       this.elem.uiChatbox.toggle();
                    else 
                       $('.TnC_Window').show();
                },
                _scrollToBottom: function(peer) {
                    var box = this.elem.uiChatboxLog;
                    var t = box.get(0).scrollHeight;
                    var h = box.get(0).lastElementChild.clientHeight;

                    if (peer == 'Me') {
                        box.scrollTop(t);
                        var g = t * 1;
                        prev = g;
                    } else {
                        box.scrollTop(prev - 100);
                    }
                }
            }
        },
        toggleContent: function(event) {
            this.uiChatbox.slideToggle(500);
            if (this.uiChatboxContent.is(":visible")) {
                //this.uiChatboxInputBox.focus();
            }
        },
        hideChat:function(event){
            event.stopPropagation();
            this.uiChatbox.slideToggle("slow")
            callSlimScroll();
            $(chatTogglerDiv).show(550);
        },
        showChat:function(event){
            event.stopPropagation();           
            this.uiChatbox.slideToggle("slow")
        },
        minMaxToggle:function(ev,self){
          ev.preventDefault();
          ev.stopPropagation();
          this.setScrollBarHeight(ev,self);
          
        },
        setScrollBarHeight:function(ev,self,thirdArg){
          if($(self).hasClass('minimize-arrow-upright') || thirdArg=="onInputFocus"){
             if(mobile){
              $("#chat_div").animate({height:height})
             }else $(".slimScrollDiv").animate({height:height})
             
             $(self).removeClass(' minimize-arrow-upright');
             $(self).addClass(' minimize-arrow-downleft')
          }else{
            if(mobile){
                $("#chat_div").animate({height:0})
               }else $(".slimScrollDiv").animate({height:0})
               
             $(self).removeClass(' minimize-arrow-downleft');
             $(self).addClass(' minimize-arrow-upright')
          }
              //$(".slimScrollDiv").animate({height:height})
              //this.minMaxToggle(ev,$(uiChatboxTitleBtnsMax));
        },
        widget: function() {
            return this.uiChatbox
        },
        _create: function() {
            var self = this,
                options = self.options,
                title = options.title //|| "No Title",
                
                TnC_Window = $("<div class='TnC_Window'></div>").css('display','none')
                btn_iAgree = $("<button type='submit'>I Agree</button>")
                note  = $("<p><i>Note: </i>Field marked with * is mandatory</p>")
                closeTnC = $("<span class='closeTnC'>X</span>").click(function(ev){
                	ev.stopPropagation();
                	$('.TnC_Window').hide();
                })
                iAgree = $("<form name='form'>"+"<p>Welcome to ICICI Bank. <br> </p>"+
                	"<div><code>*</code>Please enter your name here:<input class='username-input' maxlength='50' size='25'  placeholder='' onkeydown='if (event.keyCode == 13) return false' type='text' name='username'></div><div><div>"+
                	"<p id='inst-small'>"+instructions_ICICI_small+"<span style='text-decoration:underline;color:#025296;cursor:pointer;' onclick='fullInstShow()'> View More</span></p>"+	
                "</form>")
                    .append(btn_iAgree)    
                    .append(note)
                    .appendTo(TnC_Window)
                    .append(closeTnC)
                    .submit(function(ev){
                      ev.preventDefault();
                      if(form.username.value.length > 0 ) {
                    	//USERNAME = form.username.value;  
						USERNAME =encodeURIComponent( form.username.value );
                        self.showChat(ev);
                        //$(this).hide();
                        chatTogglerDiv.hide();
                        $("#chat_div")
                        	.chatbox("option", "boxManager")
                        	.addMsg('AIRA', 'Dear '+USERNAME+', welcome to ICICI Bank Money2India\'s automated chat service. Kindly state your query.');
                        TnC_Window.remove();
                        callTimeOuts();
                        chatTogglerDiv.click(function(ev){
                          self.showChat(ev);
                        })
                      }else{ 
                    	  form.username.placeholder = "Please enter your name first";
                    	  $("form[name='form'] code").css('color','red');
                    	  $("form[name='form'] input[name='username']").css('border-bottom-color','red');
                    	}
                    }).appendTo(TnC_Window),//.appendTo(TnC_Window), 
                chatTogglerDiv = $("<div ></div>")
                //"<div class='img-outer'>"+
                //"<img id='chatTogglerImg' src='"+assetsUrl+"/iman.jpg'>"+
                 //"<p>Have a query? <u style='color:#222'><b>Click here</b></u> to use our automated chat service.</p>"+
                //"</div>"+
                //"<span></span>"+
                //"</div>")
                     .append(TnC_Window)
                     //.fadeIn(800)
                     .animate({ opacity: 1 }, 100)
                     .click(function(ev){
                        TnC_Window.show();
                       /*self.showChat(ev);
                       $(this).hide();*/
                     })
                     .appendTo(document.body),
                uiChatbox = (self.uiChatbox = $('<div></div>'))
                    .appendTo(document.body)
                    .addClass(//'ui-widget ' +
                        //'ui-corner-top ' +
                        'ui-chatbox'
                    )
                    .attr('outline', 0)
                    .focusin(function() {
                        self.uiChatbox.removeClass('ui-state-highlight');
                        self.uiChatboxTitlebar.addClass('ui-state-focus');
                    })
                    .focusout(function() {
                        self.uiChatboxTitlebar.removeClass('ui-state-focus');
                    })
                    
               /* closeToggler = $("<b class='closeToggler'>X</b>").click(function(ev){
                	ev.stopPropagation();
                	chatTogglerDiv.hide();
                }).appendTo(chatTogglerDiv)*/

                uiChatboxTitlebar = (self.uiChatboxTitlebar = $('<div></div>'))
                    .addClass('ui-corner-top ' +
                        'ui-chatbox-titlebar '    
                    )
                    .click(function(event) {
                       // self.toggleContent(event);
                    })
                    .appendTo(uiChatbox),
                uiChatboxTitleTorso = $('<div class="torso title-torso"><img id="title-torso" src="'+assetsUrl+'/iman.jpg"/></div>')
                    //.appendTo(uiChatboxTitlebar),
                uiChatboxTitle = (self.uiChatboxTitle = $('<span></span>'))
                    .html(title)
                    .appendTo(uiChatboxTitlebar),

                uiChatboxTitleBtnsMin = $('<span class="title-btns minimize-minus"></span>')
                         .click(function(ev){
                             self.hideChat(ev);
                         })
                uiChatboxTitleBtnsMax = $('<span class="title-btns minimize-arrow-downleft"></span')
                         .click(function(ev){
                            /* self.showChat(ev);*/
                           self.minMaxToggle(ev,$(this))
                         })      

                uiChatboxTitleBtns = $('<div class="title-btn-wrapper"></div>')
                      .append(uiChatboxTitleBtnsMin)
                     // .append(uiChatboxTitleBtnsMax)

                    .appendTo(uiChatboxTitlebar),    
                uiChatboxContent = (self.uiChatboxContent = $('<div></div>'))
                    .addClass(//'ui-widget-content ' +
                        'ui-chatbox-content '
                    )
                    .appendTo(uiChatbox),
    
                uiChatboxLog = (self.uiChatboxLog = self.element)
                    .addClass('ui-chatbox-log')
                    .appendTo(uiChatboxContent),                
                uiChatboxInput = (self.uiChatboxInput = $('<div></div>'))
                    .addClass('ui-chatbox-input')
                    .appendTo(uiChatboxContent),
                
                sfChatboxInputBtns= $("<div class='btn-wrapper'></div>")    
                                        .appendTo(uiChatboxInput),      
               /* sfChatAttachBtn   = $("<span id='attach-msg' class='input-btns'></span>")
                                        .appendTo(sfChatboxInputBtns), */
                sfChatSendBtn     = $("<span id='send-msg' class='input-btns'></span>") 
                                        .click(function(){
                                            getInput()
                                        })  
                                        .appendTo(sfChatboxInputBtns),                                                                       
                getInput = function(){
                    var chatInput = $("#chatInput")

                    msg = $.trim(chatInput.val());
                    if (msg.length > 0) {
                        self.options.messageSent(self.options.id, self.options.user, msg);
                    }
                    chatInput.val('');
                    return false;
                },
                uiChatboxInputBox = (self.uiChatboxInputBox = $('<input id="chatInput" type="text" maxlength=1000>'))
                    .addClass(
                        'ui-chatbox-input-box ' +
                        'ui-corner-all'
                    )
                    .attr("placeholder", "Type your query here")
                    .appendTo(uiChatboxInput)
                    .focusin(function(event){
                        if(!mobile){
                          self.setScrollBarHeight(event,uiChatboxTitleBtnsMax,"onInputFocus");
                        }
                    })
                    .keydown(function(event) {
                    	$(".comment").remove();
                        if (event.keyCode && event.keyCode == $.ui.keyCode.ENTER) {
                            getInput();
                        }
                    }),
                sfBottomElem = "<div class='sfBottomElem'>"+
                                 "<div class='bottom left'><p>You can also contact us by:</p>"+
                                  "<span>phone/email</span>"+
                                  "<span><a target='_blank' href='https://www.icicibank.com/nri-banking/money_transfer/contact-m2i.page'>Click here</a></span>"+
                                  /*"<span><a target='_blank' href="+ICICI_ContactLink+">Post</a></span>"+
                                  "<span><a target='_blank' href="+ICICI_ContactLink+">Person</a></span>"+*/
                                 "</div>"+
                                 /*"<div class='bottom middle'><p>Want us to call you back </p>"+
                                    "<span><a target='_blank' href="+ICICI_ContactLink+">Click to call</a></span>"+
                                 "</div>"+*/
                                 "<div class='bottom right'>"+
                                    "<span class='bottom-high'><a target='_blank' onClick='doHandoff()' href='https://chat.icicibank.com/ICICIChat/ICICIBankNRIChat.aspx'>Additional Help</a></span>"+
                                 "</div>"+  
                                "</div>",

                sfBottomBar = (self.sfBottomBar = $('<div>'+sfBottomElem+'</div>'))
                    .addClass('sf-bottom-bar')
                    //.appendChild(sfBottomElem)
                    .appendTo(uiChatboxContent)

            uiChatboxTitlebar.find('*').add(uiChatboxTitlebar).disableSelection();

            self._setWidth(self.options.width);
            self._position(self.options.offset);
            self._setHeight(self.options.height);

            self.options.boxManager.init(self);

            if (!self.options.hidden) {
                uiChatbox.show();
            }
        },
        _setOption: function(option, value) {
            if (value != null) {
                switch (option) {
                    case "hidden":
                        if (value)
                            this.uiChatbox.hide();
                           // this.uiChatboxContent.hide();
                        else
                            this.uiChatbox.hide();
                            //this.uiChatboxContent.show();
                        break;
                    case "offset":
                        this._position(value);
                        break;
                    case "width":
                        this._setWidth(value);
                        break;
                    case "height":
                         this._setHeight(value);    
                }
            }
            $.Widget.prototype._setOption.apply(this, arguments);
        },
        _setWidth: function(width) {
            /*this.uiChatboxTitlebar.width(width + "px");*/
            this.uiChatbox.width(width + "px");
            /*this.uiChatboxLog.width(width + "px");*/
            this.uiChatboxInput.css("maxWidth", width + "px");
            // padding:2, boarder:2, margin:5
            this.uiChatboxInputBox.css("width", (width ) + "px");
        },
        _setHeight: function(height){
            this.uiChatboxLog.height(height + "px");  
        },
        _position: function(offset) {
            this.uiChatbox.css("right", offset);
        }
    });
}(jQuery));

var mobile = false;
var box = null;
$(document).ready(function() { 
     
     var _originalSize = $(window).width() + $(window).height()
     $(window).resize(function(){
        $("#chat_div").height(function(){
           return (toVhVw('100vh') - 140 );
         })
         
       callSlimScroll();  
       if($(window).width() + $(window).height() != _originalSize){
       }else{
       }
     });

    /*var tempmsg = 'Welcome. How can i help you';*/
    

    if ((window.innerWidth < 992 || window.screen.width < 992)) {
        mobile = true;
        width  = toVhVw("100vw") ;
        height = toVhVw("100vh") - 140;
        offset = 0;
    } else {
        mobile = false;
        width = 300 + 300/2.5;   
        height = 350 + 350/3.5;
        offset = 14;
    }
   
  var oneMin = 1*1000//*60

      function docOnload() {
          if (box) {
              box.chatbox("option", "boxManager").toggleBox();
          } else {
              box = $("#chat_div").chatbox({
                  id: "chat_div",
                  user: { key: "value" },
                  hidden: true,
                  title: "",
                  width: width,
                  height: height,
                  offset: offset,
                  messageSent: function(id, user, msg) {

                      $("#chat_div")
                          .chatbox("option", "boxManager")
                          .addMsg('Me', msg);
                      //replacing encodeURI with encodeURIComponent
                      var request = $.ajax({ url: ""+BASEURL+"chat?q=" + encodeURIComponent(msg)+"&apiuser="+USERNAME, dataType: "JSON", cache: false, timeout: 50000,xhrFields: {withCredentials: true} });

                      request.done(function(html) {
                          $("#chat_div")
                              .chatbox("option", "boxManager")
                              .addMsg('AIRA', html, html.key);
                      });
                      request.fail(function(jqXHR, textStatus) {
                          var regretMsg = "We are unavailable to chat right now. Please try after sometime. Sorry for the inconvenience."
                          $("#chat_div")
                              .chatbox("option", "boxManager")
                              .addMsg('AIRA', regretMsg);
                          
                          /*Removing all timers*/
                          clearTimeout(timeOut)
                      	  clearTimeout(chatEnd)

                          $(".thinkingGif").remove();
                      });
                  }
              });

              $("#chat_div")
                  .chatbox({ 'hidden': true })
                  .chatbox("option", "boxManager")
                  //.addMsg('AIRA', 'Dear '+USERNAME+', Welcome to ICICI Bank\'s automated chat service.');
              //callTimeOuts();    

              callSlimScroll();
              
            /* $("#chat_div").filter('.comment').click(function(ev){
            	 $('.comment').hide();
             }) */
          }
      }

    window.setTimeout(function(){
       docOnload();
    },oneMin)
});

function callSlimScroll() {
    if (!mobile) {
        $("#chat_div").slimScroll({
            height: height,
            color: '#000454',
            alwaysVisible: true,
            railVisible: true,
            size: '8px',
            wheelStep: 10
        });
    }
}

/*String.includes polyfill*/
if (!String.prototype.includes) {
	  String.prototype.includes = function(search, start) {
	    'use strict';
	    if (typeof start !== 'number') {
	      start = 0;
	    }
	    
	    if (start + search.length > this.length) {
	      return false;
	    } else {
	      return this.indexOf(search, start) !== -1;
	    }
	  };
	}
/*String.endswith polyfill*/
if (!String.prototype.endsWith) {
	  String.prototype.endsWith = function(searchString, position) {
	      var subjectString = this.toString();
	      if (typeof position !== 'number' || !isFinite(position) || Math.floor(position) !== position || position > subjectString.length) {
	        position = subjectString.length;
	      }
	      position -= searchString.length;
	      var lastIndex = subjectString.lastIndexOf(searchString, position);
	      return lastIndex !== -1 && lastIndex === position;
	  };
	}


var ELEM;
var original = [] , index;
function lessMore(elem) {
	$(elem).find(".rm_less").remove();
	//$(elem).html().replace(/<hr>/g,"");
	
	ELEM = elem;
	//console.log(elem);
	elem = $(elem);
	//console.log(elem)
	original.push(elem.html())
	index = original.length - 1;
	elemText = elem.html();
	
	if (elemText.includes("View Less")) {
		elemText.replace("View Less","");
	}
	
	if (elemText.includes('<span class="sfShowMore"></span>') ) {
		var html = elem.html().split('<span class="sfShowMore"></span>');
		var first = elemText.split('<span class="sfShowMore"></span>')[0];
		
		var totalRest = elem.html().split('<hr>');
		
		var rest = "";
		if(elem.html().includes("<hr>")){
			//rest = "<hr>";
		}
		
		
		if(elem.html().includes("<i>")){
			totalRest = elem.html().split('<i>'); 
			rest = "<i>";
		}

		elem.html("");

		$.each(totalRest, function(i, e) {
			if (i > 0) {
				rest = rest + e;
			}
		})

		elem.html(makeEllipses(first) + rest);
		
		function makeEllipses(text) {
			if (text.length > 1) {
				 text = text
						+ "<span style='text-decoration:underline;color:#025296;cursor:pointer' class='rm_more' onclick='callMore(this,"+index+")'> View More</span>";
			}
			return text
		}
	} else {
		return elemText;
	}
}
function callMore(self,i){
	//console.log(i)
	var totalRest  = original[i].split('<hr>');
	var rest = "";
	
	if(original[i].includes("<hr>")){
		//rest = "<hr>";
	}
	
	if(original[i].includes("<i>")){
		totalRest = original[i].split('<i>'); 
		rest = "<i>";
	} 
	
	//$(self).parent().html = "";

	$.each(totalRest, function(i, e) {
		if (i > 0) {
			rest = rest + e;
		}
	})
	if(totalRest[0].includes("<i>"))
		$(self).parent().html(totalRest[0].split("<i>")[0] 
		   + "<span style='text-decoration:underline;color:#025296;cursor:pointer;' class='rm_less' onclick='lessMore($(this).parent())'> View Less</span>"
		   +"<i>"+totalRest[0].split("<i>")[1]
		   +rest);	
	else
		//$(self).parent().html(totalRest[0] +rest);
	    $(self).parent().html(totalRest[0] + "<span style='text-decoration:underline;color:#025296;cursor:pointer;' class='rm_less' onclick='lessMore($(this).parent())'> View Less</span>"+rest);
}
