function openFancybox() {
    setTimeout(function() {
        $("#remaining-session-popup").fancybox({
            padding: 0,
            //closeBtn: !1
        }).trigger("click")
    }, 2e3)
}

function shakeForm(e) {
    for (var t = 20, n = 0; n < 10; n++) $(e).animate({
        "margin-left": "+=" + (t = -t) + "px",
        "margin-right": "-=" + t + "px"
    }, 50, function() {
        $(e).removeAttr("style")
    })
}

function get_operating_system() {
    var e = "Unknown OS";
    return navigator.appVersion.indexOf("Win") != -1 && (e = "Windows"), navigator.appVersion.indexOf("Mac") != -1 && (e = "MacOS"), navigator.appVersion.indexOf("X11") != -1 && (e = "UNIX"), navigator.appVersion.indexOf("Linux") != -1 && (e = "Linux"), e
}

function isSafari() {
    return navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0 ? 1 : 0
}

function get_scrollbar_width() {
    if (isSafari() && "MacOS" == operating_system) var e = 15;
    else var e = 17;
    return e
}

function get_viewport_dimension() {
    var e = 0,
        t = 0;
    "number" == typeof window.innerWidth ? (e = window.innerWidth, t = window.innerHeight) : document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight) ? (e = document.documentElement.clientWidth, t = document.documentElement.clientHeight) : document.body && (document.body.clientWidth || document.body.clientHeight) && (e = document.body.clientWidth, t = document.body.clientHeight), isSafari() && (e -= get_scrollbar_width());
    var n = {
        width: e,
        height: t
    };
    return n
}

function checkOffset() {
    $(".action").offset().top + $(".action").height() >= $("footer").offset().top - 10 && $(".action").css("position", "absolute"), $(document).scrollTop() + window.innerHeight < $("footer").offset().top && $(".action").css("position", "fixed"), setTimeout(function() {
        $(".action").offset().top + $(".action").height() >= $(".tab-detail").offset().top - 10 ? $(".action").css("visibility", "visible") : $(".action").css("visibility", "hidden")
    }, 1e3)
}

function checkOffset1() {
    $(".msg-action-bar").offset().top + $(".msg-action-bar").height() >= $("footer").offset().top - 10 && $(".msg-action-bar").css("position", "absolute"), $(document).scrollTop() + window.innerHeight < $("footer").offset().top && $(".msg-action-bar").css("position", "fixed"), setTimeout(function() {
        $(".msg-action-bar").offset().top + $(".msg-action-bar").height() >= $(".pending-invitations").offset().top - 10 ? $(".msg-action-bar").css("visibility", "visible") : $(".msg-action-bar").css("visibility", "hidden")
    }, 1e3)
}

function checkOffset2() {
    $(".reciept-header").offset().top + $(".reciept-header").height() >= $("footer").offset().top - 10 && $(".reciept-header").css("position", "absolute"), $(document).scrollTop() + window.innerHeight < $("footer").offset().top && $(".reciept-header").css("position", "fixed"), setTimeout(function() {
        $(".reciept-header").offset().top + $(".reciept-header").height() >= $(".reciept-container").offset().top - 10 ? $(".reciept-header").css("visibility", "visible") : $(".reciept-header").css("visibility", "hidden")
    }, 1e3)
}

function checkOffset_table_operations() {
    $(".table-operations").offset().top + $(".table-operations").height() >= $("footer").offset().top - 10 && $(".table-operations").css("position", "absolute"), $(document).scrollTop() + window.innerHeight < $("footer").offset().top && $(".table-operations").css("position", "fixed"), setTimeout(function() {
        $(".table-operations").offset().top + $(".table-operations").height() >= $(".tab-detail").offset().top - 10 ? $(".table-operations").css("visibility", "visible") : $(".table-operations").css("visibility", "hidden")
    }, 1e3)
}
jQuery(document).ready(function() {
	//Code by DOBOZ start
	var faqsSections = $('.cd-faq-group'),
	faqTrigger = $('.cd-faq-trigger'),
	faqsContainer = $('.cd-faq-items'),
	faqsCategoriesContainer = $('.cd-faq-categories'),
	faqsCategories = faqsCategoriesContainer.find('a'),
	closeFaqsContainer = $('.cd-close-panel');

//select a faq section 
faqsCategories.on('click', function(event){
	event.preventDefault();
	var selectedHref = $(this).attr('href'),
		target= $(selectedHref);
	if( $(window).width() < MqM) {
		faqsContainer.scrollTop(0).addClass('slide-in').children('ul').removeClass('selected').end().children(selectedHref).addClass('selected');
		closeFaqsContainer.addClass('move-left');
		$('body').addClass('cd-overlay');
	} else {
        $('body,html').animate({ 'scrollTop': target.offset().top - 19}, 200); 
	}
});

//close faq lateral panel - mobile only
$('body').bind('click touchstart', function(event){
	if( $(event.target).is('body.cd-overlay') || $(event.target).is('.cd-close-panel')) { 
		closePanel(event);
	}
});
faqsContainer.on('swiperight', function(event){
	closePanel(event);
});

//show faq content clicking on faqTrigger
faqTrigger.on('click', function(event){
	event.preventDefault();
	$(this).next('.cd-faq-content').slideToggle(200).end().parent('li').toggleClass('content-visible');
});
	
//Code by DOBOZ end
	
	
        function e() {
            if ($(window).width() <= 767) {
                var e = $(".header-currency dt span.country-code");
                return $(".country-location a").append(e), $(".country-location a span.country-code").addClass("active"), !1
            }
        }

        function t() {
            if ($(window).width() <= 767) {
                var e = $("li.user-flyout > label, li.user-flyout .frame");
                return $("li.mobile-user-flyout").append(e), !1
            }
        }

        function n() {
            if ($(window).width() <= 767) {
                var e = $(".right-frame ul li.setting-drop-down-toggle");
                return $("li.mobile-user-flyout").after(e), !1
            }
        }

        function s() {
            if ($(window).width() <= 767) {
                var e = $(".right-frame ul li.normal-drop-down-toggle");
                return $("li.normal-drop-down-notification").after(e), !1
            }
        }

        function i() {
            if ($(window).width() <= 767) {
                var e = $("li.user-flyout > label, li.user-flyout .left-frame");
                return $("li.mobile-user-flyout label strong").after(e), !1
            }
        }

        function a() {
            if ($(window).width() <= 767) return $("li.mobile-user-flyout label strong").html(""), $(".country-location a span.country-code.active").clone().appendTo("li.mobile-user-flyout label strong"), !1
        }

        function o() {
            var e = $(".floating-labels .cd-label").next();
            e.each(function() {
                var e = $(this);
                d(e), e.on("change keyup", function() {
                    d(e)
                })
            })
        }

        function d(e) {
            "" == e.val() ? e.prev(".cd-label").removeClass("float") : e.prev(".cd-label").addClass("float")
        }

        function c(e) {
            return $("#" + e).find("dt a span.value").html()
        }

        function c(e) {
            return $("#" + e).find("dt a span.value").html()
        }

        function c(e) {
            return $("#" + e).find("dt a span.value").html()
        }
        openFancybox(), $(".user-flyout .frame, .body-lock").click(function() {
            $("html").hasClass("has-flyout") && $(".user-flyout").hasClass("current") ? ($("html").removeClass("has-flyout"), $(".user-flyout").removeClass("current"), $(".body-lock").fadeOut("slow", "linear")) : $(this).parent(".user-flyout") && !$(this).hasClass("body-lock") && ($(this).closest(".user-flyout").toggleClass("current"), $(".body-lock").fadeToggle("slow", "linear"), $("html").addClass("has-flyout"))
        }), $(".post-login-notification-dropdown a, .ct-notifications, .body-lock").click(function() {
            $("html").hasClass("has-flyout") && $(".post-login-notification-dropdown").hasClass("current") ? ($("html").removeClass("has-flyout"), $(".post-login-notification-dropdown").removeClass("current"), $(".body-lock").fadeOut("slow", "linear")) : ($(this).parent(".post-login-notification-dropdown") && !$(this).hasClass("body-lock") || $(this).hasClass("ct-notifications")) && ($(".post-login-notification-dropdown").toggleClass("current"), $(".body-lock").fadeToggle("slow", "linear"), $("html").addClass("has-flyout"))
        }), $(".pre-login-signup-has-dropdown a, .body-lock").click(function() {
            $("html").hasClass("has-flyout") && $(".pre-login-signup-has-dropdown").hasClass("current") ? ($(".pre-login-signup-has-dropdown").removeClass("current"), $("html").removeClass("has-flyout"), $(".body-lock").fadeOut("slow", "linear")) : $(this).parent(".pre-login-signup-has-dropdown") && !$(this).hasClass("body-lock") && ($(this).closest(".pre-login-signup-has-dropdown").toggleClass("current"), $(".body-lock").fadeToggle("slow", "linear"), $("html").addClass("has-flyout"))
        }), $(".pre-login-help-has-dropdown a, .body-lock").click(function() {
            $("html").hasClass("has-flyout") && $(".pre-login-help-has-dropdown").hasClass("current") ? ($(".pre-login-help-has-dropdown").removeClass("current"), $("html").removeClass("has-flyout"), $(".body-lock").fadeOut("slow", "linear")) : $(this).parent(".pre-login-help-has-dropdown") && !$(this).hasClass("body-lock") && ($(this).closest(".pre-login-help-has-dropdown").toggleClass("current"), $(".body-lock").fadeToggle("slow", "linear"), $("html").addClass("has-flyout"))
        }), $(".pre-login-has-dropdown a, .body-lock").click(function() {
            $("html").hasClass("has-flyout") && $(".pre-login-has-dropdown").hasClass("current") ? ($(".pre-login-has-dropdown").removeClass("current"), $("html").removeClass("has-flyout"), $(".body-lock").fadeOut("slow", "linear")) : $(this).parent(".pre-login-has-dropdown") && !$(this).hasClass("body-lock") && ($(this).closest(".pre-login-has-dropdown").toggleClass("current"), $(".body-lock").fadeToggle("slow", "linear"), $("html").addClass("has-flyout"))
        }), $(".js_register").click(function() {}), $(".js_show_pwd").click(function() {
            var e = $(this).parent().parent().find(".pwd");
            "password" == e.attr("type") ? (e.attr("type", "text"), $(this).addClass("active")) : (e.attr("type", "password"), $(this).removeClass("active"))
        }), $(".js_breakup_detail").fancybox({
            padding: 0,
//            closeBtn: !1
        }), $(document).on("keypress", ".txtbox-enterfund", function(e) {
            var t = e.which ? e.which : event.keyCode;
            return !(t > 31 && (t < 48 || t > 57))
        }), $(document).on("keypress", ".input-amount", function(e) {
            var t = e.which ? e.which : event.keyCode;
            return !(t > 31 && (t < 48 || t > 57))
        }), $("#dob").datepicker({
            changeMonth: !0,
            changeYear: !0
        }), $(".favourite-bene").click(function() {
            $(this).toggleClass("active")
        }), $("li.setting-dropdown").click(function() {
            $(this).closest("#mobile-primary-logedin-nav").toggleClass("current")
        });
        var l = $(".right-nav");
        l.height();
        l.on("click", ".nav-trigger", function(e) {
            e.preventDefault(), l.toggleClass("nav-open")
        }), $(window).width() < 768 ? $(".has-dropdown a").click(function() {
            $(this).closest(".has-dropdown").hasClass("current") ? $(".has-dropdown").removeClass("current") : ($(".has-dropdown").removeClass("current"), $(this).closest(".has-dropdown").addClass("current"))
        }) : $(".normal-drop-down-toggle-help a, .body-lock").click(function() {
            $("html").hasClass("has-flyout") && $(".normal-drop-down-toggle-help").hasClass("current") ? ($("html").removeClass("has-flyout"), $(".normal-drop-down-toggle-help").removeClass("current"), $(".body-lock").fadeOut("slow", "linear")) : $(this).parent(".normal-drop-down-toggle-help") && !$(this).hasClass("body-lock") && ($(this).closest(".normal-drop-down-toggle-help").toggleClass("current"), $(".body-lock").fadeToggle("slow", "linear"), $("html").addClass("has-flyout"))
        }), $(function() {
            e(), t(), n(), s(), i(), a(), window.resizeEvt, $(window).on("resize", function(o) {
                e(), t(), n(), s(), i(), a()
            })
        }), $(".floating-labels").length > 0 && o(), $("#example-one").organicTabs(), $(".dropdown img.flag").addClass("flagvisibility"), $(".dropdown dt a").click(function() {
            $(".dropdown dd ul").toggle()
        }), $(".dropdown dd ul li a").click(function() {
            if ($(this).parent().parent().hasClass("no-drop-down")) return !1;
            var e = $(this).html();
            $(".dropdown dt a span").html(e), $(".dropdown dd ul").hide(), $("#result").html("Selected value is: " + c("sample"))
        }), $(document).bind("click", function(e) {
            var t = $(e.target);
            t.parents().hasClass("dropdown") || $(".dropdown dd ul").hide()
        }), $("#flagSwitcher").click(function() {
            $(".dropdown img.flag").toggleClass("flagvisibility")
        }), $(".dropdowns01 img.flag").addClass("flagvisibility"), $(".dropdowns01 dt a").click(function() {
            $(".dropdowns01 dd ul").toggle()
        }), $(".dropdowns01 dd ul li a").click(function() {
            if ($(this).parent().parent().hasClass("no-drop-down")) return !1;
            var e = $(this).html();
            $(".dropdowns01 dt a span").html(e), $(".dropdowns01 dd ul").hide(), $("#result").html("Selected value is: " + c("sample"))
        }), $(document).bind("click", function(e) {
            var t = $(e.target);
            t.parents().hasClass("dropdowns01") || $(".dropdowns01 dd ul").hide()
        }), $("#flagSwitcher").click(function() {
            $(".dropdowns01 img.flag").toggleClass("flagvisibility")
        }), $(".dropdowns02 img.flag").addClass("flagvisibility"), $(".dropdowns02 dt a").click(function() {
            $(".dropdowns02 dd ul").toggle()
        }), $(".dropdowns02 dd ul li a").click(function() {
            if ($(this).parent().parent().hasClass("no-drop-down")) return !1;
            var e = $(this).html();
            $(".dropdowns02 dt a span").html(e), $(".dropdowns02 dd ul").hide(), $("#result").html("Selected value is: " + c("sample"))
        }), $(document).bind("click", function(e) {
            var t = $(e.target);
            t.parents().hasClass("dropdowns02") || $(".dropdowns02 dd ul").hide()
        }), $("#flagSwitcher").click(function() {
            $(".dropdowns02 img.flag").toggleClass("flagvisibility")
        })
    }), $(window).scroll(function() {
        $(this).scrollTop() > 1 ? $("nav.icici-m2i-header").addClass("sticky") : $("nav.icici-m2i-header").removeClass("sticky")
    }),
    function(e) {
        e.organicTabs = function(t, n) {
            var s = this;
            s.$el = e(t), s.$nav = s.$el.find(".nav"), s.init = function() {
                s.options = e.extend({}, e.organicTabs.defaultOptions, n), e(".hide").css({
                    position: "relative",
                    top: 0,
                    left: 0,
                    display: "none"
                }), s.$nav.delegate("li > a", "click", function() {
                    var t = s.$el.find("a.current").attr("href").substring(1),
                        n = e(this),
                        i = n.attr("href").substring(1),
                        a = s.$el.find(".list-wrap"),
                        o = a.height();
                    return a.height(o), i != t && 0 == s.$el.find(":animated").length && s.$el.find("#" + t).fadeOut(s.options.speed, function() {
                        s.$el.find("#" + i).fadeIn(s.options.speed);
                        var e = s.$el.find("#" + i).height();
                        a.animate({
                            height: e
                        }), s.$el.find(".nav li a").removeClass("current"), n.addClass("current")
                    }), !1
                })
            }, s.init()
        }, e.organicTabs.defaultOptions = {
            speed: 300
        }, e.fn.organicTabs = function(t) {
            return this.each(function() {
                new e.organicTabs(this, t)
            })
        }
    }(jQuery), $(document).ready(function() {
        $(".datePicker").each(function() {
            $(this).datepicker({
                changeMonth: !0,
                changeYear: !0,
                showOn: "button",
                buttonImage: "images/calendor-orange.png",
                buttonImageOnly: !0,
                buttonText: "Select date",
                dateFormat: "dd-M-yy"
            })
        }),
        $(".datePicker_passFun").each(function() {
            $(this).datepicker({
                changeMonth: !0,
                changeYear: !0,
                showOn: "button",
                yearRange: "-150:+0",
                buttonImage: "images/calendor-orange.png",
                buttonImageOnly: !0,
                buttonText: "Select date",
                dateFormat: "dd/mm/yy"
            })
        })
    });
var BrowserDetect = {
    init: function() {
        this.browser = this.searchString(this.dataBrowser) || "Other", this.version = this.searchVersion(navigator.userAgent) || this.searchVersion(navigator.appVersion) || "Unknown"
    },
    searchString: function(e) {
        for (var t = 0; t < e.length; t++) {
            var n = e[t].string;
            if (this.versionSearchString = e[t].subString, n.indexOf(e[t].subString) !== -1) return e[t].identity
        }
    },
    searchVersion: function(e) {
        var t = e.indexOf(this.versionSearchString);
        if (t !== -1) {
            var n = e.indexOf("rv:");
            return "Trident" === this.versionSearchString && n !== -1 ? parseFloat(e.substring(n + 3)) : parseFloat(e.substring(t + this.versionSearchString.length + 1))
        }
    },
    dataBrowser: [{
        string: navigator.userAgent,
        subString: "Edge",
        identity: "ms-edge"
    }, {
        string: navigator.userAgent,
        subString: "MSIE",
        identity: "explorer"
    }, {
        string: navigator.userAgent,
        subString: "Trident",
        identity: "explorer"
    }, {
        string: navigator.userAgent,
        subString: "Firefox",
        identity: "firefox"
    }, {
        string: navigator.userAgent,
        subString: "Opera",
        identity: "opera"
    }, {
        string: navigator.userAgent,
        subString: "OPR",
        identity: "opera"
    }, {
        string: navigator.userAgent,
        subString: "Chrome",
        identity: "chrome"
    }, {
        string: navigator.userAgent,
        subString: "Safari",
        identity: "safari"
    }]
};
$(document).ready(function() {
    BrowserDetect.init(), $("body").addClass(BrowserDetect.browser + " " + BrowserDetect.browser + BrowserDetect.version)
}), $(document).ready(function() {
    $("#owl-demo").owlCarousel({
        navigation: !0,
        slideSpeed: 300,
        paginationSpeed: 400,
        singleItem: !0,
        items: 1,
        navText: ["", ""]
    }), $(".fancybox").fancybox(), $(".fancybox-media").attr("rel", "media-gallery").fancybox({
        openEffect: "none",
        closeEffect: "none",
        prevEffect: "none",
        nextEffect: "none",
        arrows: !1,
        helpers: {
            media: {},
            buttons: {}
        }
    }), $(".fancybox").fancybox({
        helpers: {
            overlay: {
                closeClick: !1
            }
        }
    })
});
var operating_system = get_operating_system();
$(document).ready(function() {
        $(".tabs a").click(function() {
            var e = $(this).attr("rel");
            switch ($(".tabs a").removeClass("current"), $(this).addClass("current"), $(".action-btns").attr("class", "action-btns " + e), $(".component-13-wrapper .cd-form").addClass("hidden"), $(".cd-form." + e).removeClass("hidden"), e) {
                case "fav-trans":
                    $(".transactions-btn-mgmt").addClass("hidden"), $(".setup-rec-transfer").addClass("hidden");
                    break;
                case "rec-trans":
                    $(".transactions-btn-mgmt").addClass("hidden"), $(".transactions-btn-mgmt.rec-trans").removeClass("hidden"), $(".setup-rec-transfer").addClass("hidden");
                    break;
                default:
                    $(".transactions-btn-mgmt").addClass("hidden"), $(".transactions-btn-mgmt.last5-trans").removeClass("hidden"), $(".setup-rec-transfer").addClass("hidden")
            }
        })
    }),
    function(e) {
        var t;
        e(window).on("resize scroll", function() {
            var n = get_viewport_dimension();
            t = n.width, e("html").hasClass("touch") ? e(window).width() < 1024 ? (e(".action").get(0) && checkOffset(), e(document).scroll(function() {
                e(".action").get(0) && checkOffset()
            })) : e(".action").attr("style", "") : t < 1024 ? (e(".action").get(0) && checkOffset(), e(document).scroll(function() {
                e(".action").get(0) && checkOffset()
            })) : e(".action").attr("style", "")
        })
    }(jQuery), $(document).ready(function() {
        $(".edit-transation").click(function(e) {
        	e.stopPropagation(), $(".sm-tab").removeClass("active"), $(this).closest(".sm-tab").addClass("active"), $(this).closest(".sm-tab").removeClass("completed"), $(this).closest(".sm-tab").hasClass("tab2") ? ($(".tab2-step1").addClass("hidden"), $(".tab2-step2").removeClass("hidden")) : $(this).closest(".sm-tab").hasClass("tab3") ? ($(".tab3-step1").removeClass("hidden"), $(".tab3-step2").addClass("hidden")) : $(this).closest(".sm-tab").hasClass("tab4") && ($(".tab4-step1").addClass("hidden"), $(".tab4-step2").addClass("hidden"), $(".tab4-step3").addClass("hidden"), $(".tab4-step4").addClass("hidden"), $(".tab4-step6").addClass("active"), $(".tab4-step7").addClass("hidden")), $(".tab3-step_otp_ICICI").addClass("hidden"), $(".tab3-step_otp_NEFT").addClass("hidden"), $(".tab3-step_otp_DD").addClass("hidden")
            }), $(".js_step1").click(function() {}), $(".js_show_user_profile").click(function() {}), $(".js_edit-profile-pic").click(function() {
                $(".tab2-step1").removeClass("hidden"), $(".tab2-step2").addClass("hidden"), $(".tab2 .other-content p").removeClass("hidden")
            }), $(".js_step2").click(function() {
                $(".tab2").addClass("completed"), $(".sm-tab").removeClass("active"), $(".tab3").addClass("active"), $(".tab3-step1").removeClass("hidden"), $(".tab3-step2").addClass("hidden"), $(".added-recipient").removeClass("hidden"), $(".tab3").hasClass("completed") && $(".tab3").removeClass("completed"), $(".js_step3").removeClass("hidden")
            }), $(".add-recipient").click(function() {
                $(".tab3-step1").addClass("hidden"), $(".tab3-step2").removeClass("hidden")
            }), $('.recipient-type input[type="radio"]').on("change", function() {
            	"recipient-individual" == $(this).attr("value") && ($(".recipient").not(".recipient-individual").addClass("hidden"), $(".recipient-individual").removeClass("hidden")), "recipient-non-individual" == $(this).attr("value") && ($(".recipient").not(".recipient-non-individual").addClass("hidden"), $(".recipient-non-individual").removeClass("hidden")), "recipient-business" == $(this).attr("value") && ($(".recipient").not(".recipient-business").addClass("hidden"), $(".recipient-business").removeClass("hidden"))
            }), $(".option-button a").click(function() {
                $(".option-button a").removeClass("active"), $(this).addClass("active"), $(".recipient-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $(".recipient-non-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $("." + $(this).attr("rel")).removeClass("hidden"), $(".registered_entity_option1").addClass("hidden"), $(".registered_entity_option2").addClass("hidden"), $(".registered_entity_option3").addClass("hidden")
            }), $(".show_registered_entity_option1").click(function() {
                $(this).addClass("active"), $(".recipient-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $(".recipient-non-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $(".registered_entity_option1").removeClass("hidden")
            }), $(".show_registered_entity_option2").click(function() {
                $(this).addClass("active"), $(".recipient-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $(".recipient-non-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $(".registered_entity_option2").removeClass("hidden")
            }), $(".show_registered_entity_option3").click(function() {
                $(this).addClass("active"), $(".recipient-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $(".recipient-non-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $(".registered_entity_option3").removeClass("hidden")
            }), $(".registered_entity_back").click(function() {
                $(this).addClass("active"), $(".recipient-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $(".recipient-non-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $(".registered_entity_option2").addClass("hidden"), $(".registered_entity_option3").addClass("hidden"), $(".registered-entity").removeClass("hidden")
            }), $(".donation_back").click(function() {
                $(this).addClass("active"), $(".recipient-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $(".recipient-non-individual-types").not("." + $(this).attr("rel")).addClass("hidden"), $(".registered_entity_option1").addClass("hidden"), $(".donation").removeClass("hidden")

            }), $('.non-icici-bank-type input[type="radio"]').on("change", function() {
                "bank-ifsc-code" == $(this).attr("value") && ($(".non-icici-ifsc").not(".bank-ifsc-code").addClass("hidden"), $(".bank-ifsc-code").removeClass("hidden")), "bank-location" == $(this).attr("value") && ($(".non-icici-ifsc").not(".bank-location").addClass("hidden"), $(".bank-location").removeClass("hidden"))
            }), $(".js_tab3_step2").click(function() {}), $(".js_recipient-profile").click(function() {
                $(".js_recipient-profile").removeClass("active"), $(this).addClass("active")
            }), $(".js_step3").click(function() {
            	
            	//alert('beneficiary account is mandatory1'),
            	$(".tab4-step6").get(0).scrollIntoView(),window.scrollBy(0,-3000);     

            }),

            $(".js_view_detail").fancybox({
                padding: 0,
                /*closeBtn: !1*/
            }), $(".js_dollar_varification").click(function() {
                $(".tab4-step6").addClass("hidden"), $(".tab4-step7").removeClass("hidden")
            }), $(".js_step4").click(function() {
                //alert('remitter account is mandatory');
            	$(".tab5-step1").get(0).scrollIntoView(),window.scrollBy(0,-700)
            }),

            $(".js_back_dollar_varification").click(function() {
                $(".tab4-step7").addClass("hidden"), $(".tab4-step6").removeClass("hidden")
            }), $(".js_dollar_varification_finish").click(function() {
                $(".tab4-step7").addClass("hidden"), $(".tab4-step1").removeClass("hidden"), $(".tab4").addClass("completed"), $(".sm-tab").removeClass("active"), $(".tab5").addClass("active")
            }), $(".js_back_to_step4").click(function() {
                $(".tab5").removeClass("active"), $(".tab4").removeClass("completed"), $(".tab4").addClass("active"), $(".tab4-step1").removeClass("hidden"), $(".tab4-step6").addClass("hidden")
            }), $(".js_step5").click(function() {
            $(".tab5-step1").addClass("hidden"), $(".tab5-step2").removeClass("hidden"),$(".tab5-step2").get(0).scrollIntoView(),window.scrollBy(0,-180)
        }), $(".js_tab5_step3").click(function() {
                $(".tab5").addClass("initiate-ft"), $(".tab5-step1").addClass("hidden"), $(".tab5-step3").removeClass("hidden")
            }), $(".add-bank-account").click(function() {
                $(".tab4-step1").addClass("hidden"), $(".tab4-step2").removeClass("hidden")
            }), $(".tab4-step6 .add-bank-account").click(function() {
                $(".tab4-step1").addClass("hidden"), $(".tab4-step6").addClass("hidden"), $(".tab4-step2").removeClass("hidden")
            }), $(".btnBack").click(function() {
                $(".tab4-step1").removeClass("hidden"), $(".tab4-step2").addClass("hidden")
            }), $(".btn-save-continue").click(function() {
                $(".tab4-step1").addClass("hidden"), $(".tab4-step2").addClass("hidden"), $(".tab4-step3").removeClass("hidden")
            }), $(".btn-save-continue-yodleesubmit").click(function() {
                $(".tab4-step1").addClass("hidden"), $(".tab4-step2").addClass("hidden"), $(".tab4-step3").addClass("hidden"), $(".tab4-step4").addClass("hidden"), $(".tab4-step5").addClass("hidden"), $(".tab4-step6").removeClass("hidden")
            }), $(".tab4-step3 .frm-checkbox").click(function() {
                $(this).is(":checked") ? ($(".btn-save-continue").addClass("go-next-level"), $(".go-next-level").click(function() {
                    $(".tab4-step1").addClass("hidden"), $(".tab4-step2").addClass("hidden"), $(".tab4-step3").addClass("hidden"), $(".tab4-step4").removeClass("hidden")
                })) : $(".btn-save-continue").removeClass("go-next-level")
            }), $(".tab4-step3 .btnBack").click(function() {
                $(".tab4-step1").addClass("hidden"), $(".tab4-step2").removeClass("hidden"), $(".tab4-step3").addClass("hidden")
            }), $(".tab4-step4 .btnBack").click(function() {
                $(".tab4-step1").addClass("hidden"), $(".tab4-step2").addClass("hidden"), $(".tab4-step3").removeClass("hidden"), $(".tab4-step4").addClass("hidden")
            }), $(".tab4-step5 .btn-continue").click(function() {
                $(".tab4-step1").addClass("hidden"), $(".tab4-step2").addClass("hidden"), $(".tab4-step3").addClass("hidden"), $(".tab4-step4").addClass("hidden"), $.fancybox.close(), $(".tab4-step6").removeClass("hidden")
            }), $(".tab4-step5 .btn-ok").click(function() {
                $.fancybox.close()
            }), $(".tab4-step5-user .btn-ok").click(function() {
                $.fancybox.close()
            }), $(".tab4-step6 .btn-continue").click(function() {
                $(".tab4-step1").addClass("hidden"), $(".tab4-step2").addClass("hidden"), $(".tab4-step3").addClass("hidden"), $(".tab4-step4").addClass("hidden"), $.fancybox.close(), $(".tab5-step1").removeClass("hidden")
            }), $("#datepicker").datepicker({
                changeMonth: !0,
                changeYear: !0
            })
    });
var operating_system = get_operating_system();
$(document).ready(function() {
        $(".left-nav li > a").click(function() {
            $(this).next().fadeToggle("slow", "linear")
        }), $(".component-generic-invite-01 .btn-save-invite").click(function() {
            $(".component-generic-invite-01").addClass("hidden"), $(".component-generic-invite-02").removeClass("hidden"), $(".component-generic-invite-03").addClass("hidden"), $(".component-generic-invite-04").addClass("hidden")
        }), $(".ct-overview").click(function() {
            $(".component-generic-invite-01").addClass("hidden"), $(".component-generic-invite-02").addClass("hidden"), $(".component-generic-invite-03").addClass("hidden"), $(".component-generic-invite-04").removeClass("hidden")
        }), $(".ct-password").click(function() {
            $(".component-generic-invite-01").addClass("hidden"), $(".component-generic-invite-02").addClass("hidden"), $(".component-generic-invite-03").removeClass("hidden"), $(".component-generic-invite-04").addClass("hidden")
        }), $(".ct-send-invitation").click(function() {
            $(".component-generic-invite-01").removeClass("hidden"), $(".component-generic-invite-02").addClass("hidden"), $(".component-generic-invite-03").addClass("hidden"), $(".component-generic-invite-04").addClass("hidden")
        }), $(".ct-pending-invitation").click(function() {
            $(".component-generic-invite-01").addClass("hidden"), $(".component-generic-invite-02").removeClass("hidden"), $(".component-generic-invite-03").addClass("hidden"), $(".component-generic-invite-04").addClass("hidden")
        }), $(".js_change_password").click(function() {
            shakeForm(".change-pass")
        })
    }), $("#select-all").click(function() {
        $('.message-list input[type="checkbox"]').prop("checked", !0)
    }),/*$(".js_step4").click(function() {
        //alert('remitter account is mandatory');
    	$(".tab5-step1").get(0).scrollIntoView(),window.scrollBy(0,0)
    }),*/
    function(e) {
        var t;
        e(window).on("resize scroll", function() {
            var n = get_viewport_dimension();
            t = n.width, e("html").hasClass("touch") ? e(window).width() < 768 ? (e(".msg-action-bar").get(0) && checkOffset1(), e(document).scroll(function() {
                e(".msg-action-bar").get(0) && checkOffset1()
            })) : e(".msg-action-bar").attr("style", "") : t < 768 ? (e(".msg-action-bar").get(0) && checkOffset1(), e(document).scroll(function() {
                e(".msg-action-bar").get(0) && checkOffset1()
            })) : e(".msg-action-bar").attr("style", "")
        })
    }(jQuery), $(document).ready(function() {
        $(".js_add_bank_account").click(function() {
            $(".bank-ac-overview").addClass("hidden"), $(".ac-creation-step1").removeClass("hidden"), $(".component-generic-account-wrapper > a > h1").addClass("mobile-go-back-title"), window.scrollTo(0, 0)
        }), $(".ac-view").click(function() {
            $(".bank-ac-overview").addClass("hidden"), $(".ac-view-details").removeClass("hidden"), $(".component-generic-account-wrapper > a > h1").addClass("mobile-go-back-title")
        }), $(".ac-back").click(function() {
            $(".bank-ac-overview").removeClass("hidden"), $(".ac-view-details").addClass("hidden"), $(".component-generic-account-wrapper > a > h1").removeClass("mobile-go-back-title")
        }), $(".sr_req_add_clickhere").click(function() {
            $(".sr_req_add_step2").removeClass("hidden")
        }), $(".bill_pay_add_new").click(function() {
            $(".add_new_show").removeClass("hidden"), $(".add_new_hide").addClass("hidden")
        }), $(".js_ac-creation-step1").click(function() {
            $(".ac-creation-step1").addClass("hidden"), $(".ac-creation-step2").removeClass("hidden"), window.scrollTo(0, 0)
        }), $(".js_goback_ac_creation_step1").click(function() {
            $(".ac-creation-step1").removeClass("hidden"), $(".ac-creation-step2").addClass("hidden")
        }), $(".js_validate_account").click(function() {
            $(".component-generic-account-wrapper > a > h1").html("SUB DOLLAR VERIFICATION"), $(".ac-creation-step2").addClass("hidden"), $(".ac-creation-step3").removeClass("hidden"), window.scrollTo(0, 0)
        }), $(".js_ac-creation-step3").click(function() {
            $(".ac-creation-step3").addClass("hidden"), $(".ac-creation-step4").removeClass("hidden"), window.scrollTo(0, 0)
        }), $(".js_ac-creation-step4").click(function() {
            $(".component-generic-account-wrapper > a > h1").html("OTP AUTHENTICATION"), $(".ac-creation-step4").addClass("hidden"), $(".ac-creation-step5").removeClass("hidden")
        })
    });
var operating_system = get_operating_system();
/* ZEUX: Replaced , with ; */
$(document).ready(function() {
        $(".js_add_recipient").click(function() {
            $(".my-recipients-list").addClass("hidden"); $(".add-my-recipient").removeClass("hidden");
            $(".tab3-step2").removeClass("hidden"); $(".tab3-step1").addClass("hidden");
        })
        $(".js_view_recipient").click(function() {
            $(".my-recipients-list").addClass("hidden"); $(".view-my-recipient").removeClass("hidden");
        })
        $(".accordian-tab-btn").click(function() {
            $(this).toggleClass("active");
        })
    }),
    function(e) {
        var t;
        e(window).on("resize scroll", function() {
            var n = get_viewport_dimension();
            t = n.width, e("html").hasClass("touch") ? e(window).width() < 768 ? (e(".reciept-header").get(0) && checkOffset2(), e(document).scroll(function() {
                e(".reciept-header").get(0) && checkOffset2()
            })) : e(".reciept-header").attr("style", "") : t < 768 ? (e(".reciept-header").get(0) && checkOffset2(), e(document).scroll(function() {
                e(".reciept-header").get(0) && checkOffset2()
            })) : e(".reciept-header").attr("style", "")
        })
    }(jQuery), $(document).ready(function() {
        $(".js_search").click(function() {
            $(".search-transfer-details").toggleClass("close")
        }), $(".js_search-tablet").click(function() {
            $(".search-transfer-control.tablet-only").toggleClass("close")
        })
    });
var operating_system = get_operating_system();
$(document).ready(function() {
        $(".bill-pay-options a").click(function() {
            var e = $(this).attr("rel");
	            $(".bill-pay-options a").removeClass("active"), $(this).addClass("active"), $(".cd-form." + e).removeClass("hidden"), $(".pending-pay-list").removeClass("hidden")
        }), $(".js_pay-phone").click(function() {
        	$(".pending-bill-payment").addClass("hidden")
        }), $(".js_back_phone_bill").click(function() {
            $(".component-billpay-wrapper").removeClass("payment-step"),$(".step1").removeClass("hidden"),$(".step2").addClass("hidden"),$(".pending-bill-payment").removeClass("hidden")
        }), $(".js_pay-utils").click(function() {
            $(".component-billpay-wrapper").addClass("payment-step"),$(".step1").addClass("hidden"),$(".step2").removeClass("hidden")
        }), $(".js_pay-utils-finish").click(function() {
            $.fancybox([{
                href: "#bill-pay-overview-utils-popup"
            }])
        }), $(".js_back_utils_bill ").click(function() {
            $(".component-billpay-wrapper").removeClass("payment-step"),$(".step1").removeClass("hidden"),$(".step2").addClass("hidden")
        }), $(".js_show_exchange_popup").click(function() {
            $(this).next().removeClass("hidden")
        }), $(".js_hide_exchange_popup").click(function() {
            $(this).addClass("hidden")
        }), $(".js_utils_location").change(function() {
            $(".next-element-1").removeClass("hidden")
        }), $(".js_utils_operator").change(function() {
            $(".next-element-2").removeClass("hidden")
        })
    }),
    function(e) {
        var t;
        e(window).on("resize scroll", function() {
            var n = get_viewport_dimension();
            t = n.width, e("html").hasClass("touch") ? e(window).width() < 1024 ? (e(".table-operations").get(0) && checkOffset_table_operations(), e(document).scroll(function() {
                e(".table-operations").get(0) && checkOffset_table_operations()
            })) : e(".table-operations").attr("style", "") : t < 1024 ? (e(".table-operations").get(0) && checkOffset_table_operations(), e(document).scroll(function() {
                e(".table-operations").get(0) && checkOffset_table_operations()
            })) : e(".table-operations").attr("style", "")
        })
    }(jQuery);
$(".not-yet-member").click(function() {
        $(".pre-login-has-dropdown").removeClass("current"), $(".pre-login-signup-has-dropdown").addClass("current"), $(".body-lock").fadeToggle("fast", "linear"), $("html").addClass("has-flyout")
    }),
    
    /*$(".pw_opt_forgot_user_pass").click(function() { 
    if ($("#cd-radio-1").is(":checked")) {
            $(".pass_reset_step2").removeClass("hidden"), $(".pass_reset_step1").addClass("hidden");
    } else if ($("#cd-radio-2").is(":checked")) {
            $(".pass_reset_step7").removeClass("hidden"), $(".pass_reset_step1").addClass("hidden");
    }
}),*/
$(".pw_otp_pass").click(function() { 
    if ($("#cd-radio-3").is(":checked")) {
            $(".pass_reset_step3").removeClass("hidden"), $(".pass_reset_step2").addClass("hidden");
    } else if ($("#cd-radio-32").is(":checked")) {
            $(".pass_reset_step32").removeClass("hidden"), $(".pass_reset_step2").addClass("hidden");
    }
}),

    $(".already-member").click(function() {
        $(".pre-login-signup-has-dropdown").removeClass("current"), $(".pre-login-has-dropdown").addClass("current"), $(".body-lock").fadeToggle("fast", "linear"), $("html").addClass("has-flyout")
    }),
    
    $(".tri-rect").on('click','.add-active-bank-account', function() {
                $(".add-active-bank-account").removeClass("selected"), $(".add-active-bank-account").children(".rem_acc_item_statusdot").removeClass("green-bullet"), $(".add-active-bank-account").children(".rem_acc_item_statusdot").addClass("red-bullet"), $(this).addClass("selected"), $(this).children(".rem_acc_item_statusdot").removeClass("red-bullet"), $(this).children(".rem_acc_item_statusdot").addClass("green-bullet")
            }),
            $("#home_SendMoney").click(function() {
                $("#hide_on_login").removeClass("hidden"), $("#show_on_login").addClass("hidden"),$(".makepayment_hide_on_login").removeClass("hidden"), $(".makepayment_show_on_login").addClass("hidden")
            }), $("#home_MakePayments").click(function() {
                $(".PayBillLoginSection").removeClass("hidden"), $(".PayBillUIDPassSection").addClass("hidden") }),    
                
                $("#home_login_opt4").click(function() {
                    $(".PayBillLoginSection").addClass("hidden"), $(".PayBillUIDPassSection").removeClass("hidden")
                }),      
                $("#home_MakePaymentsfooter").click(function() {
                    $(".PayBillLoginSection").removeClass("hidden"), $(".PayBillUIDPassSection").addClass("hidden") }),
            
            
$("#home_login_opt1").click(function() {
    $("#hide_on_login").addClass("hidden"), $("#show_on_login").removeClass("hidden")
}),$(".makepayment-button").click(function() {
    $(".makepayment_hide_on_login").addClass("hidden"), $(".makepayment_show_on_login").removeClass("hidden")
}),$(".home_sendmoney_login_back").click(function() {
    $("#hide_on_login").removeClass("hidden"), $("#show_on_login").addClass("hidden")
}),$(".home_sendmoney_login_back11").click(function() {
    $(".makepayment_hide_on_login").removeClass("hidden"), $(".makepayment_show_on_login").addClass("hidden")
}),$(".home_MakePayments_login_back").click(function() {
    $(".PayBillLoginSection").removeClass("hidden"), $(".PayBillUIDPassSection").addClass("hidden")
});

$(".cont-rgr").click(function() {
	window.onbeforeunload = function () {
		  window.scrollTo(0, 0);
		}
});

$(document).ready(function(){
	if(document.getElementById('nav-id') ==null){
		$('.icici-m2i-header').css('border-bottom','1px solid #f5821f');
	}
				
});

//==========================================================================================
//******************************* DOBOZ Start ***********************************************

//modernizr
/*!
* Modernizr v2.8.3
* www.modernizr.com
*
* Copyright (c) Faruk Ates, Paul Irish, Alex Sexton
* Available under the BSD and MIT licenses: www.modernizr.com/license/
*/

/*
* Modernizr tests which native CSS3 and HTML5 features are available in
* the current UA and makes the results available to you in two ways:
* as properties on a global Modernizr object, and as classes on the
* <html> element. This information allows you to progressively enhance
* your pages with a granular level of control over the experience.
*
* Modernizr has an optional (not included) conditional resource loader
* called Modernizr.load(), based on Yepnope.js (yepnopejs.com).
* To get a build that includes Modernizr.load(), as well as choosing
* which tests to include, go to www.modernizr.com/download/
*
* Authors        Faruk Ates, Paul Irish, Alex Sexton
* Contributors   Ryan Seddon, Ben Alman
*/

window.Modernizr = (function( window, document, undefined ) {

 var version = '2.8.3',

 Modernizr = {},

 /*>>cssclasses*/
 // option for enabling the HTML classes to be added
 enableClasses = true,
 /*>>cssclasses*/

 docElement = document.documentElement,

 /**
  * Create our "modernizr" element that we do most feature tests on.
  */
 mod = 'modernizr',
 modElem = document.createElement(mod),
 mStyle = modElem.style,

 /**
  * Create the input element for various Web Forms feature tests.
  */
 inputElem /*>>inputelem*/ = document.createElement('input') /*>>inputelem*/ ,

 /*>>smile*/
 smile = ':)',
 /*>>smile*/

 toString = {}.toString,

 // TODO :: make the prefixes more granular
 /*>>prefixes*/
 // List of property values to set for css tests. See ticket #21
 prefixes = ' -webkit- -moz- -o- -ms- '.split(' '),
 /*>>prefixes*/

 /*>>domprefixes*/
 // Following spec is to expose vendor-specific style properties as:
 //   elem.style.WebkitBorderRadius
 // and the following would be incorrect:
 //   elem.style.webkitBorderRadius

 // Webkit ghosts their properties in lowercase but Opera & Moz do not.
 // Microsoft uses a lowercase `ms` instead of the correct `Ms` in IE8+
 //   erik.eae.net/archives/2008/03/10/21.48.10/

 // More here: github.com/Modernizr/Modernizr/issues/issue/21
 omPrefixes = 'Webkit Moz O ms',

 cssomPrefixes = omPrefixes.split(' '),

 domPrefixes = omPrefixes.toLowerCase().split(' '),
 /*>>domprefixes*/

 /*>>ns*/
 ns = {'svg': 'http://www.w3.org/2000/svg'},
 /*>>ns*/

 tests = {},
 inputs = {},
 attrs = {},

 classes = [],

 slice = classes.slice,

 featureName, // used in testing loop


 /*>>teststyles*/
 // Inject element with style element and some CSS rules
 injectElementWithStyles = function( rule, callback, nodes, testnames ) {

   var style, ret, node, docOverflow,
       div = document.createElement('div'),
       // After page load injecting a fake body doesn't work so check if body exists
       body = document.body,
       // IE6 and 7 won't return offsetWidth or offsetHeight unless it's in the body element, so we fake it.
       fakeBody = body || document.createElement('body');

   if ( parseInt(nodes, 10) ) {
       // In order not to give false positives we create a node for each test
       // This also allows the method to scale for unspecified uses
       while ( nodes-- ) {
           node = document.createElement('div');
           node.id = testnames ? testnames[nodes] : mod + (nodes + 1);
           div.appendChild(node);
       }
   }

   // <style> elements in IE6-9 are considered 'NoScope' elements and therefore will be removed
   // when injected with innerHTML. To get around this you need to prepend the 'NoScope' element
   // with a 'scoped' element, in our case the soft-hyphen entity as it won't mess with our measurements.
   // msdn.microsoft.com/en-us/library/ms533897%28VS.85%29.aspx
   // Documents served as xml will throw if using &shy; so use xml friendly encoded version. See issue #277
   style = ['&#173;','<style id="s', mod, '">', rule, '</style>'].join('');
   div.id = mod;
   // IE6 will false positive on some tests due to the style element inside the test div somehow interfering offsetHeight, so insert it into body or fakebody.
   // Opera will act all quirky when injecting elements in documentElement when page is served as xml, needs fakebody too. #270
   (body ? div : fakeBody).innerHTML += style;
   fakeBody.appendChild(div);
   if ( !body ) {
       //avoid crashing IE8, if background image is used
       fakeBody.style.background = '';
       //Safari 5.13/5.1.4 OSX stops loading if ::-webkit-scrollbar is used and scrollbars are visible
       fakeBody.style.overflow = 'hidden';
       docOverflow = docElement.style.overflow;
       docElement.style.overflow = 'hidden';
       docElement.appendChild(fakeBody);
   }

   ret = callback(div, rule);
   // If this is done after page load we don't want to remove the body so check if body exists
   if ( !body ) {
       fakeBody.parentNode.removeChild(fakeBody);
       docElement.style.overflow = docOverflow;
   } else {
       div.parentNode.removeChild(div);
   }

   return !!ret;

 },
 /*>>teststyles*/

 /*>>mq*/
 // adapted from matchMedia polyfill
 // by Scott Jehl and Paul Irish
 // gist.github.com/786768
 testMediaQuery = function( mq ) {

   var matchMedia = window.matchMedia || window.msMatchMedia;
   if ( matchMedia ) {
     return matchMedia(mq) && matchMedia(mq).matches || false;
   }

   var bool;

   injectElementWithStyles('@media ' + mq + ' { #' + mod + ' { position: absolute; } }', function( node ) {
     bool = (window.getComputedStyle ?
               getComputedStyle(node, null) :
               node.currentStyle)['position'] == 'absolute';
   });

   return bool;

  },
  /*>>mq*/


 /*>>hasevent*/
 //
 // isEventSupported determines if a given element supports the given event
 // kangax.github.com/iseventsupported/
 //
 // The following results are known incorrects:
 //   Modernizr.hasEvent("webkitTransitionEnd", elem) // false negative
 //   Modernizr.hasEvent("textInput") // in Webkit. github.com/Modernizr/Modernizr/issues/333
 //   ...
 isEventSupported = (function() {

   var TAGNAMES = {
     'select': 'input', 'change': 'input',
     'submit': 'form', 'reset': 'form',
     'error': 'img', 'load': 'img', 'abort': 'img'
   };

   function isEventSupported( eventName, element ) {

     element = element || document.createElement(TAGNAMES[eventName] || 'div');
     eventName = 'on' + eventName;

     // When using `setAttribute`, IE skips "unload", WebKit skips "unload" and "resize", whereas `in` "catches" those
     var isSupported = eventName in element;

     if ( !isSupported ) {
       // If it has no `setAttribute` (i.e. doesn't implement Node interface), try generic element
       if ( !element.setAttribute ) {
         element = document.createElement('div');
       }
       if ( element.setAttribute && element.removeAttribute ) {
         element.setAttribute(eventName, '');
         isSupported = is(element[eventName], 'function');

         // If property was created, "remove it" (by setting value to `undefined`)
         if ( !is(element[eventName], 'undefined') ) {
           element[eventName] = undefined;
         }
         element.removeAttribute(eventName);
       }
     }

     element = null;
     return isSupported;
   }
   return isEventSupported;
 })(),
 /*>>hasevent*/

 // TODO :: Add flag for hasownprop ? didn't last time

 // hasOwnProperty shim by kangax needed for Safari 2.0 support
 _hasOwnProperty = ({}).hasOwnProperty, hasOwnProp;

 if ( !is(_hasOwnProperty, 'undefined') && !is(_hasOwnProperty.call, 'undefined') ) {
   hasOwnProp = function (object, property) {
     return _hasOwnProperty.call(object, property);
   };
 }
 else {
   hasOwnProp = function (object, property) { /* yes, this can give false positives/negatives, but most of the time we don't care about those */
     return ((property in object) && is(object.constructor.prototype[property], 'undefined'));
   };
 }

 // Adapted from ES5-shim https://github.com/kriskowal/es5-shim/blob/master/es5-shim.js
 // es5.github.com/#x15.3.4.5

 if (!Function.prototype.bind) {
   Function.prototype.bind = function bind(that) {

     var target = this;

     if (typeof target != "function") {
         throw new TypeError();
     }

     var args = slice.call(arguments, 1),
         bound = function () {

         if (this instanceof bound) {

           var F = function(){};
           F.prototype = target.prototype;
           var self = new F();

           var result = target.apply(
               self,
               args.concat(slice.call(arguments))
           );
           if (Object(result) === result) {
               return result;
           }
           return self;

         } else {

           return target.apply(
               that,
               args.concat(slice.call(arguments))
           );

         }

     };

     return bound;
   };
 }

 /**
  * setCss applies given styles to the Modernizr DOM node.
  */
 function setCss( str ) {
     mStyle.cssText = str;
 }

 /**
  * setCssAll extrapolates all vendor-specific css strings.
  */
 function setCssAll( str1, str2 ) {
     return setCss(prefixes.join(str1 + ';') + ( str2 || '' ));
 }

 /**
  * is returns a boolean for if typeof obj is exactly type.
  */
 function is( obj, type ) {
     return typeof obj === type;
 }

 /**
  * contains returns a boolean for if substr is found within str.
  */
 function contains( str, substr ) {
     return !!~('' + str).indexOf(substr);
 }

 /*>>testprop*/

 // testProps is a generic CSS / DOM property test.

 // In testing support for a given CSS property, it's legit to test:
 //    `elem.style[styleName] !== undefined`
 // If the property is supported it will return an empty string,
 // if unsupported it will return undefined.

 // We'll take advantage of this quick test and skip setting a style
 // on our modernizr element, but instead just testing undefined vs
 // empty string.

 // Because the testing of the CSS property names (with "-", as
 // opposed to the camelCase DOM properties) is non-portable and
 // non-standard but works in WebKit and IE (but not Gecko or Opera),
 // we explicitly reject properties with dashes so that authors
 // developing in WebKit or IE first don't end up with
 // browser-specific content by accident.

 function testProps( props, prefixed ) {
     for ( var i in props ) {
         var prop = props[i];
         if ( !contains(prop, "-") && mStyle[prop] !== undefined ) {
             return prefixed == 'pfx' ? prop : true;
         }
     }
     return false;
 }
 /*>>testprop*/

 // TODO :: add testDOMProps
 /**
  * testDOMProps is a generic DOM property test; if a browser supports
  *   a certain property, it won't return undefined for it.
  */
 function testDOMProps( props, obj, elem ) {
     for ( var i in props ) {
         var item = obj[props[i]];
         if ( item !== undefined) {

             // return the property name as a string
             if (elem === false) return props[i];

             // let's bind a function
             if (is(item, 'function')){
               // default to autobind unless override
               return item.bind(elem || obj);
             }

             // return the unbound function or obj or value
             return item;
         }
     }
     return false;
 }

 /*>>testallprops*/
 /**
  * testPropsAll tests a list of DOM properties we want to check against.
  *   We specify literally ALL possible (known and/or likely) properties on
  *   the element including the non-vendor prefixed one, for forward-
  *   compatibility.
  */
 function testPropsAll( prop, prefixed, elem ) {

     var ucProp  = prop.charAt(0).toUpperCase() + prop.slice(1),
         props   = (prop + ' ' + cssomPrefixes.join(ucProp + ' ') + ucProp).split(' ');

     // did they call .prefixed('boxSizing') or are we just testing a prop?
     if(is(prefixed, "string") || is(prefixed, "undefined")) {
       return testProps(props, prefixed);

     // otherwise, they called .prefixed('requestAnimationFrame', window[, elem])
     } else {
       props = (prop + ' ' + (domPrefixes).join(ucProp + ' ') + ucProp).split(' ');
       return testDOMProps(props, prefixed, elem);
     }
 }
 /*>>testallprops*/


 /**
  * Tests
  * -----
  */

 // The *new* flexbox
 // dev.w3.org/csswg/css3-flexbox

 tests['flexbox'] = function() {
   return testPropsAll('flexWrap');
 };

 // The *old* flexbox
 // www.w3.org/TR/2009/WD-css3-flexbox-20090723/

 tests['flexboxlegacy'] = function() {
     return testPropsAll('boxDirection');
 };

 // On the S60 and BB Storm, getContext exists, but always returns undefined
 // so we actually have to call getContext() to verify
 // github.com/Modernizr/Modernizr/issues/issue/97/

 tests['canvas'] = function() {
     var elem = document.createElement('canvas');
     return !!(elem.getContext && elem.getContext('2d'));
 };

 tests['canvastext'] = function() {
     return !!(Modernizr['canvas'] && is(document.createElement('canvas').getContext('2d').fillText, 'function'));
 };

 // webk.it/70117 is tracking a legit WebGL feature detect proposal

 // We do a soft detect which may false positive in order to avoid
 // an expensive context creation: bugzil.la/732441

 tests['webgl'] = function() {
     return !!window.WebGLRenderingContext;
 };

 /*
  * The Modernizr.touch test only indicates if the browser supports
  *    touch events, which does not necessarily reflect a touchscreen
  *    device, as evidenced by tablets running Windows 7 or, alas,
  *    the Palm Pre / WebOS (touch) phones.
  *
  * Additionally, Chrome (desktop) used to lie about its support on this,
  *    but that has since been rectified: crbug.com/36415
  *
  * We also test for Firefox 4 Multitouch Support.
  *
  * For more info, see: modernizr.github.com/Modernizr/touch.html
  */

 tests['touch'] = function() {
     var bool;

     if(('ontouchstart' in window) || window.DocumentTouch && document instanceof DocumentTouch) {
       bool = true;
     } else {
       injectElementWithStyles(['@media (',prefixes.join('touch-enabled),('),mod,')','{#modernizr{top:9px;position:absolute}}'].join(''), function( node ) {
         bool = node.offsetTop === 9;
       });
     }

     return bool;
 };


 // geolocation is often considered a trivial feature detect...
 // Turns out, it's quite tricky to get right:
 //
 // Using !!navigator.geolocation does two things we don't want. It:
 //   1. Leaks memory in IE9: github.com/Modernizr/Modernizr/issues/513
 //   2. Disables page caching in WebKit: webk.it/43956
 //
 // Meanwhile, in Firefox < 8, an about:config setting could expose
 // a false positive that would throw an exception: bugzil.la/688158

 tests['geolocation'] = function() {
     return 'geolocation' in navigator;
 };


 tests['postmessage'] = function() {
   return !!window.postMessage;
 };


 // Chrome incognito mode used to throw an exception when using openDatabase
 // It doesn't anymore.
 tests['websqldatabase'] = function() {
   return !!window.openDatabase;
 };

 // Vendors had inconsistent prefixing with the experimental Indexed DB:
 // - Webkit's implementation is accessible through webkitIndexedDB
 // - Firefox shipped moz_indexedDB before FF4b9, but since then has been mozIndexedDB
 // For speed, we don't test the legacy (and beta-only) indexedDB
 tests['indexedDB'] = function() {
   return !!testPropsAll("indexedDB", window);
 };

 // documentMode logic from YUI to filter out IE8 Compat Mode
 //   which false positives.
 tests['hashchange'] = function() {
   return isEventSupported('hashchange', window) && (document.documentMode === undefined || document.documentMode > 7);
 };

 // Per 1.6:
 // This used to be Modernizr.historymanagement but the longer
 // name has been deprecated in favor of a shorter and property-matching one.
 // The old API is still available in 1.6, but as of 2.0 will throw a warning,
 // and in the first release thereafter disappear entirely.
 tests['history'] = function() {
   return !!(window.history && history.pushState);
 };

 tests['draganddrop'] = function() {
     var div = document.createElement('div');
     return ('draggable' in div) || ('ondragstart' in div && 'ondrop' in div);
 };

 // FF3.6 was EOL'ed on 4/24/12, but the ESR version of FF10
 // will be supported until FF19 (2/12/13), at which time, ESR becomes FF17.
 // FF10 still uses prefixes, so check for it until then.
 // for more ESR info, see: mozilla.org/en-US/firefox/organizations/faq/
 tests['websockets'] = function() {
     return 'WebSocket' in window || 'MozWebSocket' in window;
 };


 // css-tricks.com/rgba-browser-support/
 tests['rgba'] = function() {
     // Set an rgba() color and check the returned value

     setCss('background-color:rgba(150,255,150,.5)');

     return contains(mStyle.backgroundColor, 'rgba');
 };

 tests['hsla'] = function() {
     // Same as rgba(), in fact, browsers re-map hsla() to rgba() internally,
     //   except IE9 who retains it as hsla

     setCss('background-color:hsla(120,40%,100%,.5)');

     return contains(mStyle.backgroundColor, 'rgba') || contains(mStyle.backgroundColor, 'hsla');
 };

 tests['multiplebgs'] = function() {
     // Setting multiple images AND a color on the background shorthand property
     //  and then querying the style.background property value for the number of
     //  occurrences of "url(" is a reliable method for detecting ACTUAL support for this!

     setCss('background:url(https://),url(https://),red url(https://)');

     // If the UA supports multiple backgrounds, there should be three occurrences
     //   of the string "url(" in the return value for elemStyle.background

     return (/(url\s*\(.*?){3}/).test(mStyle.background);
 };



 // this will false positive in Opera Mini
 //   github.com/Modernizr/Modernizr/issues/396

 tests['backgroundsize'] = function() {
     return testPropsAll('backgroundSize');
 };

 tests['borderimage'] = function() {
     return testPropsAll('borderImage');
 };


 // Super comprehensive table about all the unique implementations of
 // border-radius: muddledramblings.com/table-of-css3-border-radius-compliance

 tests['borderradius'] = function() {
     return testPropsAll('borderRadius');
 };

 // WebOS unfortunately false positives on this test.
 tests['boxshadow'] = function() {
     return testPropsAll('boxShadow');
 };

 // FF3.0 will false positive on this test
 tests['textshadow'] = function() {
     return document.createElement('div').style.textShadow === '';
 };


 tests['opacity'] = function() {
     // Browsers that actually have CSS Opacity implemented have done so
     //  according to spec, which means their return values are within the
     //  range of [0.0,1.0] - including the leading zero.

     setCssAll('opacity:.55');

     // The non-literal . in this regex is intentional:
     //   German Chrome returns this value as 0,55
     // github.com/Modernizr/Modernizr/issues/#issue/59/comment/516632
     return (/^0.55$/).test(mStyle.opacity);
 };


 // Note, Android < 4 will pass this test, but can only animate
 //   a single property at a time
 //   goo.gl/v3V4Gp
 tests['cssanimations'] = function() {
     return testPropsAll('animationName');
 };


 tests['csscolumns'] = function() {
     return testPropsAll('columnCount');
 };


 tests['cssgradients'] = function() {
     /**
      * For CSS Gradients syntax, please see:
      * webkit.org/blog/175/introducing-css-gradients/
      * developer.mozilla.org/en/CSS/-moz-linear-gradient
      * developer.mozilla.org/en/CSS/-moz-radial-gradient
      * dev.w3.org/csswg/css3-images/#gradients-
      */

     var str1 = 'background-image:',
         str2 = 'gradient(linear,left top,right bottom,from(#9f9),to(white));',
         str3 = 'linear-gradient(left top,#9f9, white);';

     setCss(
          // legacy webkit syntax (FIXME: remove when syntax not in use anymore)
           (str1 + '-webkit- '.split(' ').join(str2 + str1) +
          // standard syntax             // trailing 'background-image:'
           prefixes.join(str3 + str1)).slice(0, -str1.length)
     );

     return contains(mStyle.backgroundImage, 'gradient');
 };


 tests['cssreflections'] = function() {
     return testPropsAll('boxReflect');
 };


 tests['csstransforms'] = function() {
     return !!testPropsAll('transform');
 };


 tests['csstransforms3d'] = function() {

     var ret = !!testPropsAll('perspective');

     // Webkit's 3D transforms are passed off to the browser's own graphics renderer.
     //   It works fine in Safari on Leopard and Snow Leopard, but not in Chrome in
     //   some conditions. As a result, Webkit typically recognizes the syntax but
     //   will sometimes throw a false positive, thus we must do a more thorough check:
     if ( ret && 'webkitPerspective' in docElement.style ) {

       // Webkit allows this media query to succeed only if the feature is enabled.
       // `@media (transform-3d),(-webkit-transform-3d){ ... }`
       injectElementWithStyles('@media (transform-3d),(-webkit-transform-3d){#modernizr{left:9px;position:absolute;height:3px;}}', function( node, rule ) {
         ret = node.offsetLeft === 9 && node.offsetHeight === 3;
       });
     }
     return ret;
 };


 tests['csstransitions'] = function() {
     return testPropsAll('transition');
 };


 /*>>fontface*/
 // @font-face detection routine by Diego Perini
 // javascript.nwbox.com/CSSSupport/

 // false positives:
 //   WebOS github.com/Modernizr/Modernizr/issues/342
 //   WP7   github.com/Modernizr/Modernizr/issues/538
 tests['fontface'] = function() {
     var bool;

     injectElementWithStyles('@font-face {font-family:"font";src:url("https://")}', function( node, rule ) {
       var style = document.getElementById('smodernizr'),
           sheet = style.sheet || style.styleSheet,
           cssText = sheet ? (sheet.cssRules && sheet.cssRules[0] ? sheet.cssRules[0].cssText : sheet.cssText || '') : '';

       bool = /src/i.test(cssText) && cssText.indexOf(rule.split(' ')[0]) === 0;
     });

     return bool;
 };
 /*>>fontface*/

 // CSS generated content detection
 tests['generatedcontent'] = function() {
     var bool;

     injectElementWithStyles(['#',mod,'{font:0/0 a}#',mod,':after{content:"',smile,'";visibility:hidden;font:3px/1 a}'].join(''), function( node ) {
       bool = node.offsetHeight >= 3;
     });

     return bool;
 };



 // These tests evaluate support of the video/audio elements, as well as
 // testing what types of content they support.
 //
 // We're using the Boolean constructor here, so that we can extend the value
 // e.g.  Modernizr.video     // true
 //       Modernizr.video.ogg // 'probably'
 //
 // Codec values from : github.com/NielsLeenheer/html5test/blob/9106a8/index.html#L845
 //                     thx to NielsLeenheer and zcorpan

 // Note: in some older browsers, "no" was a return value instead of empty string.
 //   It was live in FF3.5.0 and 3.5.1, but fixed in 3.5.2
 //   It was also live in Safari 4.0.0 - 4.0.4, but fixed in 4.0.5

 tests['video'] = function() {
     var elem = document.createElement('video'),
         bool = false;

     // IE9 Running on Windows Server SKU can cause an exception to be thrown, bug #224
     try {
         if ( bool = !!elem.canPlayType ) {
             bool      = new Boolean(bool);
             bool.ogg  = elem.canPlayType('video/ogg; codecs="theora"')      .replace(/^no$/,'');

             // Without QuickTime, this value will be `undefined`. github.com/Modernizr/Modernizr/issues/546
             bool.h264 = elem.canPlayType('video/mp4; codecs="avc1.42E01E"') .replace(/^no$/,'');

             bool.webm = elem.canPlayType('video/webm; codecs="vp8, vorbis"').replace(/^no$/,'');
         }

     } catch(e) { }

     return bool;
 };

 tests['audio'] = function() {
     var elem = document.createElement('audio'),
         bool = false;

     try {
         if ( bool = !!elem.canPlayType ) {
             bool      = new Boolean(bool);
             bool.ogg  = elem.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,'');
             bool.mp3  = elem.canPlayType('audio/mpeg;')               .replace(/^no$/,'');

             // Mimetypes accepted:
             //   developer.mozilla.org/En/Media_formats_supported_by_the_audio_and_video_elements
             //   bit.ly/iphoneoscodecs
             bool.wav  = elem.canPlayType('audio/wav; codecs="1"')     .replace(/^no$/,'');
             bool.m4a  = ( elem.canPlayType('audio/x-m4a;')            ||
                           elem.canPlayType('audio/aac;'))             .replace(/^no$/,'');
         }
     } catch(e) { }

     return bool;
 };


 // In FF4, if disabled, window.localStorage should === null.

 // Normally, we could not test that directly and need to do a
 //   `('localStorage' in window) && ` test first because otherwise Firefox will
 //   throw bugzil.la/365772 if cookies are disabled

 // Also in iOS5 Private Browsing mode, attempting to use localStorage.setItem
 // will throw the exception:
 //   QUOTA_EXCEEDED_ERRROR DOM Exception 22.
 // Peculiarly, getItem and removeItem calls do not throw.

 // Because we are forced to try/catch this, we'll go aggressive.

 // Just FWIW: IE8 Compat mode supports these features completely:
 //   www.quirksmode.org/dom/html5.html
 // But IE8 doesn't support either with local files

 tests['localstorage'] = function() {
     try {
         localStorage.setItem(mod, mod);
         localStorage.removeItem(mod);
         return true;
     } catch(e) {
         return false;
     }
 };

 tests['sessionstorage'] = function() {
     try {
         sessionStorage.setItem(mod, mod);
         sessionStorage.removeItem(mod);
         return true;
     } catch(e) {
         return false;
     }
 };


 tests['webworkers'] = function() {
     return !!window.Worker;
 };


 tests['applicationcache'] = function() {
     return !!window.applicationCache;
 };


 // Thanks to Erik Dahlstrom
 tests['svg'] = function() {
     return !!document.createElementNS && !!document.createElementNS(ns.svg, 'svg').createSVGRect;
 };

 // specifically for SVG inline in HTML, not within XHTML
 // test page: paulirish.com/demo/inline-svg
 tests['inlinesvg'] = function() {
   var div = document.createElement('div');
   div.innerHTML = '<svg/>';
   return (div.firstChild && div.firstChild.namespaceURI) == ns.svg;
 };

 // SVG SMIL animation
 tests['smil'] = function() {
     return !!document.createElementNS && /SVGAnimate/.test(toString.call(document.createElementNS(ns.svg, 'animate')));
 };

 // This test is only for clip paths in SVG proper, not clip paths on HTML content
 // demo: srufaculty.sru.edu/david.dailey/svg/newstuff/clipPath4.svg

 // However read the comments to dig into applying SVG clippaths to HTML content here:
 //   github.com/Modernizr/Modernizr/issues/213#issuecomment-1149491
 tests['svgclippaths'] = function() {
     return !!document.createElementNS && /SVGClipPath/.test(toString.call(document.createElementNS(ns.svg, 'clipPath')));
 };

 /*>>webforms*/
 // input features and input types go directly onto the ret object, bypassing the tests loop.
 // Hold this guy to execute in a moment.
 function webforms() {
     /*>>input*/
     // Run through HTML5's new input attributes to see if the UA understands any.
     // We're using f which is the <input> element created early on
     // Mike Taylr has created a comprehensive resource for testing these attributes
     //   when applied to all input types:
     //   miketaylr.com/code/input-type-attr.html
     // spec: www.whatwg.org/specs/web-apps/current-work/multipage/the-input-element.html#input-type-attr-summary

     // Only input placeholder is tested while textarea's placeholder is not.
     // Currently Safari 4 and Opera 11 have support only for the input placeholder
     // Both tests are available in feature-detects/forms-placeholder.js
     Modernizr['input'] = (function( props ) {
         for ( var i = 0, len = props.length; i < len; i++ ) {
             attrs[ props[i] ] = !!(props[i] in inputElem);
         }
         if (attrs.list){
           // safari false positive's on datalist: webk.it/74252
           // see also github.com/Modernizr/Modernizr/issues/146
           attrs.list = !!(document.createElement('datalist') && window.HTMLDataListElement);
         }
         return attrs;
     })('autocomplete autofocus list placeholder max min multiple pattern required step'.split(' '));
     /*>>input*/

     /*>>inputtypes*/
     // Run through HTML5's new input types to see if the UA understands any.
     //   This is put behind the tests runloop because it doesn't return a
     //   true/false like all the other tests; instead, it returns an object
     //   containing each input type with its corresponding true/false value

     // Big thanks to @miketaylr for the html5 forms expertise. miketaylr.com/
     Modernizr['inputtypes'] = (function(props) {

         for ( var i = 0, bool, inputElemType, defaultView, len = props.length; i < len; i++ ) {

             inputElem.setAttribute('type', inputElemType = props[i]);
             bool = inputElem.type !== 'text';

             // We first check to see if the type we give it sticks..
             // If the type does, we feed it a textual value, which shouldn't be valid.
             // If the value doesn't stick, we know there's input sanitization which infers a custom UI
             if ( bool ) {

                 inputElem.value         = smile;
                 inputElem.style.cssText = 'position:absolute;visibility:hidden;';

                 if ( /^range$/.test(inputElemType) && inputElem.style.WebkitAppearance !== undefined ) {

                   docElement.appendChild(inputElem);
                   defaultView = document.defaultView;

                   // Safari 2-4 allows the smiley as a value, despite making a slider
                   bool =  defaultView.getComputedStyle &&
                           defaultView.getComputedStyle(inputElem, null).WebkitAppearance !== 'textfield' &&
                           // Mobile android web browser has false positive, so must
                           // check the height to see if the widget is actually there.
                           (inputElem.offsetHeight !== 0);

                   docElement.removeChild(inputElem);

                 } else if ( /^(search|tel)$/.test(inputElemType) ){
                   // Spec doesn't define any special parsing or detectable UI
                   //   behaviors so we pass these through as true

                   // Interestingly, opera fails the earlier test, so it doesn't
                   //  even make it here.

                 } else if ( /^(url|email)$/.test(inputElemType) ) {
                   // Real url and email support comes with prebaked validation.
                   bool = inputElem.checkValidity && inputElem.checkValidity() === false;

                 } else {
                   // If the upgraded input compontent rejects the :) text, we got a winner
                   bool = inputElem.value != smile;
                 }
             }

             inputs[ props[i] ] = !!bool;
         }
         return inputs;
     })('search tel url email datetime date month week time datetime-local number range color'.split(' '));
     /*>>inputtypes*/
 }
 /*>>webforms*/


 // End of test definitions
 // -----------------------



 // Run through all tests and detect their support in the current UA.
 // todo: hypothetically we could be doing an array of tests and use a basic loop here.
 for ( var feature in tests ) {
     if ( hasOwnProp(tests, feature) ) {
         // run the test, throw the return value into the Modernizr,
         //   then based on that boolean, define an appropriate className
         //   and push it into an array of classes we'll join later.
         featureName  = feature.toLowerCase();
         Modernizr[featureName] = tests[feature]();

         classes.push((Modernizr[featureName] ? '' : 'no-') + featureName);
     }
 }

 /*>>webforms*/
 // input tests need to run.
 Modernizr.input || webforms();
 /*>>webforms*/


 /**
  * addTest allows the user to define their own feature tests
  * the result will be added onto the Modernizr object,
  * as well as an appropriate className set on the html element
  *
  * @param feature - String naming the feature
  * @param test - Function returning true if feature is supported, false if not
  */
  Modernizr.addTest = function ( feature, test ) {
    if ( typeof feature == 'object' ) {
      for ( var key in feature ) {
        if ( hasOwnProp( feature, key ) ) {
          Modernizr.addTest( key, feature[ key ] );
        }
      }
    } else {

      feature = feature.toLowerCase();

      if ( Modernizr[feature] !== undefined ) {
        // we're going to quit if you're trying to overwrite an existing test
        // if we were to allow it, we'd do this:
        //   var re = new RegExp("\\b(no-)?" + feature + "\\b");
        //   docElement.className = docElement.className.replace( re, '' );
        // but, no rly, stuff 'em.
        return Modernizr;
      }

      test = typeof test == 'function' ? test() : test;

      if (typeof enableClasses !== "undefined" && enableClasses) {
        docElement.className += ' ' + (test ? '' : 'no-') + feature;
      }
      Modernizr[feature] = test;

    }

    return Modernizr; // allow chaining.
  };


 // Reset modElem.cssText to nothing to reduce memory footprint.
 setCss('');
 modElem = inputElem = null;

 /*>>shiv*/
 /**
  * @preserve HTML5 Shiv prev3.7.1 | @afarkas @jdalton @jon_neal @rem | MIT/GPL2 Licensed
  */
 ;(function(window, document) {
     /*jshint evil:true */
     /** version */
     var version = '3.7.0';

     /** Preset options */
     var options = window.html5 || {};

     /** Used to skip problem elements */
     var reSkip = /^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i;

     /** Not all elements can be cloned in IE **/
     var saveClones = /^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i;

     /** Detect whether the browser supports default html5 styles */
     var supportsHtml5Styles;

     /** Name of the expando, to work with multiple documents or to re-shiv one document */
     var expando = '_html5shiv';

     /** The id for the the documents expando */
     var expanID = 0;

     /** Cached data for each document */
     var expandoData = {};

     /** Detect whether the browser supports unknown elements */
     var supportsUnknownElements;

     (function() {
       try {
         var a = document.createElement('a');
         a.innerHTML = '<xyz></xyz>';
         //if the hidden property is implemented we can assume, that the browser supports basic HTML5 Styles
         supportsHtml5Styles = ('hidden' in a);

         supportsUnknownElements = a.childNodes.length == 1 || (function() {
           // assign a false positive if unable to shiv
           (document.createElement)('a');
           var frag = document.createDocumentFragment();
           return (
             typeof frag.cloneNode == 'undefined' ||
             typeof frag.createDocumentFragment == 'undefined' ||
             typeof frag.createElement == 'undefined'
           );
         }());
       } catch(e) {
         // assign a false positive if detection fails => unable to shiv
         supportsHtml5Styles = true;
         supportsUnknownElements = true;
       }

     }());

     /*--------------------------------------------------------------------------*/

     /**
      * Creates a style sheet with the given CSS text and adds it to the document.
      * @private
      * @param {Document} ownerDocument The document.
      * @param {String} cssText The CSS text.
      * @returns {StyleSheet} The style element.
      */
     function addStyleSheet(ownerDocument, cssText) {
       var p = ownerDocument.createElement('p'),
       parent = ownerDocument.getElementsByTagName('head')[0] || ownerDocument.documentElement;

       p.innerHTML = 'x<style>' + cssText + '</style>';
       return parent.insertBefore(p.lastChild, parent.firstChild);
     }

     /**
      * Returns the value of `html5.elements` as an array.
      * @private
      * @returns {Array} An array of shived element node names.
      */
     function getElements() {
       var elements = html5.elements;
       return typeof elements == 'string' ? elements.split(' ') : elements;
     }

     /**
      * Returns the data associated to the given document
      * @private
      * @param {Document} ownerDocument The document.
      * @returns {Object} An object of data.
      */
     function getExpandoData(ownerDocument) {
       var data = expandoData[ownerDocument[expando]];
       if (!data) {
         data = {};
         expanID++;
         ownerDocument[expando] = expanID;
         expandoData[expanID] = data;
       }
       return data;
     }

     /**
      * returns a shived element for the given nodeName and document
      * @memberOf html5
      * @param {String} nodeName name of the element
      * @param {Document} ownerDocument The context document.
      * @returns {Object} The shived element.
      */
     function createElement(nodeName, ownerDocument, data){
       if (!ownerDocument) {
         ownerDocument = document;
       }
       if(supportsUnknownElements){
         return ownerDocument.createElement(nodeName);
       }
       if (!data) {
         data = getExpandoData(ownerDocument);
       }
       var node;

       if (data.cache[nodeName]) {
         node = data.cache[nodeName].cloneNode();
       } else if (saveClones.test(nodeName)) {
         node = (data.cache[nodeName] = data.createElem(nodeName)).cloneNode();
       } else {
         node = data.createElem(nodeName);
       }

       // Avoid adding some elements to fragments in IE < 9 because
       // * Attributes like `name` or `type` cannot be set/changed once an element
       //   is inserted into a document/fragment
       // * Link elements with `src` attributes that are inaccessible, as with
       //   a 403 response, will cause the tab/window to crash
       // * Script elements appended to fragments will execute when their `src`
       //   or `text` property is set
       return node.canHaveChildren && !reSkip.test(nodeName) && !node.tagUrn ? data.frag.appendChild(node) : node;
     }

     /**
      * returns a shived DocumentFragment for the given document
      * @memberOf html5
      * @param {Document} ownerDocument The context document.
      * @returns {Object} The shived DocumentFragment.
      */
     function createDocumentFragment(ownerDocument, data){
       if (!ownerDocument) {
         ownerDocument = document;
       }
       if(supportsUnknownElements){
         return ownerDocument.createDocumentFragment();
       }
       data = data || getExpandoData(ownerDocument);
       var clone = data.frag.cloneNode(),
       i = 0,
       elems = getElements(),
       l = elems.length;
       for(;i<l;i++){
         clone.createElement(elems[i]);
       }
       return clone;
     }

     /**
      * Shivs the `createElement` and `createDocumentFragment` methods of the document.
      * @private
      * @param {Document|DocumentFragment} ownerDocument The document.
      * @param {Object} data of the document.
      */
     function shivMethods(ownerDocument, data) {
       if (!data.cache) {
         data.cache = {};
         data.createElem = ownerDocument.createElement;
         data.createFrag = ownerDocument.createDocumentFragment;
         data.frag = data.createFrag();
       }


       ownerDocument.createElement = function(nodeName) {
         //abort shiv
         if (!html5.shivMethods) {
           return data.createElem(nodeName);
         }
         return createElement(nodeName, ownerDocument, data);
       };

       ownerDocument.createDocumentFragment = Function('h,f', 'return function(){' +
                                                       'var n=f.cloneNode(),c=n.createElement;' +
                                                       'h.shivMethods&&(' +
                                                       // unroll the `createElement` calls
                                                       getElements().join().replace(/[\w\-]+/g, function(nodeName) {
         data.createElem(nodeName);
         data.frag.createElement(nodeName);
         return 'c("' + nodeName + '")';
       }) +
         ');return n}'
                                                      )(html5, data.frag);
     }

     /*--------------------------------------------------------------------------*/

     /**
      * Shivs the given document.
      * @memberOf html5
      * @param {Document} ownerDocument The document to shiv.
      * @returns {Document} The shived document.
      */
     function shivDocument(ownerDocument) {
       if (!ownerDocument) {
         ownerDocument = document;
       }
       var data = getExpandoData(ownerDocument);

       if (html5.shivCSS && !supportsHtml5Styles && !data.hasCSS) {
         data.hasCSS = !!addStyleSheet(ownerDocument,
                                       // corrects block display not defined in IE6/7/8/9
                                       'article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}' +
                                         // adds styling not present in IE6/7/8/9
                                         'mark{background:#FF0;color:#000}' +
                                         // hides non-rendered elements
                                         'template{display:none}'
                                      );
       }
       if (!supportsUnknownElements) {
         shivMethods(ownerDocument, data);
       }
       return ownerDocument;
     }

     /*--------------------------------------------------------------------------*/

     /**
      * The `html5` object is exposed so that more elements can be shived and
      * existing shiving can be detected on iframes.
      * @type Object
      * @example
      *
      * // options can be changed before the script is included
      * html5 = { 'elements': 'mark section', 'shivCSS': false, 'shivMethods': false };
      */
     var html5 = {

       /**
        * An array or space separated string of node names of the elements to shiv.
        * @memberOf html5
        * @type Array|String
        */
       'elements': options.elements || 'abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video',

       /**
        * current version of html5shiv
        */
       'version': version,

       /**
        * A flag to indicate that the HTML5 style sheet should be inserted.
        * @memberOf html5
        * @type Boolean
        */
       'shivCSS': (options.shivCSS !== false),

       /**
        * Is equal to true if a browser supports creating unknown/HTML5 elements
        * @memberOf html5
        * @type boolean
        */
       'supportsUnknownElements': supportsUnknownElements,

       /**
        * A flag to indicate that the document's `createElement` and `createDocumentFragment`
        * methods should be overwritten.
        * @memberOf html5
        * @type Boolean
        */
       'shivMethods': (options.shivMethods !== false),

       /**
        * A string to describe the type of `html5` object ("default" or "default print").
        * @memberOf html5
        * @type String
        */
       'type': 'default',

       // shivs the document according to the specified `html5` object options
       'shivDocument': shivDocument,

       //creates a shived element
       createElement: createElement,

       //creates a shived documentFragment
       createDocumentFragment: createDocumentFragment
     };

     /*--------------------------------------------------------------------------*/

     // expose html5
     window.html5 = html5;

     // shiv the document
     shivDocument(document);

 }(this, document));
 /*>>shiv*/

 // Assign private properties to the return object with prefix
 Modernizr._version      = version;

 // expose these for the plugin API. Look in the source for how to join() them against your input
 /*>>prefixes*/
 Modernizr._prefixes     = prefixes;
 /*>>prefixes*/
 /*>>domprefixes*/
 Modernizr._domPrefixes  = domPrefixes;
 Modernizr._cssomPrefixes  = cssomPrefixes;
 /*>>domprefixes*/

 /*>>mq*/
 // Modernizr.mq tests a given media query, live against the current state of the window
 // A few important notes:
 //   * If a browser does not support media queries at all (eg. oldIE) the mq() will always return false
 //   * A max-width or orientation query will be evaluated against the current state, which may change later.
 //   * You must specify values. Eg. If you are testing support for the min-width media query use:
 //       Modernizr.mq('(min-width:0)')
 // usage:
 // Modernizr.mq('only screen and (max-width:768)')
 Modernizr.mq            = testMediaQuery;
 /*>>mq*/

 /*>>hasevent*/
 // Modernizr.hasEvent() detects support for a given event, with an optional element to test on
 // Modernizr.hasEvent('gesturestart', elem)
 Modernizr.hasEvent      = isEventSupported;
 /*>>hasevent*/

 /*>>testprop*/
 // Modernizr.testProp() investigates whether a given style property is recognized
 // Note that the property names must be provided in the camelCase variant.
 // Modernizr.testProp('pointerEvents')
 Modernizr.testProp      = function(prop){
     return testProps([prop]);
 };
 /*>>testprop*/

 /*>>testallprops*/
 // Modernizr.testAllProps() investigates whether a given style property,
 //   or any of its vendor-prefixed variants, is recognized
 // Note that the property names must be provided in the camelCase variant.
 // Modernizr.testAllProps('boxSizing')
 Modernizr.testAllProps  = testPropsAll;
 /*>>testallprops*/


 /*>>teststyles*/
 // Modernizr.testStyles() allows you to add custom styles to the document and test an element afterwards
 // Modernizr.testStyles('#modernizr { position:absolute }', function(elem, rule){ ... })
 Modernizr.testStyles    = injectElementWithStyles;
 /*>>teststyles*/


 /*>>prefixed*/
 // Modernizr.prefixed() returns the prefixed or nonprefixed property name variant of your input
 // Modernizr.prefixed('boxSizing') // 'MozBoxSizing'

 // Properties must be passed as dom-style camelcase, rather than `box-sizing` hypentated style.
 // Return values will also be the camelCase variant, if you need to translate that to hypenated style use:
 //
 //     str.replace(/([A-Z])/g, function(str,m1){ return '-' + m1.toLowerCase(); }).replace(/^ms-/,'-ms-');

 // If you're trying to ascertain which transition end event to bind to, you might do something like...
 //
 //     var transEndEventNames = {
 //       'WebkitTransition' : 'webkitTransitionEnd',
 //       'MozTransition'    : 'transitionend',
 //       'OTransition'      : 'oTransitionEnd',
 //       'msTransition'     : 'MSTransitionEnd',
 //       'transition'       : 'transitionend'
 //     },
 //     transEndEventName = transEndEventNames[ Modernizr.prefixed('transition') ];

 Modernizr.prefixed      = function(prop, obj, elem){
   if(!obj) {
     return testPropsAll(prop, 'pfx');
   } else {
     // Testing DOM property e.g. Modernizr.prefixed('requestAnimationFrame', window) // 'mozRequestAnimationFrame'
     return testPropsAll(prop, obj, elem);
   }
 };
 /*>>prefixed*/


 /*>>cssclasses*/
 // Remove "no-js" class from <html> element, if it exists:
 docElement.className = docElement.className.replace(/(^|\s)no-js(\s|$)/, '$1$2') +

                         // Add the new classes to the <html> element.
                         (enableClasses ? ' js ' + classes.join(' ') : '');
 /*>>cssclasses*/

 return Modernizr;

})(this, this.document);

/*! jQuery Mobile v1.4.4 | Copyright 2010, 2014 jQuery Foundation, Inc. | jquery.org/license */

(function(e,t,n){typeof define=="function"&&define.amd?define(["jquery"],function(r){return n(r,e,t),r.mobile}):n(e.jQuery,e,t)})(this,document,function(e,t,n,r){(function(e,n){e.extend(e.support,{orientation:"orientation"in t&&"onorientationchange"in t})})(e),function(e){e.event.special.throttledresize={setup:function(){e(this).bind("resize",n)},teardown:function(){e(this).unbind("resize",n)}};var t=250,n=function(){s=(new Date).getTime(),o=s-r,o>=t?(r=s,e(this).trigger("throttledresize")):(i&&clearTimeout(i),i=setTimeout(n,t-o))},r=0,i,s,o}(e),function(e,t){function p(){var e=s();e!==o&&(o=e,r.trigger(i))}var r=e(t),i="orientationchange",s,o,u,a,f={0:!0,180:!0},l,c,h;if(e.support.orientation){l=t.innerWidth||r.width(),c=t.innerHeight||r.height(),h=50,u=l>c&&l-c>h,a=f[t.orientation];if(u&&a||!u&&!a)f={"-90":!0,90:!0}}e.event.special.orientationchange=e.extend({},e.event.special.orientationchange,{setup:function(){if(e.support.orientation&&!e.event.special.orientationchange.disabled)return!1;o=s(),r.bind("throttledresize",p)},teardown:function(){if(e.support.orientation&&!e.event.special.orientationchange.disabled)return!1;r.unbind("throttledresize",p)},add:function(e){var t=e.handler;e.handler=function(e){return e.orientation=s(),t.apply(this,arguments)}}}),e.event.special.orientationchange.orientation=s=function(){var r=!0,i=n.documentElement;return e.support.orientation?r=f[t.orientation]:r=i&&i.clientWidth/i.clientHeight<1.1,r?"portrait":"landscape"},e.fn[i]=function(e){return e?this.bind(i,e):this.trigger(i)},e.attrFn&&(e.attrFn[i]=!0)}(e,this),function(e,t,n,r){function T(e){while(e&&typeof e.originalEvent!="undefined")e=e.originalEvent;return e}function N(t,n){var i=t.type,s,o,a,l,c,h,p,d,v;t=e.Event(t),t.type=n,s=t.originalEvent,o=e.event.props,i.search(/^(mouse|click)/)>-1&&(o=f);if(s)for(p=o.length,l;p;)l=o[--p],t[l]=s[l];i.search(/mouse(down|up)|click/)>-1&&!t.which&&(t.which=1);if(i.search(/^touch/)!==-1){a=T(s),i=a.touches,c=a.changedTouches,h=i&&i.length?i[0]:c&&c.length?c[0]:r;if(h)for(d=0,v=u.length;d<v;d++)l=u[d],t[l]=h[l]}return t}function C(t){var n={},r,s;while(t){r=e.data(t,i);for(s in r)r[s]&&(n[s]=n.hasVirtualBinding=!0);t=t.parentNode}return n}function k(t,n){var r;while(t){r=e.data(t,i);if(r&&(!n||r[n]))return t;t=t.parentNode}return null}function L(){g=!1}function A(){g=!0}function O(){E=0,v.length=0,m=!1,A()}function M(){L()}function _(){D(),c=setTimeout(function(){c=0,O()},e.vmouse.resetTimerDuration)}function D(){c&&(clearTimeout(c),c=0)}function P(t,n,r){var i;if(r&&r[t]||!r&&k(n.target,t))i=N(n,t),e(n.target).trigger(i);return i}function H(t){var n=e.data(t.target,s),r;!m&&(!E||E!==n)&&(r=P("v"+t.type,t),r&&(r.isDefaultPrevented()&&t.preventDefault(),r.isPropagationStopped()&&t.stopPropagation(),r.isImmediatePropagationStopped()&&t.stopImmediatePropagation()))}function B(t){var n=T(t).touches,r,i,o;n&&n.length===1&&(r=t.target,i=C(r),i.hasVirtualBinding&&(E=w++,e.data(r,s,E),D(),M(),d=!1,o=T(t).touches[0],h=o.pageX,p=o.pageY,P("vmouseover",t,i),P("vmousedown",t,i)))}function j(e){if(g)return;d||P("vmousecancel",e,C(e.target)),d=!0,_()}function F(t){if(g)return;var n=T(t).touches[0],r=d,i=e.vmouse.moveDistanceThreshold,s=C(t.target);d=d||Math.abs(n.pageX-h)>i||Math.abs(n.pageY-p)>i,d&&!r&&P("vmousecancel",t,s),P("vmousemove",t,s),_()}function I(e){if(g)return;A();var t=C(e.target),n,r;P("vmouseup",e,t),d||(n=P("vclick",e,t),n&&n.isDefaultPrevented()&&(r=T(e).changedTouches[0],v.push({touchID:E,x:r.clientX,y:r.clientY}),m=!0)),P("vmouseout",e,t),d=!1,_()}function q(t){var n=e.data(t,i),r;if(n)for(r in n)if(n[r])return!0;return!1}function R(){}function U(t){var n=t.substr(1);return{setup:function(){q(this)||e.data(this,i,{});var r=e.data(this,i);r[t]=!0,l[t]=(l[t]||0)+1,l[t]===1&&b.bind(n,H),e(this).bind(n,R),y&&(l.touchstart=(l.touchstart||0)+1,l.touchstart===1&&b.bind("touchstart",B).bind("touchend",I).bind("touchmove",F).bind("scroll",j))},teardown:function(){--l[t],l[t]||b.unbind(n,H),y&&(--l.touchstart,l.touchstart||b.unbind("touchstart",B).unbind("touchmove",F).unbind("touchend",I).unbind("scroll",j));var r=e(this),s=e.data(this,i);s&&(s[t]=!1),r.unbind(n,R),q(this)||r.removeData(i)}}}var i="virtualMouseBindings",s="virtualTouchID",o="vmouseover vmousedown vmousemove vmouseup vclick vmouseout vmousecancel".split(" "),u="clientX clientY pageX pageY screenX screenY".split(" "),a=e.event.mouseHooks?e.event.mouseHooks.props:[],f=e.event.props.concat(a),l={},c=0,h=0,p=0,d=!1,v=[],m=!1,g=!1,y="addEventListener"in n,b=e(n),w=1,E=0,S,x;e.vmouse={moveDistanceThreshold:10,clickDistanceThreshold:10,resetTimerDuration:1500};for(x=0;x<o.length;x++)e.event.special[o[x]]=U(o[x]);y&&n.addEventListener("click",function(t){var n=v.length,r=t.target,i,o,u,a,f,l;if(n){i=t.clientX,o=t.clientY,S=e.vmouse.clickDistanceThreshold,u=r;while(u){for(a=0;a<n;a++){f=v[a],l=0;if(u===r&&Math.abs(f.x-i)<S&&Math.abs(f.y-o)<S||e.data(u,s)===f.touchID){t.preventDefault(),t.stopPropagation();return}}u=u.parentNode}}},!0)}(e,t,n),function(e){e.mobile={}}(e),function(e,t){var r={touch:"ontouchend"in n};e.mobile.support=e.mobile.support||{},e.extend(e.support,r),e.extend(e.mobile.support,r)}(e),function(e,t,r){function l(t,n,i,s){var o=i.type;i.type=n,s?e.event.trigger(i,r,t):e.event.dispatch.call(t,i),i.type=o}var i=e(n),s=e.mobile.support.touch,o="touchmove scroll",u=s?"touchstart":"mousedown",a=s?"touchend":"mouseup",f=s?"touchmove":"mousemove";e.each("touchstart touchmove touchend tap taphold swipe swipeleft swiperight scrollstart scrollstop".split(" "),function(t,n){e.fn[n]=function(e){return e?this.bind(n,e):this.trigger(n)},e.attrFn&&(e.attrFn[n]=!0)}),e.event.special.scrollstart={enabled:!0,setup:function(){function s(e,n){r=n,l(t,r?"scrollstart":"scrollstop",e)}var t=this,n=e(t),r,i;n.bind(o,function(t){if(!e.event.special.scrollstart.enabled)return;r||s(t,!0),clearTimeout(i),i=setTimeout(function(){s(t,!1)},50)})},teardown:function(){e(this).unbind(o)}},e.event.special.tap={tapholdThreshold:750,emitTapOnTaphold:!0,setup:function(){var t=this,n=e(t),r=!1;n.bind("vmousedown",function(s){function a(){clearTimeout(u)}function f(){a(),n.unbind("vclick",c).unbind("vmouseup",a),i.unbind("vmousecancel",f)}function c(e){f(),!r&&o===e.target?l(t,"tap",e):r&&e.preventDefault()}r=!1;if(s.which&&s.which!==1)return!1;var o=s.target,u;n.bind("vmouseup",a).bind("vclick",c),i.bind("vmousecancel",f),u=setTimeout(function(){e.event.special.tap.emitTapOnTaphold||(r=!0),l(t,"taphold",e.Event("taphold",{target:o}))},e.event.special.tap.tapholdThreshold)})},teardown:function(){e(this).unbind("vmousedown").unbind("vclick").unbind("vmouseup"),i.unbind("vmousecancel")}},e.event.special.swipe={scrollSupressionThreshold:30,durationThreshold:1e3,horizontalDistanceThreshold:30,verticalDistanceThreshold:30,getLocation:function(e){var n=t.pageXOffset,r=t.pageYOffset,i=e.clientX,s=e.clientY;if(e.pageY===0&&Math.floor(s)>Math.floor(e.pageY)||e.pageX===0&&Math.floor(i)>Math.floor(e.pageX))i-=n,s-=r;else if(s<e.pageY-r||i<e.pageX-n)i=e.pageX-n,s=e.pageY-r;return{x:i,y:s}},start:function(t){var n=t.originalEvent.touches?t.originalEvent.touches[0]:t,r=e.event.special.swipe.getLocation(n);return{time:(new Date).getTime(),coords:[r.x,r.y],origin:e(t.target)}},stop:function(t){var n=t.originalEvent.touches?t.originalEvent.touches[0]:t,r=e.event.special.swipe.getLocation(n);return{time:(new Date).getTime(),coords:[r.x,r.y]}},handleSwipe:function(t,n,r,i){if(n.time-t.time<e.event.special.swipe.durationThreshold&&Math.abs(t.coords[0]-n.coords[0])>e.event.special.swipe.horizontalDistanceThreshold&&Math.abs(t.coords[1]-n.coords[1])<e.event.special.swipe.verticalDistanceThreshold){var s=t.coords[0]>n.coords[0]?"swipeleft":"swiperight";return l(r,"swipe",e.Event("swipe",{target:i,swipestart:t,swipestop:n}),!0),l(r,s,e.Event(s,{target:i,swipestart:t,swipestop:n}),!0),!0}return!1},eventInProgress:!1,setup:function(){var t,n=this,r=e(n),s={};t=e.data(this,"mobile-events"),t||(t={length:0},e.data(this,"mobile-events",t)),t.length++,t.swipe=s,s.start=function(t){if(e.event.special.swipe.eventInProgress)return;e.event.special.swipe.eventInProgress=!0;var r,o=e.event.special.swipe.start(t),u=t.target,l=!1;s.move=function(t){if(!o||t.isDefaultPrevented())return;r=e.event.special.swipe.stop(t),l||(l=e.event.special.swipe.handleSwipe(o,r,n,u),l&&(e.event.special.swipe.eventInProgress=!1)),Math.abs(o.coords[0]-r.coords[0])>e.event.special.swipe.scrollSupressionThreshold&&t.preventDefault()},s.stop=function(){l=!0,e.event.special.swipe.eventInProgress=!1,i.off(f,s.move),s.move=null},i.on(f,s.move).one(a,s.stop)},r.on(u,s.start)},teardown:function(){var t,n;t=e.data(this,"mobile-events"),t&&(n=t.swipe,delete t.swipe,t.length--,t.length===0&&e.removeData(this,"mobile-events")),n&&(n.start&&e(this).off(u,n.start),n.move&&i.off(f,n.move),n.stop&&i.off(a,n.stop))}},e.each({scrollstop:"scrollstart",taphold:"tap",swipeleft:"swipe.left",swiperight:"swipe.right"},function(t,n){e.event.special[t]={setup:function(){e(this).bind(n,e.noop)},teardown:function(){e(this).unbind(n)}}})}(e,this)});


/**
* radiosToSlider v0.3.2
* jquery plugin to create a slider using a list of radio buttons
* (c)2014 Rub�n Torres - rubentdlh@gmail.com
* Released under the MIT license
*/

$( window ).on( "load", function() {

    $("#radios").attr('checked',true);
     //$("#option2").prop('checked',true);
});

(function($) {
 function RadiosToSlider(element, options) {
     this.KNOB_WIDTH = 32;
     this.KNOB_MARGIN = 28;
     this.LEVEL_MARGIN = this.KNOB_MARGIN + 10;
     this.LABEL_WIDTH = 44;
     this.LEVEL_WIDTH = 22;
     this.bearer = element;
     this.options = options;
     this.currentLevel = 0; //this means no level selected
     this.value = null;
 }

 RadiosToSlider.prototype = {

     activate: function() {
         // Get number options
         this.numOptions = this.bearer.find('input[type=radio]').length;
         this.reset(); // helps prevent duplication
         this.fitContainer();
         this.addBaseStyle();
         this.addLevels();
         this.addBar();
         this.setSlider();       
         this.addInteraction();
         this.setDisabled();

         var slider = this;

         $(window).on('resize orientationChanged', function() {
             slider.reset();
             slider.fitContainer();
             slider.addBaseStyle();
             slider.addLevels();
             slider.setSlider();
             slider.addInteraction();
             slider.setDisabled();
         });
     },

     reset: function() {
         var $labels = this.bearer.find('label'),
             $levels = this.bearer.find('.slider-level');

         $labels.each(function() {
             var $this = $(this);

             $this.removeClass('slider-label');
             $this.css('left', 0);
         });

         $levels.each(function() {
             $(this).remove();
         });

         this.bearer.css('width', 'auto');
     },

     fitContainer: function() {
         // If fitContainer, calculate KNOB_MARGIN based on container width
         if (this.options.fitContainer) {
             this.KNOB_MARGIN = (this.bearer.width() - this.KNOB_WIDTH) / (this.numOptions - 1) - this.KNOB_WIDTH;
             this.LEVEL_MARGIN = this.KNOB_MARGIN + 10;
         }
     },

     addBaseStyle: function() {
         var label = 0,
             slider = this,
             width = (this.numOptions * this.LEVEL_WIDTH) + (this.numOptions - 1) * this.LEVEL_MARGIN;

         this.bearer.find('input[type=radio]').hide();
         this.bearer.addClass("radios-to-slider " + this.options.size);
         this.bearer.css('width', width + 'px');
         this.bearer.find('label').each(function() {
             var $this = $(this),
                 leftPos = slider.KNOB_WIDTH / 2 - (slider.LABEL_WIDTH / 2) + label * slider.LEVEL_MARGIN + label * slider.LEVEL_WIDTH;

             $this.addClass('slider-label');
             $this.css('left', leftPos + 'px');

             label++;
         });
     },

     //Add level indicators to DOM
     addLevels: function() {
         var $bearer = this.bearer,
             level = 0,
             slider = this;

         $bearer.find('input[type=radio]').each(function() {
             var $this = $(this);

             $bearer.append("<ins class='slider-level' data-radio='" + $this.attr('id') + "' data-value=" + $this.val() + "></ins>");
         });

         $bearer.find('.slider-level').each(function() {
             var $this = $(this),
                 paddingLeft = $bearer.css('padding-left').replace('px', '') - 0,
                 width = paddingLeft + (level * slider.LEVEL_MARGIN) + (level * slider.LEVEL_WIDTH);

             $this.css('left', width + 'px');

             level++;
         });

     },

     //Add slider bar to DOM
     addBar: function() {
         this.bearer.append("<ins class='slider-bar'><span class='slider-knob'></span></ins>");
     },

     //set width of slider bar and current level
     setSlider: function() {
         var $inputs = this.bearer.find('input[type=radio]'),
             $levels = this.bearer.find('.slider-level'),
             $labels = this.bearer.find('.slider-label'),
             radio = 1,
             slider = this,
             label;

         $inputs.each(function() {
             var $this = $(this),
                 $sliderbar = slider.bearer.find('.slider-bar'),
                 radioId = $this.attr('id');

             if ($this.prop('checked')) {
                 var width = (radio * slider.KNOB_WIDTH) + (radio - 1) * slider.KNOB_MARGIN;

                 $sliderbar.css('display', 'block');
                 $sliderbar.width(width + 'px');

                 slider.currentLevel = radio;
             }

             if (slider.options.animation) {
                 $sliderbar.addClass('transition-enabled');
             }

             radio++;
         });

         //Set style for lower levels
         label = 0;
         $levels.each(function() {
             label++;

             var $this = $(this);

             if (label < slider.currentLevel) {
                 $this.show();
                 $this.addClass('slider-lower-level');
             } else if (label == slider.currentLevel) {
                 $this.hide();
             } else {
                 $this.show();
                 $this.removeClass('slider-lower-level');
             }
         });

         //Add bold style for selected label
         label = 0;
         $labels.each(function() {
             label++;

             var $this = $(this);

             if (label == slider.currentLevel) {
                 $this.addClass('slider-label-active');
             } else {
                 $this.removeClass('slider-label-active');
             }
         });
     },

     addInteraction: function() {
         var slider = this,
             $bearer = slider.bearer,
             $levels = $bearer.find('.slider-level:not(.disabled)'),
             $inputs = $bearer.find('input[type=radio]:not(:disabled)');

         $levels.on('click', function() {
             var $this = $(this),
                 val = $this.attr('data-value'),
                 radioId = $this.attr('data-radio'),
                 radioElement = $bearer.find('#' + radioId);

             radioElement.prop('checked', true);

             if (slider.options.onSelect) {
                 slider.options.onSelect(radioElement, [
                     $levels,
                     $inputs
                 ]);
             }

             slider.value = val;
             $bearer.attr('data-value', val);

             slider.setSlider();

             $bearer.trigger('radiochange');
         });

         $inputs.on('change', function() {
             var $this = $(this),
                 val = $this.attr('data-value'),
                 radioId = $this.attr('data-radio'),
                 radioElement = $bearer.find('#' + radioId);

             radioElement.prop('checked', true);

             if (slider.options.onChange) {
                 slider.options.onChange(radioElement, [
                     $levels,
                     $inputs
                 ]);
             }

             slider.value = val;
             $bearer.attr('data-value', val);

             slider.setSlider();
             $bearer.trigger('radiochange');
         });

     },

     setDisabled: function(isDisable, cb) {
         if (!this.options.isDisable) return;

         this.setDisable();
     },

     setDisable: function(cb) {
         this.options.isDisable = true;

         var slider = this,
             $bearer = slider.bearer,
             $levels = this.bearer.find('.slider-level'),
             $inputs = this.bearer.find('input[type=radio]');

         $.merge($levels, $inputs).each(function() {
             var $this = $(this);

             $this.prop('disabled', true).addClass('disabled');
             $this.off('click change');
         });

         if (typeof cb === "function") {
             cb($levels, $inputs);
         }

         $bearer.trigger('radiodisabled');
     },

     setEnable: function(cb) {
         this.options.isDisable = false;

         var slider = this,
             $bearer = slider.bearer,
             $levels = this.bearer.find('.slider-level'),
             $inputs = this.bearer.find('input[type=radio]');

         $.merge($levels, $inputs).each(function() {
             $(this).prop('disabled', false).removeClass('disabled');
             slider.addInteraction();
         });

         if (typeof cb === "function") {
             cb($levels, $inputs);
         }

         $bearer.trigger('radiodenabled');
     },

     getValue: function() {
         return this.value;
     }

 };

 $.fn.radiosToSlider = function(options) {
     var rtn = [],
         $this = this;

     $this.each(function() {
         options = $.extend({}, $.fn.radiosToSlider.defaults, options);

         var slider = new RadiosToSlider($(this), options);
         slider.activate();

         rtn.push({
             bearer: slider.bearer,
             setDisable: slider.setDisable.bind(slider),
             setEnable: slider.setEnable.bind(slider),
             getValue: slider.getValue.bind(slider)
         });
     });

     return rtn;
 };

 $.fn.radiosToSlider.defaults = {
     size: 'medium',
     animation: true,
     fitContainer: true,
     isDisable: false,
     onSelect: null
 };

})(jQuery);


//******************************* DOBOZ End *************************************************
//==========================================================================================

//Refer a friend js
//var WinH = $(window).height();
var WinW = $(window).width();
if (WinW > 767) {
	$('.dropdown').click(function() {
		$('.body-lock').toggle();
	});
	$('.body-lock').click(function() {
		$('.body-lock').toggle();
	});
}
var navH=$('nav').outerHeight();
var marH=$('marquee').outerHeight();
$('.navbar').css('top',marH+'px');
$('.navH').css('height',(navH+marH));


if (WinW <= 767) {
    var username = $('.login-menu').html();
    //console.log(username);
    $('.login-menu').remove();
    $('.uname').html(username).addClass('dropdown login-menu');
}

/*
});*/







